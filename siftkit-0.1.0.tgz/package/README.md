# SiftKit

SiftKit is a Windows-first PowerShell module for conservative shell-output compression in Codex workflows. It replaces `distill` with a local toolkit that preserves raw logs, uses deterministic reduction first, and summarizes through Ollama only when the policy allows it.

## What it ships

- `Install-SiftKit`: bootstrap runtime folders and config under `%USERPROFILE%\.siftkit`
- `Test-SiftKit`: verify Ollama discovery, configured model presence, and runtime paths
- `Invoke-SiftSummary`: summarize pipeline input, explicit text, or a file
- `Invoke-SiftCommand`: run a command, save raw output, reduce noise, and summarize conservatively
- `Invoke-SiftEvaluation`: benchmark synthetic fixtures and optional real logs
- `Install-SiftCodexPolicy`: install SiftKit guidance into Codex `AGENTS.md`

## Import and bootstrap

```powershell
Import-Module .\SiftKit\SiftKit.psd1 -Force
Install-SiftKit
Test-SiftKit
```

The default backend is `ollama` and the default model is `qwen3.5:4b-q8_0`.

## Make it global

You can install the module and CLI shims into user-scoped locations:

```powershell
Import-Module .\SiftKit\SiftKit.psd1 -Force
Install-SiftKitShellIntegration
```

That installs:

- the module into your user PowerShell modules folder
- `siftkit.ps1` and `siftkit.cmd` into `%USERPROFILE%\bin`

After adding `%USERPROFILE%\bin` to `PATH`, you can use it like:

```powershell
siftkit "what is the main problem?"
some-command 2>&1 | siftkit "summarize only the decisive failures"
siftkit run --command pytest --arg -q --question "did tests pass?"
```

If you want npm-style global installation behavior, the repo now exposes an npm bin entry:

```powershell
npm i -g .
```

That installs a global `siftkit` command which launches the bundled PowerShell CLI.

## Usage

Summarize raw text:

```powershell
Get-Content .\build.log -Raw |
    Invoke-SiftSummary -Question 'extract the root exception and first relevant application frame'
```

Run a command and keep the raw log:

```powershell
Invoke-SiftCommand `
    -Command pytest `
    -ArgumentList '-q' `
    -Question 'did tests pass? if not, list only failing tests' `
    -RiskLevel informational `
    -ReducerProfile smart
```

Summarize risky output conservatively:

```powershell
Invoke-SiftCommand `
    -Command terraform `
    -ArgumentList 'plan', '-no-color' `
    -Question 'extract resources added, changed, and destroyed' `
    -RiskLevel risky `
    -PolicyProfile risky-operation
```

Install the Codex policy block:

```powershell
Install-SiftCodexPolicy
```

## Evaluation

Run the shipped synthetic fixtures:

```powershell
Invoke-SiftEvaluation
```

Add one or more real logs for manual review:

```powershell
Invoke-SiftEvaluation -RealLogPath .\logs\pytest.log, .\logs\terraform.log
```

Results are written under `%USERPROFILE%\.siftkit\eval\results`.

## Repo layout

- [`SiftKit/SiftKit.psm1`](C:\Users\denys\Documents\GitHub\SiftKit\SiftKit\SiftKit.psm1): module implementation
- [`eval/fixtures/fixtures.json`](C:\Users\denys\Documents\GitHub\SiftKit\eval\fixtures\fixtures.json): synthetic benchmark manifest
- [`docs/architecture.md`](C:\Users\denys\Documents\GitHub\SiftKit\docs\architecture.md): architecture and policy notes
- [`distill_codex_recommendation.md`](C:\Users\denys\Documents\GitHub\SiftKit\distill_codex_recommendation.md): original recommendation doc that SiftKit operationalizes
