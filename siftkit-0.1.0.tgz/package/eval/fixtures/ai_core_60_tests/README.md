# Imported Benchmark Fixtures

Source suite: C:\Users\denys\Documents\GitHub\ai_idle\core_project - Copy\siftkit_benchmark_suite.md
Repo root: C:\Users\denys\Documents\GitHub\ai_idle\core_project - Copy

This folder was generated from the markdown benchmark suite.
Each raw fixture file contains the command output before SiftKit summarization.
Use it with `npm run benchmark -- --fixture-root "<this-folder>"`.

Fixture count: 60