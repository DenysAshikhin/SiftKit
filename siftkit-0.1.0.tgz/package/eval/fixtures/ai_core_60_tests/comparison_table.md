| Test | Run 1 Pros | Run 1 Cons | Run 1 Score | Run 2 Pros | Run 2 Cons | Run 2 Score | Pick |
|---|---|---|---:|---|---|---:|---|
| 01. Root Inventory | Better answer-key overlap; No raw-review flag | - | 5.08 | - | Weaker answer-key overlap; Raw-review flag | 3.87 | Run 1 |
| 02. Broad Key-File Inventory | Better answer-key overlap | Raw-review flag | 4.69 | - | Weaker answer-key overlap; Raw-review flag | 3.42 | Run 1 |
| 03. Tools Inventory | - | Weaker answer-key overlap; Raw-review flag | 5.05 | Better answer-key overlap | Raw-review flag | 5.71 | Run 2 |
| 04. Tests Tree | Better answer-key overlap | Raw-review flag | 3.6 | - | Weaker answer-key overlap; Raw-review flag | 2.26 | Run 1 |
| 05. README Summary | - | Weaker answer-key overlap; Raw-review flag; More extraneous wording | 3.21 | Better answer-key overlap | Raw-review flag | 3.61 | Run 2 |
| 06. Project Config Overview | No raw-review flag | Weaker answer-key overlap | 5.32 | Better answer-key overlap | Raw-review flag | 5.73 | Run 2 |
| 07. Main Scene And Autoloads | - | Weaker answer-key overlap; Raw-review flag | 8.07 | Better answer-key overlap | Raw-review flag | 9.02 | Run 2 |
| 08. Overview Index Routing | Better answer-key overlap | Raw-review flag | 7.99 | - | Weaker answer-key overlap; Raw-review flag | 7.14 | Run 1 |
| 09. Runtime Flow Overview | - | Weaker answer-key overlap; Raw-review flag | 1.97 | Better answer-key overlap | Raw-review flag | 2.4 | Run 2 |
| 10. root_game.gd | Comparable quality; Faster tie-break | Raw-review flag | 2.84 | Comparable quality | Raw-review flag; Slower tie-break | 2.71 | Run 1 |
| 11. main_menu.gd | - | Weaker answer-key overlap; Raw-review flag; More extraneous wording | 1.74 | Better answer-key overlap | Raw-review flag | 4.01 | Run 2 |
| 12. loading_screen.gd | Better answer-key overlap | Raw-review flag | 5.22 | - | Weaker answer-key overlap; Raw-review flag | 4.47 | Run 1 |
| 13. test_harness.gd | Comparable quality; Faster tie-break | Raw-review flag | 3.51 | Comparable quality | Raw-review flag; Slower tie-break | 3.48 | Run 1 |
| 14. Representative Integration Test | Comparable quality; Faster tie-break | Raw-review flag | 5 | Comparable quality | Raw-review flag; Slower tie-break | 4.87 | Run 1 |
| 15. GUI Test Runner | Comparable quality | Raw-review flag; Slower tie-break | 4.48 | Comparable quality; Faster tie-break | Raw-review flag | 4.58 | Run 2 |
| 16. Full-Game Smoke Runner | Better answer-key overlap | Raw-review flag | 5.02 | - | Weaker answer-key overlap; Raw-review flag | 4.74 | Run 1 |
| 17. Autorun Error Log | - | Weaker answer-key overlap; Raw-review flag | 3.23 | Better answer-key overlap | Raw-review flag | 3.52 | Run 2 |
| 18. Autorun Output Log | Better answer-key overlap | Raw-review flag | 4.14 | - | Weaker answer-key overlap; Raw-review flag; More extraneous wording | 2.78 | Run 1 |
| 19. Script Error And Crash Marker Scan | Comparable quality; Faster tie-break | Raw-review flag | 2.79 | Comparable quality | Raw-review flag; Slower tie-break | 2.92 | Run 1 |
| 20. Specific Historical Failure Log | Better answer-key overlap | Raw-review flag | 3.83 | - | Weaker answer-key overlap; Raw-review flag | 3.41 | Run 1 |
| 21. Latest .godot_logs Inventory | - | Weaker answer-key overlap; Raw-review flag; More extraneous wording | 1.26 | Better answer-key overlap | Raw-review flag | 1.97 | Run 2 |
| 22. Save And Auth References | Better answer-key overlap | Raw-review flag | 5.58 | - | Weaker answer-key overlap; Raw-review flag | 2.1 | Run 1 |
| 23. SaveManager And Data Contract Search | Better answer-key overlap | Raw-review flag | 3.6 | - | Weaker answer-key overlap; Raw-review flag; More extraneous wording | 1.68 | Run 1 |
| 24. Runtime Entrypoints Search | Better answer-key overlap | Raw-review flag | 5.92 | - | Weaker answer-key overlap; Raw-review flag | 4.58 | Run 1 |
| 25. Threaded Loading, Scene Changes, Leaderboards | - | Weaker answer-key overlap; Raw-review flag | 2.98 | Better answer-key overlap | Raw-review flag | 4.05 | Run 2 |
| 26. Async, Validity, And Signal Patterns | Better answer-key overlap | Raw-review flag | 3.53 | - | Weaker answer-key overlap; Raw-review flag | 2.75 | Run 1 |
| 27. TODO/FIXME/HACK Outside Docs Snapshot | Better answer-key overlap | Raw-review flag | 7.89 | - | Weaker answer-key overlap; Raw-review flag | 7.36 | Run 1 |
| 28. Exact Local Save Path Ownership | Comparable quality; Faster tie-break | Raw-review flag | 4.57 | Comparable quality | Raw-review flag; Slower tie-break | 4.61 | Run 1 |
| 29. Actual Scene Transition Calls | Better answer-key overlap; No raw-review flag | - | 4.86 | - | Weaker answer-key overlap; Raw-review flag | 2.64 | Run 1 |
| 30. Explicit Test Result Markers | Better answer-key overlap; No raw-review flag | - | 3.27 | No raw-review flag | Weaker answer-key overlap | 2.66 | Run 1 |
| 31. Full Unlocks Ownership | Better answer-key overlap | Raw-review flag; More extraneous wording | 1.56 | - | Weaker answer-key overlap; Raw-review flag; More extraneous wording | 0.15 | Run 1 |
| 32. Full Player State Ownership | Better answer-key overlap | Raw-review flag; More extraneous wording | 2.28 | - | Weaker answer-key overlap; Raw-review flag; More extraneous wording | 0.77 | Run 1 |
| 33. Full Global State Ownership | Better answer-key overlap | Raw-review flag; More extraneous wording | 2.7 | - | Weaker answer-key overlap; Raw-review flag; More extraneous wording | 0.87 | Run 1 |
| 34. Full Combat Utilities | - | Weaker answer-key overlap; Raw-review flag; More extraneous wording | 1.54 | Better answer-key overlap | Raw-review flag; More extraneous wording | 1.91 | Run 2 |
| 35. Full Support Runtime | - | Weaker answer-key overlap; Raw-review flag; More extraneous wording | 2.39 | Better answer-key overlap | Raw-review flag; More extraneous wording | 4.01 | Run 2 |
| 36. Full Drone Runtime | - | Weaker answer-key overlap; Raw-review flag; More extraneous wording | 2.11 | Better answer-key overlap | Raw-review flag; More extraneous wording | 2.48 | Run 2 |
| 37. Full Frigate Runtime | Better answer-key overlap | Raw-review flag; More extraneous wording | 5.01 | - | Weaker answer-key overlap; Raw-review flag | 3.68 | Run 1 |
| 38. Enemy Manager Full Read | Better answer-key overlap | Raw-review flag; More extraneous wording | 2.29 | - | Weaker answer-key overlap; Raw-review flag; More extraneous wording | 1.46 | Run 1 |
| 39. Player Manager Full Read | Better answer-key overlap | Raw-review flag; More extraneous wording | 4.94 | - | Weaker answer-key overlap; Raw-review flag; More extraneous wording | 4.27 | Run 1 |
| 40. Map Manager Full Read | Better answer-key overlap | Raw-review flag; More extraneous wording | 3.45 | - | Weaker answer-key overlap; Raw-review flag; More extraneous wording | 0.43 | Run 1 |
| 41. Harness Environment Full Read | - | Weaker answer-key overlap; Raw-review flag; More extraneous wording | 1.28 | Better answer-key overlap | Raw-review flag; More extraneous wording | 1.8 | Run 2 |
| 42. Test Harness Full Read | Better answer-key overlap | Raw-review flag; More extraneous wording | 1.83 | - | Weaker answer-key overlap; Raw-review flag; More extraneous wording | 1.36 | Run 1 |
| 43. Tutorial UI Actions Full Read | Comparable quality | Raw-review flag; Slower tie-break; More extraneous wording | 1.88 | Comparable quality; Faster tie-break | Raw-review flag; More extraneous wording | 1.69 | Run 2 |
| 44. Frigate Unlocks Helper Full Read | Comparable quality | Raw-review flag; Slower tie-break; More extraneous wording | 1.77 | Comparable quality; Faster tie-break | Raw-review flag; More extraneous wording | 1.82 | Run 2 |
| 45. Autonomous Mode Runner Full Read | Comparable quality; Faster tie-break | Raw-review flag; More extraneous wording | 2.42 | Comparable quality | Raw-review flag; Slower tie-break; More extraneous wording | 2.32 | Run 1 |
| 46. Autonomous Suggestions Remediation Full Read | Better answer-key overlap | Raw-review flag; More extraneous wording | 1.54 | - | Weaker answer-key overlap; Raw-review flag; More extraneous wording | 0.47 | Run 1 |
| 47. Grouped Unused Assets Verification | Better answer-key overlap | Raw-review flag; More extraneous wording | 3.64 | - | Weaker answer-key overlap; Raw-review flag; More extraneous wording | 2.01 | Run 1 |
| 48. Holistic Review Packet | Better answer-key overlap | Raw-review flag; More extraneous wording | 1.63 | No raw-review flag | Weaker answer-key overlap; More extraneous wording | 0.68 | Run 1 |
| 49. Main-Game Smoke Stdout Log | Better answer-key overlap | Raw-review flag; More extraneous wording | 2.11 | - | Weaker answer-key overlap; Raw-review flag; More extraneous wording | 1.55 | Run 1 |
| 50. Main-Game Smoke Stderr Log | Better answer-key overlap | Raw-review flag | 4.99 | - | Weaker answer-key overlap; Raw-review flag | 2.06 | Run 1 |
| 51. Test Harness Full Log | Better answer-key overlap | Raw-review flag; More extraneous wording | 2.1 | - | Weaker answer-key overlap; Raw-review flag; More extraneous wording | 1.8 | Run 1 |
| 52. Save/Auth/Leaderboard Broad Search | Better answer-key overlap | Raw-review flag; More extraneous wording | 4.58 | - | Weaker answer-key overlap; Raw-review flag | 3.12 | Run 1 |
| 53. Error/Assert/Failure Search | Better answer-key overlap | Raw-review flag; More extraneous wording | 2.12 | - | Weaker answer-key overlap; Raw-review flag; More extraneous wording | 1.81 | Run 1 |
| 54. Manager Orchestration Search | Better answer-key overlap | Raw-review flag; More extraneous wording | 2.77 | - | Weaker answer-key overlap; Raw-review flag | 2.49 | Run 1 |
| 55. Tutorial/Autonomous Search | - | Weaker answer-key overlap; Raw-review flag | 2.32 | Better answer-key overlap | Raw-review flag | 3.66 | Run 2 |
| 56. Scene Load/Thread Search | Better answer-key overlap | Raw-review flag; More extraneous wording | 2.55 | - | Weaker answer-key overlap; Raw-review flag; More extraneous wording | 2 | Run 1 |
| 57. UI/RootCanvas Systems Search | - | Weaker answer-key overlap; Raw-review flag; More extraneous wording | 2.21 | Better answer-key overlap; No raw-review flag | - | 3.05 | Run 2 |
| 58. Combat Tick/Damage Search | - | Weaker answer-key overlap; Raw-review flag; More extraneous wording | 1.67 | Better answer-key overlap; No raw-review flag | - | 2.57 | Run 2 |
| 59. Unlock/Research/Upgrade Search | - | Weaker answer-key overlap; Raw-review flag | 2.73 | Better answer-key overlap; No raw-review flag | - | 3.33 | Run 2 |
| 60. Entity Families Search | - | Weaker answer-key overlap; Raw-review flag; More extraneous wording | 1.51 | Better answer-key overlap | Raw-review flag; More extraneous wording | 2.67 | Run 2 |
