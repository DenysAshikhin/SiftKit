$script:SiftKitVersion = '0.1.0'
$script:SiftProviders = @{}
$script:SiftMarkers = @{
    CodexPolicyStart = '<!-- SiftKit Policy:Start -->'
    CodexPolicyEnd   = '<!-- SiftKit Policy:End -->'
}

$script:SiftPromptProfiles = @{
    'general' = @'
Summarize only the information supported by the input. Prefer short bullets or short prose.
Do not invent causes, fixes, or certainty that the input does not support.
'@
    'pass-fail' = @'
Focus on pass/fail status. If failures exist, list only failing tests or suites and the first concrete error for each.
Do not include passing tests.
'@
    'unique-errors' = @'
Extract unique real errors. Group repeated lines. Ignore informational noise and warnings unless they directly indicate failure.
'@
    'buried-critical' = @'
Identify the single decisive failure or highest-priority problem if one exists. Ignore repeated harmless lines.
'@
    'json-extraction' = @'
Return only valid JSON. No code fences, commentary, or markdown. Preserve exact identifiers when present.
'@
    'diff-summary' = @'
Summarize functional changes, not formatting churn. Distinguish behavior changes from refactors when possible.
'@
    'risky-operation' = @'
Be conservative. Do not judge the operation safe. Extract facts, highlight destructive or risky actions, and say raw review is still required.
'@
}

function Get-SiftKitRoot {
    $modulePath = $MyInvocation.MyCommand.Module.Path
    Split-Path -Path $modulePath -Parent
}

function Get-SiftRuntimeRoot {
    Join-Path -Path $env:USERPROFILE -ChildPath '.siftkit'
}

function Get-SiftRepoPath {
    param(
        [Parameter(Mandatory = $true)]
        [string]$RelativePath
    )

    Join-Path -Path (Split-Path -Path (Get-SiftKitRoot) -Parent) -ChildPath $RelativePath
}

function New-SiftDirectory {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Path
    )

    if (-not (Test-Path -LiteralPath $Path)) {
        New-Item -Path $Path -ItemType Directory -Force | Out-Null
    }

    return $Path
}

function Get-SiftDefaultConfigObject {
    $runtimeRoot = Get-SiftRuntimeRoot
    [ordered]@{
        Version = $script:SiftKitVersion
        Backend = 'ollama'
        Model = 'qwen3.5:4b-q8_0'
        PolicyMode = 'conservative'
        RawLogRetention = $true
        Ollama = [ordered]@{
            BaseUrl = 'http://127.0.0.1:11434'
            ExecutablePath = $null
        }
        Thresholds = [ordered]@{
            MinCharactersForSummary = 500
            MinLinesForSummary = 16
        }
        Paths = [ordered]@{
            RuntimeRoot = $runtimeRoot
            Logs = Join-Path -Path $runtimeRoot -ChildPath 'logs'
            EvalFixtures = Join-Path -Path $runtimeRoot -ChildPath 'eval\fixtures'
            EvalResults = Join-Path -Path $runtimeRoot -ChildPath 'eval\results'
        }
    }
}

function ConvertTo-SiftJson {
    param(
        [Parameter(Mandatory = $true)]
        [object]$InputObject
    )

    $InputObject | ConvertTo-Json -Depth 8
}

function ConvertFrom-SiftJsonFile {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Path
    )

    if (-not (Test-Path -LiteralPath $Path)) {
        throw "File not found: $Path"
    }

    Get-Content -LiteralPath $Path -Raw | ConvertFrom-Json
}

function Get-SiftConfigPath {
    Join-Path -Path (Get-SiftRuntimeRoot) -ChildPath 'config.json'
}

function Find-OllamaExecutable {
    $command = Get-Command ollama -ErrorAction SilentlyContinue
    if ($command -and $command.Source) {
        return $command.Source
    }

    $candidates = @(
        (Join-Path -Path $env:LOCALAPPDATA -ChildPath 'Programs\Ollama\ollama.exe'),
        (Join-Path -Path $env:ProgramFiles -ChildPath 'Ollama\ollama.exe'),
        (Join-Path -Path ${env:ProgramFiles(x86)} -ChildPath 'Ollama\ollama.exe')
    ) | Where-Object { $_ -and $_.Trim() -ne '' }

    foreach ($candidate in $candidates) {
        if (Test-Path -LiteralPath $candidate) {
            return $candidate
        }
    }

    return $null
}

function Initialize-SiftRuntime {
    $runtimeRoot = New-SiftDirectory -Path (Get-SiftRuntimeRoot)
    $logsPath = New-SiftDirectory -Path (Join-Path -Path $runtimeRoot -ChildPath 'logs')
    $evalRoot = New-SiftDirectory -Path (Join-Path -Path $runtimeRoot -ChildPath 'eval')
    $fixturesPath = New-SiftDirectory -Path (Join-Path -Path $evalRoot -ChildPath 'fixtures')
    $resultsPath = New-SiftDirectory -Path (Join-Path -Path $evalRoot -ChildPath 'results')

    [ordered]@{
        RuntimeRoot = $runtimeRoot
        Logs = $logsPath
        EvalFixtures = $fixturesPath
        EvalResults = $resultsPath
    }
}

function Save-SiftConfig {
    param(
        [Parameter(Mandatory = $true)]
        [hashtable]$Config
    )

    $null = Initialize-SiftRuntime
    Set-Content -LiteralPath (Get-SiftConfigPath) -Value (ConvertTo-SiftJson -InputObject $Config) -Encoding UTF8
}

function Get-SiftConfig {
    param(
        [switch]$Ensure
    )

    $configPath = Get-SiftConfigPath
    if (-not (Test-Path -LiteralPath $configPath)) {
        if (-not $Ensure) {
            throw "SiftKit is not installed. Run Install-SiftKit first."
        }

        $paths = Initialize-SiftRuntime
        $config = Get-SiftDefaultConfigObject
        $config.Paths.RuntimeRoot = $paths.RuntimeRoot
        $config.Paths.Logs = $paths.Logs
        $config.Paths.EvalFixtures = $paths.EvalFixtures
        $config.Paths.EvalResults = $paths.EvalResults
        $config.Ollama.ExecutablePath = Find-OllamaExecutable
        Save-SiftConfig -Config $config
    }

    ConvertFrom-SiftJsonFile -Path $configPath
}

function Register-SiftProvider {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Name,
        [Parameter(Mandatory = $true)]
        [scriptblock]$TestScript,
        [Parameter(Mandatory = $true)]
        [scriptblock]$ListModelsScript,
        [Parameter(Mandatory = $true)]
        [scriptblock]$SummarizeScript
    )

    $script:SiftProviders[$Name] = [ordered]@{
        Name = $Name
        Test = $TestScript
        ListModels = $ListModelsScript
        Summarize = $SummarizeScript
    }
}

function Initialize-SiftProviders {
    if ($script:SiftProviders.ContainsKey('ollama')) {
        return
    }

    Register-SiftProvider -Name 'ollama' `
        -TestScript {
            param($Config)

            $status = [ordered]@{
                Available = $false
                ExecutablePath = Find-OllamaExecutable
                Reachable = $false
                BaseUrl = $Config.Ollama.BaseUrl
                Error = $null
            }

            if ($status.ExecutablePath) {
                $status.Available = $true
            }

            try {
                $response = Invoke-RestMethod -Uri ($Config.Ollama.BaseUrl.TrimEnd('/') + '/api/tags') -Method Get -TimeoutSec 3
                if ($response -and $response.models) {
                    $status.Reachable = $true
                    $status.Available = $true
                }
            }
            catch {
                $status.Error = $_.Exception.Message
            }

            [pscustomobject]$status
        } `
        -ListModelsScript {
            param($Config)

            try {
                $response = Invoke-RestMethod -Uri ($Config.Ollama.BaseUrl.TrimEnd('/') + '/api/tags') -Method Get -TimeoutSec 5
                if ($response -and $response.models) {
                    return @($response.models | ForEach-Object { $_.name })
                }
            }
            catch {
            }

            $exe = Find-OllamaExecutable
            if (-not $exe) {
                return @()
            }

            $lines = & $exe list 2>$null
            if (-not $lines) {
                return @()
            }

            $models = New-Object System.Collections.Generic.List[string]
            foreach ($line in $lines | Select-Object -Skip 1) {
                $trimmed = [string]$line
                if (-not $trimmed.Trim()) {
                    continue
                }

                $name = ($trimmed -split '\s{2,}')[0]
                if ($name) {
                    [void]$models.Add($name.Trim())
                }
            }

            return $models.ToArray()
        } `
        -SummarizeScript {
            param($Config, $Model, $Prompt)

            $body = [ordered]@{
                model = $Model
                prompt = $Prompt
                stream = $false
                options = [ordered]@{
                    temperature = 0.1
                }
            }

            $response = Invoke-RestMethod -Uri ($Config.Ollama.BaseUrl.TrimEnd('/') + '/api/generate') `
                -Method Post `
                -ContentType 'application/json' `
                -Body (ConvertTo-SiftJson -InputObject $body) `
                -TimeoutSec 120

            if (-not $response.response) {
                throw 'Ollama did not return a response body.'
            }

            return [string]$response.response
        }
}

function Get-SiftProvider {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Name
    )

    Initialize-SiftProviders
    if (-not $script:SiftProviders.ContainsKey($Name)) {
        throw "Unknown SiftKit backend: $Name"
    }

    $script:SiftProviders[$Name]
}

function Get-SiftInputText {
    param(
        [string]$Text,
        [string]$InputFile,
        [System.Collections.Generic.List[string]]$PipelineBuffer
    )

    if ($PSBoundParameters.ContainsKey('Text')) {
        return $Text
    }

    if ($PSBoundParameters.ContainsKey('InputFile')) {
        if (-not (Test-Path -LiteralPath $InputFile)) {
            throw "Input file not found: $InputFile"
        }

        return Get-Content -LiteralPath $InputFile -Raw
    }

    if ($PipelineBuffer -and $PipelineBuffer.Count -gt 0) {
        return ($PipelineBuffer -join [Environment]::NewLine)
    }

    throw 'No input text was provided.'
}

function Measure-SiftText {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Text
    )

    $normalized = $Text -replace "`r`n", "`n"
    $lines = @()
    if ($normalized.Length -gt 0) {
        $lines = $normalized -split "`n"
    }

    [pscustomobject]@{
        CharacterCount = $Text.Length
        LineCount = @($lines).Count
    }
}

function Get-SiftSummaryDecision {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Text,
        [Parameter(Mandatory = $true)]
        [string]$RiskLevel,
        [Parameter(Mandatory = $true)]
        [object]$Config
    )

    $metrics = Measure-SiftText -Text $Text
    $minCharacters = [int]$Config.Thresholds.MinCharactersForSummary
    $minLines = [int]$Config.Thresholds.MinLinesForSummary

    if ($metrics.CharacterCount -lt $minCharacters -and $metrics.LineCount -lt $minLines) {
        return [pscustomobject]@{
            ShouldSummarize = $false
            Reason = 'short-output'
            RawReviewRequired = $false
            CharacterCount = $metrics.CharacterCount
            LineCount = $metrics.LineCount
        }
    }

    if ($RiskLevel -eq 'debug' -or $RiskLevel -eq 'risky') {
        return [pscustomobject]@{
            ShouldSummarize = $true
            Reason = 'raw-first-secondary-summary'
            RawReviewRequired = $true
            CharacterCount = $metrics.CharacterCount
            LineCount = $metrics.LineCount
        }
    }

    [pscustomobject]@{
        ShouldSummarize = $true
        Reason = 'summarize'
        RawReviewRequired = $false
        CharacterCount = $metrics.CharacterCount
        LineCount = $metrics.LineCount
    }
}

function Compress-SiftRepeatedLines {
    param(
        [Parameter(Mandatory = $true)]
        [string[]]$Lines
    )

    if ($Lines.Count -eq 0) {
        return @()
    }

    $result = New-Object System.Collections.Generic.List[string]
    $current = $Lines[0]
    $count = 1

    for ($i = 1; $i -lt $Lines.Count; $i++) {
        if ($Lines[$i] -eq $current) {
            $count++
            continue
        }

        if ($count -gt 3) {
            [void]$result.Add(('{0} [repeated {1} times]' -f $current, $count))
        }
        else {
            for ($j = 0; $j -lt $count; $j++) {
                [void]$result.Add($current)
            }
        }

        $current = $Lines[$i]
        $count = 1
    }

    if ($count -gt 3) {
        [void]$result.Add(('{0} [repeated {1} times]' -f $current, $count))
    }
    else {
        for ($j = 0; $j -lt $count; $j++) {
            [void]$result.Add($current)
        }
    }

    $result.ToArray()
}

function Get-SiftErrorContextLines {
    param(
        [Parameter(Mandatory = $true)]
        [string[]]$Lines
    )

    $pattern = '(?i)(error|exception|failed|fatal|denied|timeout|traceback|panic|duplicate key|destroy)'
    $indexes = New-Object System.Collections.Generic.List[int]

    for ($i = 0; $i -lt $Lines.Count; $i++) {
        if ($Lines[$i] -match $pattern) {
            [void]$indexes.Add($i)
        }
    }

    if ($indexes.Count -eq 0) {
        return @()
    }

    $selected = New-Object System.Collections.Generic.List[string]
    $seen = @{}
    foreach ($index in $indexes) {
        $start = [Math]::Max($index - 2, 0)
        $end = [Math]::Min($index + 2, $Lines.Count - 1)
        for ($cursor = $start; $cursor -le $end; $cursor++) {
            $key = [string]$cursor
            if (-not $seen.ContainsKey($key)) {
                $seen[$key] = $true
                [void]$selected.Add($Lines[$cursor])
            }
        }
    }

    $selected.ToArray()
}

function Reduce-SiftText {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Text,
        [Parameter(Mandatory = $true)]
        [string]$ReducerProfile
    )

    if ($ReducerProfile -eq 'none') {
        return $Text
    }

    $lines = @()
    if ($Text.Length -gt 0) {
        $lines = ($Text -replace "`r`n", "`n") -split "`n"
    }

    if ($lines.Count -le 200) {
        return $Text
    }

    $compressed = Compress-SiftRepeatedLines -Lines $lines

    switch ($ReducerProfile) {
        'errors' {
            $context = Get-SiftErrorContextLines -Lines $compressed
            if ($context.Count -gt 0) {
                return ($context -join [Environment]::NewLine)
            }

            return (($compressed | Select-Object -Last 120) -join [Environment]::NewLine)
        }
        'tail' {
            return (($compressed | Select-Object -Last 160) -join [Environment]::NewLine)
        }
        'diff' {
            $diffLines = $compressed | Where-Object {
                $_ -match '^(diff --git|\+\+\+|---|@@|\+[^+]|-[^-]|index\s|rename |new file mode|deleted file mode)'
            }

            if (@($diffLines).Count -gt 0) {
                return ($diffLines -join [Environment]::NewLine)
            }

            return (($compressed | Select-Object -First 80) -join [Environment]::NewLine)
        }
        default {
            $context = Get-SiftErrorContextLines -Lines $compressed
            if ($context.Count -gt 0) {
                $head = $compressed | Select-Object -First 20
                $tail = $compressed | Select-Object -Last 40
                return (@($head) + '' + @($context) + '' + @($tail) -join [Environment]::NewLine)
            }

            return (@($compressed | Select-Object -First 40) + '' + @($compressed | Select-Object -Last 80) -join [Environment]::NewLine)
        }
    }
}

function New-SiftPrompt {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Question,
        [Parameter(Mandatory = $true)]
        [string]$InputText,
        [Parameter(Mandatory = $true)]
        [string]$Format,
        [Parameter(Mandatory = $true)]
        [string]$PolicyProfile,
        [Parameter(Mandatory = $true)]
        [bool]$RawReviewRequired
    )

    $profilePrompt = $script:SiftPromptProfiles[$PolicyProfile]
    if (-not $profilePrompt) {
        $profilePrompt = $script:SiftPromptProfiles['general']
    }

    $formatPrompt = if ($Format -eq 'json') {
        'Return only valid JSON. Do not use markdown fences.'
    }
    else {
        'Return concise plain text.'
    }

    $rawReviewPrompt = if ($RawReviewRequired) {
        'Raw-log review is still required before any risky decision. State that explicitly.'
    }
    else {
        'Keep the answer focused and factual.'
    }

@"
You are SiftKit, a conservative shell-output compressor for Codex workflows.

Rules:
- Preserve the most decisive facts.
- Prefer extraction over explanation.
- Never claim certainty beyond the input.
- If evidence is incomplete or ambiguous, say so.
- Do not suggest destructive actions.

Profile:
$profilePrompt

Output:
$formatPrompt

Risk handling:
$rawReviewPrompt

Question:
$Question

Input:
$InputText
"@
}

function Invoke-SiftProviderSummary {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Backend,
        [Parameter(Mandatory = $true)]
        [object]$Config,
        [Parameter(Mandatory = $true)]
        [string]$Model,
        [Parameter(Mandatory = $true)]
        [string]$Prompt
    )

    $provider = Get-SiftProvider -Name $Backend
    & $provider.Summarize $Config $Model $Prompt
}

function Get-SiftTimestamp {
    (Get-Date).ToString('yyyyMMdd_HHmmss')
}

function New-SiftArtifactPath {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Directory,
        [Parameter(Mandatory = $true)]
        [string]$Prefix,
        [Parameter(Mandatory = $true)]
        [string]$Extension
    )

    $safeExtension = $Extension.TrimStart('.')
    Join-Path -Path $Directory -ChildPath ('{0}_{1}.{2}' -f $Prefix, (Get-SiftTimestamp), $safeExtension)
}

function Format-SiftArgument {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Argument
    )

    if ($Argument -notmatch '[\s"]') {
        return $Argument
    }

    '"' + ($Argument -replace '"', '\"') + '"'
}

function Invoke-SiftProcess {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Command,
        [string[]]$ArgumentList = @()
    )

    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = $Command
    $psi.UseShellExecute = $false
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError = $true
    $psi.CreateNoWindow = $true

    if ($ArgumentList.Count -gt 0) {
        $psi.Arguments = (($ArgumentList | ForEach-Object { Format-SiftArgument -Argument $_ }) -join ' ')
    }

    $process = New-Object System.Diagnostics.Process
    $process.StartInfo = $psi

    [void]$process.Start()
    $stdout = $process.StandardOutput.ReadToEnd()
    $stderr = $process.StandardError.ReadToEnd()
    $process.WaitForExit()

    [pscustomobject]@{
        ExitCode = $process.ExitCode
        StdOut = $stdout
        StdErr = $stderr
        Combined = ($stdout + [Environment]::NewLine + $stderr).Trim()
    }
}

function Get-SiftCodexPolicyBlock {
@"
$($script:SiftMarkers.CodexPolicyStart)
# SiftKit default shell-output handling

Use SiftKit instead of distill for shell-output compression.

- Prefer deterministic reduction first: quiet flags, JSON output, rg, Select-String, and targeted filters.
- For large informational output, prefer `Invoke-SiftCommand` so raw logs are saved before summarization.
- For direct text or log-file summarization, use `Invoke-SiftSummary`.
- For short output, risky operations, crashes, auth issues, migrations, or exact diagnosis, inspect raw output first.
- If SiftKit returns a summary for a risky or debug command, treat it as a lossy secondary summary and review the raw log path before making strong claims.
- When reporting distilled output, say it is a summary and include the raw log path when available.

Examples:
- `Invoke-SiftCommand -Command pytest -ArgumentList '-q' -Question 'did tests pass? if not, list only failing tests'`
- `Get-Content .\build.log -Raw | Invoke-SiftSummary -Question 'extract the root exception and first relevant application frame'`

$($script:SiftMarkers.CodexPolicyEnd)
"@
}

function Get-SiftFixtureManifest {
    param(
        [string]$FixtureRoot = (Get-SiftRepoPath -RelativePath 'eval\fixtures')
    )

    $manifestPath = Join-Path -Path $FixtureRoot -ChildPath 'fixtures.json'
    ConvertFrom-SiftJsonFile -Path $manifestPath
}

function Get-SiftFixtureScore {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Summary,
        [Parameter(Mandatory = $true)]
        [object]$Fixture,
        [Parameter(Mandatory = $true)]
        [int]$SourceLength
    )

    $required = @($Fixture.RequiredTerms)
    $forbidden = @($Fixture.ForbiddenTerms)
    $matchedRequired = 0
    $matchedForbidden = 0

    foreach ($term in $required) {
        if ($term -and $Summary -match [Regex]::Escape($term)) {
            $matchedRequired++
        }
    }

    foreach ($term in $forbidden) {
        if ($term -and $Summary -match [Regex]::Escape($term)) {
            $matchedForbidden++
        }
    }

    if ($required.Count -eq 0) {
        $recall = 2
    }
    elseif ($matchedRequired -eq $required.Count) {
        $recall = 2
    }
    elseif ($matchedRequired -gt 0) {
        $recall = 1
    }
    else {
        $recall = 0
    }

    if ($matchedForbidden -eq 0) {
        $precision = 2
    }
    elseif ($matchedForbidden -lt [Math]::Max($forbidden.Count, 1)) {
        $precision = 1
    }
    else {
        $precision = 0
    }

    if ($recall -eq 2 -and $precision -eq 2) {
        $faithfulness = 2
    }
    elseif ($recall -gt 0 -and $precision -gt 0) {
        $faithfulness = 1
    }
    else {
        $faithfulness = 0
    }

    $format = 2
    if ($Fixture.Format -eq 'json') {
        try {
            $null = $Summary | ConvertFrom-Json
        }
        catch {
            $format = 0
        }
    }

    $ratio = 1
    if ($SourceLength -gt 0) {
        $ratio = [double]$Summary.Length / [double]$SourceLength
    }

    if ($ratio -le 0.6) {
        $compression = 2
    }
    elseif ($ratio -le 0.85) {
        $compression = 1
    }
    else {
        $compression = 0
    }

    [pscustomobject]@{
        Recall = $recall
        Precision = $precision
        Faithfulness = $faithfulness
        Format = $format
        Compression = $compression
        Total = ($recall + $precision + $faithfulness + $format + $compression)
        Notes = ('required matched: {0}/{1}; forbidden matched: {2}/{3}' -f $matchedRequired, $required.Count, $matchedForbidden, $forbidden.Count)
    }
}

function Install-SiftKit {
    [CmdletBinding()]
    param(
        [switch]$Force
    )

    $paths = Initialize-SiftRuntime
    $config = Get-SiftDefaultConfigObject
    $config.Paths.RuntimeRoot = $paths.RuntimeRoot
    $config.Paths.Logs = $paths.Logs
    $config.Paths.EvalFixtures = $paths.EvalFixtures
    $config.Paths.EvalResults = $paths.EvalResults
    $config.Ollama.ExecutablePath = Find-OllamaExecutable

    if ($Force -or -not (Test-Path -LiteralPath (Get-SiftConfigPath))) {
        Save-SiftConfig -Config $config
    }
    else {
        $config = Get-SiftConfig
    }

    $models = @()
    try {
        $provider = Get-SiftProvider -Name $config.Backend
        $models = @(& $provider.ListModels $config)
    }
    catch {
    }

    [pscustomobject]@{
        Installed = $true
        ConfigPath = Get-SiftConfigPath
        RuntimeRoot = $paths.RuntimeRoot
        LogsPath = $paths.Logs
        EvalResultsPath = $paths.EvalResults
        Backend = $config.Backend
        Model = $config.Model
        OllamaExecutablePath = $config.Ollama.ExecutablePath
        AvailableModels = $models
    }
}

function Test-SiftKit {
    [CmdletBinding()]
    param()

    $config = Get-SiftConfig -Ensure
    $paths = Initialize-SiftRuntime
    $provider = Get-SiftProvider -Name $config.Backend
    $providerStatus = & $provider.Test $config
    $models = @(& $provider.ListModels $config)
    $defaultModelPresent = $models -contains $config.Model

    $issues = New-Object System.Collections.Generic.List[string]
    if (-not $providerStatus.Available) {
        [void]$issues.Add('Backend is not available.')
    }
    if (-not $providerStatus.Reachable) {
        [void]$issues.Add('Ollama API is not reachable.')
    }
    if (-not $defaultModelPresent) {
        [void]$issues.Add(('Configured model not found: {0}' -f $config.Model))
    }

    [pscustomobject]@{
        Ready = ($issues.Count -eq 0)
        PowerShellVersion = $PSVersionTable.PSVersion.ToString()
        ConfigPath = Get-SiftConfigPath
        RuntimeRoot = $paths.RuntimeRoot
        LogsPath = $paths.Logs
        EvalFixturesPath = $paths.EvalFixtures
        EvalResultsPath = $paths.EvalResults
        Backend = $config.Backend
        Model = $config.Model
        OllamaExecutablePath = $providerStatus.ExecutablePath
        OllamaApiReachable = $providerStatus.Reachable
        AvailableModels = $models
        DefaultModelPresent = $defaultModelPresent
        Issues = $issues.ToArray()
    }
}

function Invoke-SiftSummary {
    [CmdletBinding(DefaultParameterSetName = 'Pipeline')]
    param(
        [Parameter(Mandatory = $true, Position = 0)]
        [string]$Question,
        [Parameter(ParameterSetName = 'Text', Mandatory = $true)]
        [string]$Text,
        [Parameter(ParameterSetName = 'File', Mandatory = $true)]
        [string]$InputFile,
        [Parameter(ParameterSetName = 'Pipeline', ValueFromPipeline = $true)]
        [string]$InputObject,
        [ValidateSet('text', 'json')]
        [string]$Format = 'text',
        [string]$Backend,
        [string]$Model,
        [ValidateSet('general', 'pass-fail', 'unique-errors', 'buried-critical', 'json-extraction', 'diff-summary', 'risky-operation')]
        [string]$PolicyProfile = 'general'
    )

    begin {
        $buffer = New-Object System.Collections.Generic.List[string]
    }

    process {
        if ($null -ne $InputObject) {
            [void]$buffer.Add([string]$InputObject)
        }
    }

    end {
        $config = Get-SiftConfig -Ensure
        if (-not $Backend) {
            $Backend = $config.Backend
        }
        if (-not $Model) {
            $Model = $config.Model
        }

        $inputText = Get-SiftInputText -Text $Text -InputFile $InputFile -PipelineBuffer $buffer
        $riskLevel = if ($PolicyProfile -eq 'risky-operation') { 'risky' } else { 'informational' }
        $decision = Get-SiftSummaryDecision -Text $inputText -RiskLevel $riskLevel -Config $config

        if (-not $decision.ShouldSummarize) {
            return [pscustomobject]@{
                WasSummarized = $false
                PolicyDecision = $decision.Reason
                Backend = $Backend
                Model = $Model
                Summary = $inputText
            }
        }

        $prompt = New-SiftPrompt -Question $Question -InputText $inputText -Format $Format -PolicyProfile $PolicyProfile -RawReviewRequired $decision.RawReviewRequired
        $summary = Invoke-SiftProviderSummary -Backend $Backend -Config $config -Model $Model -Prompt $prompt

        [pscustomobject]@{
            WasSummarized = $true
            PolicyDecision = $decision.Reason
            Backend = $Backend
            Model = $Model
            Summary = $summary.Trim()
        }
    }
}

function Invoke-SiftCommand {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Command,
        [string[]]$ArgumentList = @(),
        [string]$Question = 'Summarize the main result and any actionable failures.',
        [ValidateSet('informational', 'debug', 'risky')]
        [string]$RiskLevel = 'informational',
        [ValidateSet('smart', 'errors', 'tail', 'diff', 'none')]
        [string]$ReducerProfile = 'smart',
        [ValidateSet('text', 'json')]
        [string]$Format = 'text',
        [ValidateSet('general', 'pass-fail', 'unique-errors', 'buried-critical', 'json-extraction', 'diff-summary', 'risky-operation')]
        [string]$PolicyProfile = 'general',
        [string]$Backend,
        [string]$Model,
        [switch]$NoSummarize
    )

    $config = Get-SiftConfig -Ensure
    if (-not $Backend) {
        $Backend = $config.Backend
    }
    if (-not $Model) {
        $Model = $config.Model
    }

    $paths = Initialize-SiftRuntime
    $processResult = Invoke-SiftProcess -Command $Command -ArgumentList $ArgumentList
    $rawLogPath = New-SiftArtifactPath -Directory $paths.Logs -Prefix 'command_raw' -Extension 'log'
    Set-Content -LiteralPath $rawLogPath -Value $processResult.Combined -Encoding UTF8

    $decision = Get-SiftSummaryDecision -Text $processResult.Combined -RiskLevel $RiskLevel -Config $config
    $reducedText = Reduce-SiftText -Text $processResult.Combined -ReducerProfile $ReducerProfile
    $reducedLogPath = $null
    if ($reducedText -ne $processResult.Combined) {
        $reducedLogPath = New-SiftArtifactPath -Directory $paths.Logs -Prefix 'command_reduced' -Extension 'log'
        Set-Content -LiteralPath $reducedLogPath -Value $reducedText -Encoding UTF8
    }

    if ($NoSummarize -or -not $decision.ShouldSummarize) {
        return [pscustomobject]@{
            ExitCode = $processResult.ExitCode
            RawLogPath = $rawLogPath
            ReducedLogPath = $reducedLogPath
            WasSummarized = $false
            PolicyDecision = if ($NoSummarize) { 'no-summarize' } else { $decision.Reason }
            RawReviewRequired = $decision.RawReviewRequired
            Summary = $null
        }
    }

    $effectiveProfile = $PolicyProfile
    if (($RiskLevel -eq 'debug' -or $RiskLevel -eq 'risky') -and $PolicyProfile -eq 'general') {
        $effectiveProfile = 'risky-operation'
    }

    $summaryResult = Invoke-SiftSummary -Question $Question -Text $reducedText -Format $Format -Backend $Backend -Model $Model -PolicyProfile $effectiveProfile

    [pscustomobject]@{
        ExitCode = $processResult.ExitCode
        RawLogPath = $rawLogPath
        ReducedLogPath = $reducedLogPath
        WasSummarized = $summaryResult.WasSummarized
        PolicyDecision = $decision.Reason
        RawReviewRequired = $decision.RawReviewRequired
        Summary = $summaryResult.Summary
    }
}

function Invoke-SiftEvaluation {
    [CmdletBinding()]
    param(
        [string]$FixtureRoot = (Get-SiftRepoPath -RelativePath 'eval\fixtures'),
        [string[]]$RealLogPath = @(),
        [string]$Backend,
        [string]$Model
    )

    $config = Get-SiftConfig -Ensure
    if (-not $Backend) {
        $Backend = $config.Backend
    }
    if (-not $Model) {
        $Model = $config.Model
    }

    $manifest = Get-SiftFixtureManifest -FixtureRoot $FixtureRoot
    $results = New-Object System.Collections.Generic.List[object]

    foreach ($fixture in $manifest) {
        $path = Join-Path -Path $FixtureRoot -ChildPath $fixture.File
        $source = Get-Content -LiteralPath $path -Raw
        $summaryResult = Invoke-SiftSummary -Question $fixture.Question -Text $source -Format $fixture.Format -Backend $Backend -Model $Model -PolicyProfile $fixture.PolicyProfile
        $score = Get-SiftFixtureScore -Summary $summaryResult.Summary -Fixture $fixture -SourceLength $source.Length

        [void]$results.Add([pscustomobject]@{
            Name = $fixture.Name
            SourcePath = $path
            WasSummarized = $summaryResult.WasSummarized
            Summary = $summaryResult.Summary
            Recall = $score.Recall
            Precision = $score.Precision
            Faithfulness = $score.Faithfulness
            Format = $score.Format
            Compression = $score.Compression
            Total = $score.Total
            Notes = $score.Notes
        })
    }

    foreach ($path in $RealLogPath) {
        if (-not (Test-Path -LiteralPath $path)) {
            continue
        }

        $source = Get-Content -LiteralPath $path -Raw
        $summaryResult = Invoke-SiftSummary -Question 'Summarize the important result in up to 5 bullets, preserving only the decisive facts.' `
            -Text $source -Format 'text' -Backend $Backend -Model $Model -PolicyProfile 'general'

        [void]$results.Add([pscustomobject]@{
            Name = ('RealLog:{0}' -f (Split-Path -Path $path -Leaf))
            SourcePath = $path
            WasSummarized = $summaryResult.WasSummarized
            Summary = $summaryResult.Summary
            Recall = $null
            Precision = $null
            Faithfulness = $null
            Format = $null
            Compression = $null
            Total = $null
            Notes = 'Manual review required for real-log scoring.'
        })
    }

    $resultArray = $results.ToArray()
    $resultPath = New-SiftArtifactPath -Directory $config.Paths.EvalResults -Prefix 'evaluation' -Extension 'json'
    Set-Content -LiteralPath $resultPath -Value (ConvertTo-SiftJson -InputObject $resultArray) -Encoding UTF8

    [pscustomobject]@{
        Backend = $Backend
        Model = $Model
        ResultPath = $resultPath
        Results = $resultArray
    }
}

function Install-SiftCodexPolicy {
    [CmdletBinding()]
    param(
        [string]$CodexHome = (Join-Path -Path $env:USERPROFILE -ChildPath '.codex'),
        [switch]$Force
    )

    $null = New-SiftDirectory -Path $CodexHome
    $agentsPath = Join-Path -Path $CodexHome -ChildPath 'AGENTS.md'
    $policyBlock = Get-SiftCodexPolicyBlock
    $existing = ''

    if (Test-Path -LiteralPath $agentsPath) {
        $existing = Get-Content -LiteralPath $agentsPath -Raw
        if ($existing -match [Regex]::Escape($script:SiftMarkers.CodexPolicyStart)) {
            $updated = [Regex]::Replace(
                $existing,
                [Regex]::Escape($script:SiftMarkers.CodexPolicyStart) + '.*?' + [Regex]::Escape($script:SiftMarkers.CodexPolicyEnd),
                [System.Text.RegularExpressions.MatchEvaluator]{ param($match) $policyBlock },
                [System.Text.RegularExpressions.RegexOptions]::Singleline
            )
        }
        elseif ($Force -or $existing.Trim()) {
            $updated = $existing.TrimEnd() + [Environment]::NewLine + [Environment]::NewLine + $policyBlock + [Environment]::NewLine
        }
        else {
            $updated = $policyBlock + [Environment]::NewLine
        }
    }
    else {
        $updated = $policyBlock + [Environment]::NewLine
    }

    Set-Content -LiteralPath $agentsPath -Value $updated -Encoding UTF8

    [pscustomobject]@{
        AgentsPath = $agentsPath
        Installed = $true
    }
}

function Install-SiftKitShellIntegration {
    [CmdletBinding()]
    param(
        [string]$BinDir = (Join-Path -Path $env:USERPROFILE -ChildPath 'bin'),
        [string]$ModuleInstallRoot = (Join-Path -Path ([Environment]::GetFolderPath('MyDocuments')) -ChildPath 'WindowsPowerShell\Modules'),
        [switch]$Force
    )

    $moduleSource = Get-SiftKitRoot
    $repoRoot = Split-Path -Path $moduleSource -Parent
    $moduleTarget = Join-Path -Path $ModuleInstallRoot -ChildPath 'SiftKit'
    $binSource = Join-Path -Path $repoRoot -ChildPath 'bin'

    $null = New-SiftDirectory -Path $ModuleInstallRoot
    $null = New-SiftDirectory -Path $BinDir

    if (Test-Path -LiteralPath $moduleTarget) {
        if ($Force) {
            Remove-Item -LiteralPath $moduleTarget -Recurse -Force
        }
    }

    $null = New-SiftDirectory -Path $moduleTarget
    Get-ChildItem -LiteralPath $moduleSource -Force | Copy-Item -Destination $moduleTarget -Recurse -Force
    Copy-Item -LiteralPath (Join-Path -Path $binSource -ChildPath 'siftkit.ps1') -Destination (Join-Path -Path $BinDir -ChildPath 'siftkit.ps1') -Force
    Copy-Item -LiteralPath (Join-Path -Path $binSource -ChildPath 'siftkit.cmd') -Destination (Join-Path -Path $BinDir -ChildPath 'siftkit.cmd') -Force

    [pscustomobject]@{
        Installed = $true
        ModulePath = $moduleTarget
        BinDir = $BinDir
        PowerShellShim = Join-Path -Path $BinDir -ChildPath 'siftkit.ps1'
        CmdShim = Join-Path -Path $BinDir -ChildPath 'siftkit.cmd'
        PathHint = 'Add the bin directory to PATH to run siftkit globally.'
    }
}

Export-ModuleMember -Function Install-SiftKit, Test-SiftKit, Invoke-SiftSummary, Invoke-SiftCommand, Invoke-SiftEvaluation, Install-SiftCodexPolicy, Install-SiftKitShellIntegration
