#!/usr/bin/env node

const { spawn } = require('node:child_process');
const { randomUUID } = require('node:crypto');
const http = require('node:http');
const https = require('node:https');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const {
  loadConfig,
  getConfiguredModel,
  getConfiguredLlamaBaseUrl,
  getConfiguredLlamaNumCtx,
  getConfiguredLlamaSetting,
  getEffectiveInputCharactersPerContextToken,
} = require('../dist/config.js');
const { listLlamaCppModels, countLlamaCppTokens } = require('../dist/providers/llama-cpp.js');

const DEFAULT_MAX_TURNS = 45;
const DEFAULT_MAX_INVALID_RESPONSES = 3;
const DEFAULT_TIMEOUT_MS = 120000;
const MIN_TOOL_CALLS_BEFORE_FINISH = 5;
const THINKING_BUFFER_RATIO = 0.15;
const THINKING_BUFFER_MIN_TOKENS = 4000;
const PER_TOOL_RESULT_RATIO = 0.10;
const DEFAULT_REPO_SEARCH_REQUEST_MAX_TOKENS = 2048;
const ZERO_OUTPUT_FORCE_THRESHOLD = 10;
const FORCED_FINISH_MAX_ATTEMPTS = 3;
const TRANSIENT_PROVIDER_ERROR_CODES = ['ECONNRESET', 'ETIMEDOUT', 'EPIPE', 'ECONNABORTED'];
const NON_THINKING_FINISH_FOLLOWUP_PROMPT = 'Are you sure you have enough evidence and did not get tunnel-visioned?';
const COMPRESSED_HISTORY_MARKER = '[COMPRESSED HISTORICAL EVIDENCE]';
const BASELINE_IGNORED_NAMES = ['.git', 'node_modules', '.node_modules'];
const ANSI_RED = '\x1b[31m';
const ANSI_RESET = '\x1b[0m';
let nextLlamaCppSlotId = 0;

function createJsonlLogger(filePath) {
  const target = path.resolve(filePath);
  fs.mkdirSync(path.dirname(target), { recursive: true });
  fs.writeFileSync(target, '', 'utf8');
  return {
    path: target,
    write(event) {
      fs.appendFileSync(
        target,
        `${JSON.stringify({ at: new Date().toISOString(), ...event })}\n`,
        'utf8'
      );
    },
  };
}

/**
 * @typedef {{ action: 'tool', tool_name: 'run_repo_cmd', args: { command: string } }} ToolAction
 * @typedef {{ action: 'finish', output: string, confidence?: number }} FinishAction
 * @typedef {ToolAction | FinishAction} MockPlannerAction
 * @typedef {{
 *   runId: string,
 *   model: string,
 *   tasks: TaskResult[],
 *   totals: {
 *     tasks: number,
 *     passed: number,
 *     failed: number,
 *     commandsExecuted: number,
 *     safetyRejects: number,
 *     invalidResponses: number,
 *   },
 *   verdict: 'pass' | 'fail',
 *   failureReasons: string[],
 * }} Scorecard
 * @typedef {{
 *   id: string,
 *   question: string,
 *   signals: string[],
 * }} TaskDefinition
 * @typedef {{
 *   command: string,
 *   safe: boolean,
 *   reason: string | null,
 *   exitCode: number | null,
 *   output: string,
 * }} TaskCommand
 * @typedef {{
 *   id: string,
 *   question: string,
 *   reason: 'finish' | 'max_turns' | 'invalid_response_limit' | 'mock_responses_exhausted' | 'forced_finish_attempt_limit',
 *   turnsUsed: number,
 *   safetyRejects: number,
 *   invalidResponses: number,
 *   commands: TaskCommand[],
 *   finalOutput: string,
 *   passed: boolean,
 *   missingSignals: string[],
 * }} TaskResult
 */

const TOOL_DEFINITIONS = [
  {
    type: 'function',
    function: {
      name: 'run_repo_cmd',
      description: 'Run one read-only repo command to inspect files. Command must be non-mutating.',
      parameters: {
        type: 'object',
        properties: {
          command: { type: 'string' },
        },
        required: ['command'],
      },
    },
  },
];

function allocateLlamaCppSlotId(config) {
  const configuredSlots = getConfiguredLlamaSetting(config || {}, 'ParallelSlots');
  const slotCount = Math.max(1, Math.floor(Number(configuredSlots) || 1));
  const slotId = nextLlamaCppSlotId % slotCount;
  nextLlamaCppSlotId = (nextLlamaCppSlotId + 1) % slotCount;
  return slotId;
}

const TASK_PACK = [
  {
    id: 'symbol-location',
    question: 'Find where buildPlannerToolDefinitions is defined. Return file path and nearby signature text.',
    signals: ['src[\\\\/]summary\\.ts', 'buildPlannerToolDefinitions'],
  },
  {
    id: 'call-path',
    question: 'Find what function invokes invokePlannerMode in summary flow. Return caller function name.',
    signals: ['invokePlannerMode', 'invokeSummaryCore'],
  },
  {
    id: 'config-runtime-key',
    question: 'Find where getConfiguredLlamaNumCtx is defined and at least one usage site.',
    signals: ['src[\\\\/]config\\.ts', 'getConfiguredLlamaNumCtx'],
  },
  {
    id: 'planner-tools',
    question: 'Find planner tool names in SiftKit and list them.',
    signals: ['find_text', 'read_lines', 'json_filter'],
  },
  {
    id: 'debug-artifacts',
    question: 'Find where planner debug dumps are written and show filename pattern.',
    signals: ['planner_debug_', 'getRuntimeLogsPath'],
  },
];

function serializeNetworkError(error) {
  const source = error && typeof error === 'object' ? error : {};
  const message = source instanceof Error ? source.message : String(source || '');
  const code = typeof source.code === 'string' ? source.code : null;
  const errno = typeof source.errno === 'number' || typeof source.errno === 'string'
    ? source.errno
    : null;
  const syscall = typeof source.syscall === 'string' ? source.syscall : null;
  const address = typeof source.address === 'string' ? source.address : null;
  const port = Number.isFinite(Number(source.port)) ? Number(source.port) : null;
  return {
    message: message || 'unknown error',
    code,
    errno,
    syscall,
    address,
    port,
  };
}

function buildProviderErrorMessage(options, details) {
  const stage = String(options.stage || 'unknown');
  const method = String(options.method || 'GET').toUpperCase();
  const url = String(options.url || '');
  const parts = [
    `provider request failed stage=${stage}`,
    `method=${method}`,
    `url=${url}`,
    `error=${details.message}`,
  ];
  if (details.code) {
    parts.push(`code=${details.code}`);
  }
  if (details.errno !== null) {
    parts.push(`errno=${details.errno}`);
  }
  if (details.syscall) {
    parts.push(`syscall=${details.syscall}`);
  }
  if (details.address) {
    parts.push(`address=${details.address}`);
  }
  if (details.port !== null) {
    parts.push(`port=${details.port}`);
  }
  return parts.join(' ');
}

function writeRedConsoleLine(message) {
  if (!message) {
    return;
  }
  process.stderr.write(`${ANSI_RED}${String(message)}${ANSI_RESET}\n`);
}

function isTransientProviderError(error) {
  const message = String(
    error instanceof Error ? error.message : (error ?? '')
  ).toUpperCase();
  return TRANSIENT_PROVIDER_ERROR_CODES.some((code) => message.includes(code));
}

function requestJson(options) {
  return new Promise((resolve, reject) => {
    const startedAt = Date.now();
    let settled = false;
    const target = new URL(options.url);
    const method = String(options.method || 'GET').toUpperCase();
    const stage = String(options.stage || 'provider_request');
    const urlPath = `${target.pathname}${target.search}`;
    options.logger?.write({
      kind: 'provider_request_start',
      stage,
      method,
      url: options.url,
      path: urlPath,
    });
    const transport = target.protocol === 'https:' ? https : http;
    const request = transport.request(
      {
        protocol: target.protocol,
        hostname: target.hostname,
        port: target.port || (target.protocol === 'https:' ? 443 : 80),
        path: urlPath,
        method,
        headers: options.body ? {
          'Content-Type': 'application/json',
          'Content-Length': Buffer.byteLength(options.body, 'utf8'),
        } : undefined,
      },
      (response) => {
        let responseText = '';
        response.setEncoding('utf8');
        response.on('data', (chunk) => {
          responseText += chunk;
        });
        response.on('end', () => {
          if (settled) {
            return;
          }
          settled = true;
          const elapsedMs = Date.now() - startedAt;
          options.logger?.write({
            kind: 'provider_request_done',
            stage,
            method,
            url: options.url,
            path: urlPath,
            statusCode: response.statusCode || 0,
            elapsedMs,
          });
          if (!responseText.trim()) {
            resolve({ statusCode: response.statusCode || 0, body: {}, rawText: '' });
            return;
          }
          try {
            resolve({
              statusCode: response.statusCode || 0,
              body: JSON.parse(responseText),
              rawText: responseText,
            });
          } catch (error) {
            options.logger?.write({
              kind: 'provider_request_error',
              stage,
              method,
              url: options.url,
              path: urlPath,
              elapsedMs,
              error: serializeNetworkError(error),
            });
            reject(error);
          }
        });
      }
    );

    request.on('error', (error) => {
      if (settled) {
        return;
      }
      settled = true;
      const elapsedMs = Date.now() - startedAt;
      const serializedError = serializeNetworkError(error);
      options.logger?.write({
        kind: 'provider_request_error',
        stage,
        method,
        url: options.url,
        path: urlPath,
        elapsedMs,
        error: serializedError,
      });
      reject(new Error(buildProviderErrorMessage({
        stage,
        method,
        url: options.url,
      }, serializedError)));
    });

    request.setTimeout(options.timeoutMs, () => {
      request.destroy(new Error(`Request timed out after ${options.timeoutMs} ms.`));
    });

    if (options.body) {
      request.write(options.body);
    }
    request.end();
  });
}

function stripCodeFence(text) {
  const trimmed = String(text || '').trim();
  const match = /^```(?:json)?\s*([\s\S]*?)\s*```$/u.exec(trimmed);
  return match ? match[1].trim() : trimmed;
}

function plannerGrammar() {
  return [
    'root ::= tool_action | finish_action',
    'tool_action ::= "{" ws "\\"action\\"" ws ":" ws "\\"tool\\"" ws "," ws "\\"tool_name\\"" ws ":" ws "\\"run_repo_cmd\\"" ws "," ws "\\"args\\"" ws ":" ws args_obj ws "}"',
    'args_obj ::= "{" ws "\\"command\\"" ws ":" ws string ws "}"',
    'finish_action ::= "{" ws "\\"action\\"" ws ":" ws "\\"finish\\"" ws "," ws "\\"output\\"" ws ":" ws string (ws "," ws "\\"confidence\\"" ws ":" ws number)? ws "}"',
    'number ::= "-"? int frac? exp?',
    'int ::= "0" | [1-9] [0-9]*',
    'frac ::= "." [0-9]+',
    'exp ::= [eE] [+-]? [0-9]+',
    'string ::= "\\"" char* "\\""',
    'char ::= [^"\\\\\\x7F\\x00-\\x1F] | "\\\\" escape',
    'escape ::= ["\\\\/bfnrt] | "u" hex hex hex hex',
    'hex ::= [0-9a-fA-F]',
    'ws ::= [ \\t\\n\\r]*',
  ].join('\n');
}

function finishValidationGrammar() {
  return [
    'root ::= object',
    'object ::= "{" ws "\\"verdict\\"" ws ":" ws verdict ws "," ws "\\"reason\\"" ws ":" ws string ws "}"',
    'verdict ::= "\\"pass\\"" | "\\"fail\\""',
    'string ::= "\\"" char* "\\""',
    'char ::= [^"\\\\\\x7F\\x00-\\x1F] | "\\\\" escape',
    'escape ::= ["\\\\/bfnrt] | "u" hex hex hex hex',
    'hex ::= [0-9a-fA-F]',
    'ws ::= [ \\t\\n\\r]*',
  ].join('\n');
}

function actionFromToolCall(choice) {
  const toolCall = choice?.message?.tool_calls?.[0]
    ?? choice?.tool_calls?.[0]
    ?? choice?.message?.function_call
    ?? choice?.function_call;
  const name = typeof toolCall?.function?.name === 'string'
    ? toolCall.function.name
    : typeof toolCall?.name === 'string'
      ? toolCall.name
      : '';
  const rawArgs = toolCall?.function?.arguments ?? toolCall?.arguments;
  if (name !== 'run_repo_cmd') {
    return null;
  }
  let args = rawArgs;
  if (typeof rawArgs === 'string') {
    try {
      args = JSON.parse(rawArgs);
    } catch {
      return null;
    }
  }
  if (!args || typeof args !== 'object' || Array.isArray(args) || typeof args.command !== 'string') {
    return null;
  }
  return JSON.stringify({
    action: 'tool',
    tool_name: 'run_repo_cmd',
    args: { command: args.command },
  });
}

function normalizeProviderText(value) {
  if (typeof value === 'string') {
    return value.trim();
  }
  if (Array.isArray(value)) {
    return value
      .map((part) => {
        if (typeof part === 'string') {
          return part;
        }
        if (part && typeof part === 'object' && typeof part.text === 'string') {
          return part.text;
        }
        return '';
      })
      .join('')
      .trim();
  }
  return '';
}

function getUsageNumber(value) {
  return Number.isFinite(value) && Number(value) >= 0 ? Number(value) : null;
}

function getPromptUsageFromResponseBody(body) {
  const usage = body && typeof body === 'object' ? body.usage : null;
  const timings = body && typeof body === 'object' ? body.timings : null;
  const verboseTimings = body && typeof body === 'object' && body.__verbose && typeof body.__verbose === 'object'
    ? body.__verbose.timings
    : null;
  const promptTokens = getUsageNumber(usage?.prompt_tokens);
  const promptCacheTokens = getUsageNumber(timings?.cache_n)
    ?? getUsageNumber(verboseTimings?.cache_n)
    ?? getUsageNumber(usage?.prompt_tokens_details?.cached_tokens)
    ?? getUsageNumber(usage?.input_tokens_details?.cached_tokens);
  const promptEvalTokens = getUsageNumber(timings?.prompt_n)
    ?? getUsageNumber(verboseTimings?.prompt_n)
    ?? (promptTokens !== null && promptCacheTokens !== null ? Math.max(promptTokens - promptCacheTokens, 0) : null);
  return {
    promptTokens,
    promptCacheTokens,
    promptEvalTokens,
  };
}

async function requestPlannerAction(options) {
  if (Array.isArray(options.mockResponses)) {
    const index = options.mockResponseIndex || 0;
    if (index >= options.mockResponses.length) {
      return { text: '', thinkingText: '', mockExhausted: true };
    }
    return {
      text: options.mockResponses[index],
      thinkingText: '',
      mockExhausted: false,
      nextMockResponseIndex: index + 1,
    };
  }

  const response = await requestJson({
    url: `${options.baseUrl.replace(/\/$/u, '')}/v1/chat/completions`,
    method: 'POST',
    timeoutMs: options.timeoutMs,
    stage: 'planner_action',
    logger: options.logger || null,
    body: JSON.stringify({
      model: options.model,
      messages: options.messages,
      cache_prompt: true,
      ...(Number.isInteger(options.slotId) ? { id_slot: Number(options.slotId) } : {}),
      temperature: 0.1,
      top_p: 0.95,
      max_tokens: options.requestMaxTokens,
      tools: TOOL_DEFINITIONS,
      chat_template_kwargs: {
        enable_thinking: options.thinkingEnabled !== false,
      },
      extra_body: {
        grammar: plannerGrammar(),
        ...(options.thinkingEnabled === false ? { reasoning_budget: 0 } : {}),
      },
    }),
  });

  if (response.statusCode < 200 || response.statusCode >= 300) {
    const detail = response.rawText ? `: ${response.rawText.slice(0, 400)}` : '.';
    throw new Error(`llama.cpp planner request failed with HTTP ${response.statusCode}${detail}`);
  }

  const firstChoice = response.body?.choices?.[0] || {};
  const text = normalizeProviderText(firstChoice?.message?.content)
    || normalizeProviderText(firstChoice?.text)
    || '';
  const thinkingText = normalizeProviderText(firstChoice?.message?.reasoning_content)
    || normalizeProviderText(firstChoice?.reasoning_content)
    || '';
  const synthesized = actionFromToolCall(firstChoice);
  const promptUsage = getPromptUsageFromResponseBody(response.body);
  return {
    text: (text || synthesized || '').trim(),
    thinkingText,
    mockExhausted: false,
    promptTokens: promptUsage.promptTokens,
    promptCacheTokens: promptUsage.promptCacheTokens,
    promptEvalTokens: promptUsage.promptEvalTokens,
  };
}

function requestPlannerActionStreaming(options, onThinkingDelta) {
  if (Array.isArray(options.mockResponses)) {
    return requestPlannerAction(options);
  }

  const bodyJson = JSON.stringify({
    model: options.model,
    messages: options.messages,
    cache_prompt: true,
    ...(Number.isInteger(options.slotId) ? { id_slot: Number(options.slotId) } : {}),
    temperature: 0.1,
    top_p: 0.95,
    max_tokens: options.requestMaxTokens,
    stream: true,
    tools: TOOL_DEFINITIONS,
    chat_template_kwargs: {
      enable_thinking: options.thinkingEnabled !== false,
    },
    extra_body: {
      grammar: plannerGrammar(),
      ...(options.thinkingEnabled === false ? { reasoning_budget: 0 } : {}),
    },
  });

  const target = new URL(`${options.baseUrl.replace(/\/$/u, '')}/v1/chat/completions`);
  const transport = target.protocol === 'https:' ? https : http;

  return new Promise((resolve, reject) => {
    const startedAt = Date.now();
    const stage = 'planner_action';
    const method = 'POST';
    const urlPath = `${target.pathname}${target.search}`;
    options.logger?.write({
      kind: 'provider_request_start',
      stage,
      method,
      url: target.toString(),
      path: urlPath,
    });
    let settled = false;
    const request = transport.request({
      protocol: target.protocol,
      hostname: target.hostname,
      port: target.port || (target.protocol === 'https:' ? 443 : 80),
      path: urlPath,
      method,
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(bodyJson, 'utf8'),
      },
    }, (response) => {
      if ((response.statusCode || 0) >= 400) {
        let body = '';
        response.setEncoding('utf8');
        response.on('data', (chunk) => { body += chunk; });
        response.on('end', () => {
          if (!settled) {
            settled = true;
            const serialized = serializeNetworkError(new Error(
              `llama.cpp planner stream failed with HTTP ${response.statusCode}${body.trim() ? `: ${body.trim().slice(0, 400)}` : '.'}`
            ));
            options.logger?.write({
              kind: 'provider_request_error',
              stage,
              method,
              url: target.toString(),
              path: urlPath,
              elapsedMs: Date.now() - startedAt,
              error: serialized,
            });
            reject(new Error(buildProviderErrorMessage({
              stage,
              method,
              url: target.toString(),
            }, serialized)));
          }
        });
        return;
      }

      let rawBuffer = '';
      let contentText = '';
      let thinkingText = '';
      let toolCalls = [];
      let promptTokens = null;
      let promptCacheTokens = null;
      let promptEvalTokens = null;
      response.setEncoding('utf8');
      response.on('data', (chunk) => {
        rawBuffer += chunk;
        let boundary = rawBuffer.indexOf('\n\n');
        while (boundary >= 0) {
          const packet = rawBuffer.slice(0, boundary);
          rawBuffer = rawBuffer.slice(boundary + 2);
          boundary = rawBuffer.indexOf('\n\n');
          const lines = packet.split(/\r?\n/gu).map((l) => l.trim()).filter(Boolean);
          const dataLine = lines.find((l) => l.startsWith('data:'));
          if (!dataLine) continue;
          const dataValue = dataLine.slice(5).trim();
          if (dataValue === '[DONE]') continue;
          try {
            const parsed = JSON.parse(dataValue);
            const parsedPromptUsage = getPromptUsageFromResponseBody(parsed);
            if (parsedPromptUsage.promptTokens !== null) {
              promptTokens = parsedPromptUsage.promptTokens;
            }
            if (parsedPromptUsage.promptCacheTokens !== null) {
              promptCacheTokens = parsedPromptUsage.promptCacheTokens;
            }
            if (parsedPromptUsage.promptEvalTokens !== null) {
              promptEvalTokens = parsedPromptUsage.promptEvalTokens;
            }
            const choice = Array.isArray(parsed?.choices) ? parsed.choices[0] : null;
            const delta = choice?.delta && typeof choice.delta === 'object' ? choice.delta : {};
            const message = choice?.message && typeof choice.message === 'object' ? choice.message : {};
            const deltaThinking = typeof delta.reasoning_content === 'string' ? delta.reasoning_content
              : typeof message.reasoning_content === 'string' ? message.reasoning_content
              : '';
            const deltaContent = typeof delta.content === 'string' ? delta.content : '';
            if (delta.tool_calls && Array.isArray(delta.tool_calls)) {
              for (const tc of delta.tool_calls) {
                const idx = tc.index ?? 0;
                if (!toolCalls[idx]) toolCalls[idx] = { name: '', arguments: '' };
                if (tc.function?.name) toolCalls[idx].name += tc.function.name;
                if (tc.function?.arguments) toolCalls[idx].arguments += tc.function.arguments;
              }
            }
            if (deltaThinking) {
              thinkingText += deltaThinking;
              if (typeof onThinkingDelta === 'function') {
                onThinkingDelta(thinkingText);
              }
            }
            if (deltaContent) {
              contentText += deltaContent;
            }
          } catch { /* ignore malformed chunks */ }
        }
      });
      response.on('end', () => {
        if (settled) return;
        settled = true;
        options.logger?.write({
          kind: 'provider_request_done',
          stage,
          method,
          url: target.toString(),
          path: urlPath,
          statusCode: response.statusCode || 0,
          elapsedMs: Date.now() - startedAt,
        });
        let synthesized = null;
        if (toolCalls.length > 0 && toolCalls[0].name === 'run_repo_cmd') {
          let args;
          try { args = JSON.parse(toolCalls[0].arguments); } catch { args = null; }
          if (args && typeof args.command === 'string') {
            synthesized = JSON.stringify({ action: 'tool', tool_name: 'run_repo_cmd', args: { command: args.command } });
          }
        }
        const text = contentText.trim() || synthesized || '';
        resolve({
          text: text.trim ? text.trim() : text,
          thinkingText: thinkingText.trim(),
          mockExhausted: false,
          promptTokens,
          promptCacheTokens,
          promptEvalTokens,
        });
      });
    });

    request.on('error', (err) => {
      if (!settled) {
        settled = true;
        const serialized = serializeNetworkError(err);
        options.logger?.write({
          kind: 'provider_request_error',
          stage,
          method,
          url: target.toString(),
          path: urlPath,
          elapsedMs: Date.now() - startedAt,
          error: serialized,
        });
        reject(new Error(buildProviderErrorMessage({
          stage,
          method,
          url: target.toString(),
        }, serialized)));
      }
    });
    request.setTimeout(options.timeoutMs, () => {
      request.destroy(new Error(`Request timed out after ${options.timeoutMs} ms.`));
    });
    request.write(bodyJson);
    request.end();
  });
}

function parseFinishValidationResponse(text) {
  let parsed;
  try {
    parsed = JSON.parse(stripCodeFence(text));
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    throw new Error(`Provider returned an invalid finish validation payload: ${message}`);
  }

  const verdict = typeof parsed.verdict === 'string' ? parsed.verdict.trim().toLowerCase() : '';
  if (verdict !== 'pass' && verdict !== 'fail') {
    throw new Error('Provider returned an invalid finish validation payload.');
  }
  if (typeof parsed.reason !== 'string' || !parsed.reason.trim()) {
    throw new Error('Provider returned an invalid finish validation payload.');
  }
  return {
    verdict,
    reason: parsed.reason.trim(),
  };
}

function buildFinishValidationPrompt(options) {
  const sections = [
    'You are validating a repo-search answer against gathered evidence.',
    'Return exactly one JSON object: {"verdict":"pass"|"fail","reason":"<short reason>"}',
    'Question: is the answer valid? is the answer well supported/justified?',
    '',
    `Task: ${options.question}`,
    `Proposed answer: ${options.finalOutput}`,
    '',
    'Evidence from tool calls and inserted results:',
    options.evidenceText || '[none]',
  ];
  return sections.join('\n');
}

async function requestFinishValidation(options) {
  if (Array.isArray(options.mockResponses)) {
    const index = options.mockResponseIndex || 0;
    if (index >= options.mockResponses.length) {
      return { text: '', thinkingText: '', mockExhausted: true };
    }
    return {
      text: options.mockResponses[index],
      thinkingText: '',
      mockExhausted: false,
      nextMockResponseIndex: index + 1,
    };
  }

  const response = await requestJson({
    url: `${options.baseUrl.replace(/\/$/u, '')}/v1/chat/completions`,
    method: 'POST',
    timeoutMs: options.timeoutMs,
    stage: 'finish_validation',
    logger: options.logger || null,
    body: JSON.stringify({
      model: options.model,
      messages: [{ role: 'user', content: options.prompt }],
      temperature: 0.1,
      top_p: 0.95,
      max_tokens: options.requestMaxTokens,
      chat_template_kwargs: {
        enable_thinking: true,
      },
      extra_body: {
        grammar: finishValidationGrammar(),
      },
    }),
  });

  if (response.statusCode < 200 || response.statusCode >= 300) {
    const detail = response.rawText ? `: ${response.rawText.slice(0, 400)}` : '.';
    throw new Error(`llama.cpp finish validation request failed with HTTP ${response.statusCode}${detail}`);
  }

  const firstChoice = response.body?.choices?.[0] || {};
  const text = normalizeProviderText(firstChoice?.message?.content)
    || normalizeProviderText(firstChoice?.text)
    || '';
  const thinkingText = normalizeProviderText(firstChoice?.message?.reasoning_content)
    || normalizeProviderText(firstChoice?.reasoning_content)
    || '';
  const promptUsage = getPromptUsageFromResponseBody(response.body);
  return {
    text: text.trim(),
    thinkingText,
    mockExhausted: false,
    promptTokens: promptUsage.promptTokens,
    promptCacheTokens: promptUsage.promptCacheTokens,
    promptEvalTokens: promptUsage.promptEvalTokens,
  };
}

function buildTerminalSynthesisPrompt(options) {
  const evidenceText = options.history.length > 0
    ? options.history.map((item) => `Command: ${item.command}\nResult: ${item.resultText}`).join('\n\n')
    : '[none]';
  return [
    'You are finalizing a repo-search run that terminated before finish validation passed.',
    'Write a best-effort final answer from available evidence.',
    'Rules:',
    '- Be explicit about uncertainty.',
    '- Include concrete file:line evidence when present.',
    '- Keep it concise and directly answer the task question.',
    '',
    `Task: ${options.question}`,
    `Termination reason: ${options.reason}`,
    '',
    'Evidence from tool calls and inserted results:',
    evidenceText,
  ].join('\n');
}

function buildTerminalSynthesisFallback(options) {
  const lines = [];
  if (options.commands.length > 0) {
    for (let index = options.commands.length - 1; index >= 0; index -= 1) {
      const command = options.commands[index];
      const output = String(command.output || '').trim();
      if (!output) {
        continue;
      }
      const singleLine = output.split(/\r?\n/u).find((line) => line.trim()) || '';
      if (singleLine) {
        lines.push(`Latest evidence (${command.command}): ${singleLine}`);
      }
      if (lines.length >= 2) {
        break;
      }
    }
  }
  if (lines.length === 0) {
    lines.push('No usable evidence was captured from tool calls.');
  }
  return [
    `Best-effort result (terminated: ${options.reason}).`,
    ...lines,
  ].join('\n');
}

async function requestTerminalSynthesis(options) {
  if (Array.isArray(options.mockResponses)) {
    const index = options.mockResponseIndex || 0;
    if (index >= options.mockResponses.length) {
      return { text: '', thinkingText: '', mockExhausted: true };
    }
    return {
      text: options.mockResponses[index],
      thinkingText: '',
      mockExhausted: false,
      nextMockResponseIndex: index + 1,
    };
  }

  const response = await requestJson({
    url: `${options.baseUrl.replace(/\/$/u, '')}/v1/chat/completions`,
    method: 'POST',
    timeoutMs: options.timeoutMs,
    stage: 'terminal_synthesis',
    logger: options.logger || null,
    body: JSON.stringify({
      model: options.model,
      messages: [{ role: 'user', content: options.prompt }],
      temperature: 0.1,
      top_p: 0.95,
      max_tokens: options.requestMaxTokens,
      chat_template_kwargs: {
        enable_thinking: true,
      },
    }),
  });

  if (response.statusCode < 200 || response.statusCode >= 300) {
    const detail = response.rawText ? `: ${response.rawText.slice(0, 400)}` : '.';
    throw new Error(`llama.cpp terminal synthesis request failed with HTTP ${response.statusCode}${detail}`);
  }

  const firstChoice = response.body?.choices?.[0] || {};
  const text = normalizeProviderText(firstChoice?.message?.content)
    || normalizeProviderText(firstChoice?.text)
    || '';
  const thinkingText = normalizeProviderText(firstChoice?.message?.reasoning_content)
    || normalizeProviderText(firstChoice?.reasoning_content)
    || '';
  const promptUsage = getPromptUsageFromResponseBody(response.body);
  return {
    text: text.trim(),
    thinkingText,
    mockExhausted: false,
    promptTokens: promptUsage.promptTokens,
    promptCacheTokens: promptUsage.promptCacheTokens,
    promptEvalTokens: promptUsage.promptEvalTokens,
  };
}

function parsePlannerAction(text) {
  const normalized = stripCodeFence(text);
  let parsed;
  try {
    parsed = JSON.parse(normalized);
  } catch (error) {
    const recovered = tryRecoverMalformedPlannerToolAction(normalized);
    if (recovered) {
      return recovered;
    }
    const message = error instanceof Error ? error.message : String(error);
    throw new Error(`Provider returned an invalid planner payload: ${message}`);
  }

  const action = typeof parsed.action === 'string' ? parsed.action.trim().toLowerCase() : '';
  if (action === 'tool') {
    if (
      parsed.tool_name !== 'run_repo_cmd'
      || !parsed.args
      || typeof parsed.args !== 'object'
      || Array.isArray(parsed.args)
      || typeof parsed.args.command !== 'string'
      || !parsed.args.command.trim()
    ) {
      throw new Error('Provider returned an invalid planner tool action.');
    }
    return {
      action: 'tool',
      tool_name: 'run_repo_cmd',
      args: { command: parsed.args.command.trim() },
    };
  }

  if (action === 'finish') {
    if (typeof parsed.output !== 'string' || !parsed.output.trim()) {
      throw new Error('Provider returned an invalid planner finish action.');
    }
    const confidence = Number(parsed.confidence);
    return Number.isFinite(confidence)
      ? { action: 'finish', output: parsed.output.trim(), confidence }
      : { action: 'finish', output: parsed.output.trim() };
  }

  throw new Error('Provider returned an unknown planner action.');
}

function decodeJsonStringLoose(raw) {
  let decoded = '';
  for (let i = 0; i < raw.length; i += 1) {
    const ch = raw[i];
    if (ch !== '\\') {
      decoded += ch;
      continue;
    }
    if (i + 1 >= raw.length) {
      decoded += '\\';
      continue;
    }
    const next = raw[i + 1];
    i += 1;
    if (next === '"' || next === '\\' || next === '/') {
      decoded += next;
      continue;
    }
    if (next === 'b') {
      decoded += '\b';
      continue;
    }
    if (next === 'f') {
      decoded += '\f';
      continue;
    }
    if (next === 'n') {
      decoded += '\n';
      continue;
    }
    if (next === 'r') {
      decoded += '\r';
      continue;
    }
    if (next === 't') {
      decoded += '\t';
      continue;
    }
    if (next === 'u' && i + 4 < raw.length) {
      const hex = raw.slice(i + 1, i + 5);
      if (/^[0-9a-fA-F]{4}$/u.test(hex)) {
        decoded += String.fromCharCode(Number.parseInt(hex, 16));
        i += 4;
        continue;
      }
    }
    // Keep going for non-standard escape sequences by dropping the backslash.
    decoded += next;
  }
  return decoded;
}

function tryRecoverMalformedPlannerToolAction(rawText) {
  if (
    !/"action"\s*:\s*"tool"/iu.test(rawText)
    || !/"tool_name"\s*:\s*"run_repo_cmd"/iu.test(rawText)
  ) {
    return null;
  }
  const commandMatch = /"command"\s*:\s*"([\s\S]*)"\s*\}\s*\}\s*$/u.exec(rawText);
  if (!commandMatch || typeof commandMatch[1] !== 'string') {
    return null;
  }
  const recoveredCommand = decodeJsonStringLoose(commandMatch[1]).trim();
  if (!recoveredCommand) {
    return null;
  }
  return {
    action: 'tool',
    tool_name: 'run_repo_cmd',
    args: { command: recoveredCommand },
  };
}

function hasBlockedOperator(command) {
  return /&&|\|\||[;`]/u.test(command);
}

function splitTopLevelPipes(command) {
  const parts = [];
  let current = '';
  let inSingle = false;
  let inDouble = false;
  for (let i = 0; i < command.length; i += 1) {
    const ch = command[i];
    if (ch === "'" && !inDouble) {
      inSingle = !inSingle;
      current += ch;
      continue;
    }
    if (ch === '"' && !inSingle) {
      inDouble = !inDouble;
      current += ch;
      continue;
    }
    if (ch === '|' && !inSingle && !inDouble) {
      parts.push(current.trim());
      current = '';
      continue;
    }
    current += ch;
  }
  parts.push(current.trim());
  return parts.filter(Boolean);
}

function normalizeRepoRoot(repoRoot) {
  return String(repoRoot || '')
    .replace(/\//gu, '\\')
    .replace(/\\+$/u, '')
    .toLowerCase();
}

function tokenizeSegment(segment) {
  const tokens = [];
  let current = '';
  let inSingle = false;
  let inDouble = false;
  for (let i = 0; i < segment.length; i += 1) {
    const ch = segment[i];
    if (ch === "'" && !inDouble) {
      inSingle = !inSingle;
      continue;
    }
    if (ch === '"' && !inSingle) {
      inDouble = !inDouble;
      continue;
    }
    if (!inSingle && !inDouble && /\s/u.test(ch)) {
      if (current) {
        tokens.push(current);
        current = '';
      }
      continue;
    }
    current += ch;
  }
  if (current) {
    tokens.push(current);
  }
  return tokens;
}

function normalizePathCandidate(value) {
  return String(value || '').trim().replace(/^['"]|['"]$/gu, '');
}

function isPathOutsideRepo(pathCandidate, normalizedRepoRoot) {
  const token = normalizePathCandidate(pathCandidate).replace(/\//gu, '\\');
  if (!token) {
    return false;
  }
  if (/\.\.[\\/]/u.test(token)) {
    return true;
  }
  if (/^\\\\[a-z0-9_.-]+\\/iu.test(token)) {
    return true;
  }
  if (/^[a-zA-Z]:\\/u.test(token)) {
    return token.toLowerCase().startsWith(normalizedRepoRoot) === false;
  }
  return false;
}

function collectOptionPaths(tokens, optionConfig) {
  const paths = [];
  const command = (tokens[0] || '').toLowerCase();
  if (!command) {
    return paths;
  }
  const config = optionConfig[command];
  if (!config) {
    return paths;
  }
  const {
    valueOptions,
    pathOptions,
    positionalArePaths,
    rgPatternOptions,
  } = config;
  let index = 1;
  let rgPatternProvidedByOption = false;
  let rgPatternConsumed = false;

  while (index < tokens.length) {
    const token = tokens[index];
    if (token === '--') {
      index += 1;
      break;
    }
    if (token.startsWith('-')) {
      const normalized = token.toLowerCase();
      if (valueOptions.has(normalized)) {
        const next = tokens[index + 1];
        if (next) {
          if (pathOptions.has(normalized)) {
            paths.push(next);
          }
          if (command === 'rg' && rgPatternOptions.has(normalized)) {
            rgPatternProvidedByOption = true;
          }
        }
        index += 2;
        continue;
      }
      index += 1;
      continue;
    }
    if (command === 'rg') {
      if (!rgPatternProvidedByOption && !rgPatternConsumed) {
        rgPatternConsumed = true;
      } else {
        paths.push(token);
      }
    } else if (positionalArePaths) {
      paths.push(token);
    }
    index += 1;
  }

  for (; index < tokens.length; index += 1) {
    const token = tokens[index];
    if (command === 'rg') {
      if (!rgPatternProvidedByOption && !rgPatternConsumed) {
        rgPatternConsumed = true;
      } else {
        paths.push(token);
      }
    } else if (positionalArePaths) {
      paths.push(token);
    }
  }
  return paths;
}

function referencesPathOutsideRepo(command, repoRoot) {
  const normalizedRepoRoot = normalizeRepoRoot(repoRoot);
  if (!normalizedRepoRoot) {
    return false;
  }

  const pathOptionConfig = {
    rg: {
      valueOptions: new Set([
        '-e', '--regexp',
        '-f', '--file',
        '-g', '--glob',
        '--iglob',
        '-t', '--type',
        '-t', '--type-not',
        '--type-add',
        '--type-clear',
        '-m', '--max-count',
        '-A', '-B', '-C',
        '--context',
        '--max-filesize',
        '--engine',
        '--encoding',
        '--sort',
        '--sortr',
        '--threads',
      ]),
      pathOptions: new Set(['-f', '--file']),
      positionalArePaths: true,
      rgPatternOptions: new Set(['-e', '--regexp']),
    },
    'get-content': {
      valueOptions: new Set(['-path', '-literalpath', '-encoding', '-delimiter', '-filter', '-include', '-exclude', '-raw', '-readcount', '-totalcount', '-tail']),
      pathOptions: new Set(['-path', '-literalpath']),
      positionalArePaths: true,
      rgPatternOptions: new Set(),
    },
    'get-childitem': {
      valueOptions: new Set(['-path', '-literalpath', '-filter', '-include', '-exclude', '-name', '-file', '-directory', '-recurse', '-depth', '-force']),
      pathOptions: new Set(['-path', '-literalpath']),
      positionalArePaths: true,
      rgPatternOptions: new Set(),
    },
    ls: {
      valueOptions: new Set(['-path', '-literalpath', '-filter', '-include', '-exclude', '-name', '-file', '-directory', '-recurse', '-depth', '-force']),
      pathOptions: new Set(['-path', '-literalpath']),
      positionalArePaths: true,
      rgPatternOptions: new Set(),
    },
    'select-string': {
      valueOptions: new Set(['-path', '-literalpath', '-pattern', '-simplematch', '-encoding', '-caseSensitive', '-allmatches', '-notmatch']),
      pathOptions: new Set(['-path', '-literalpath']),
      positionalArePaths: false,
      rgPatternOptions: new Set(),
    },
  };

  const segments = splitTopLevelPipes(command);
  for (const segment of segments) {
    const tokens = tokenizeSegment(segment);
    const pathCandidates = collectOptionPaths(tokens, pathOptionConfig);
    for (const candidate of pathCandidates) {
      if (isPathOutsideRepo(candidate, normalizedRepoRoot)) {
        return true;
      }
    }
  }
  return false;
}

function hasFileRedirection(command) {
  return /(^|\s)(?:\d?>|>>|<|\*>)($|\s)/u.test(command);
}

function getFirstToken(segment) {
  return (segment.trim().split(/\s+/u)[0] || '').toLowerCase();
}

function getGitSubcommand(segment) {
  const tokens = segment.trim().split(/\s+/u).filter(Boolean);
  let i = 1;
  while (i < tokens.length) {
    const token = tokens[i].toLowerCase();
    if (token === '-c' || token === '--git-dir' || token === '--work-tree') {
      i += 2;
      continue;
    }
    if (token.startsWith('-')) {
      i += 1;
      continue;
    }
    return token;
  }
  return '';
}

function evaluateSegmentSafety(segment, allowedCommands) {
  const token = getFirstToken(segment);
  if (!allowedCommands.has(token)) {
    return { safe: false, reason: `command is not in allowlist: ${token}` };
  }
  if (token === 'git') {
    const subcommand = getGitSubcommand(segment);
    if (subcommand !== 'status' && subcommand !== 'log' && subcommand !== 'show') {
      return { safe: false, reason: 'git subcommand is not in read-only allowlist' };
    }
  }
  return { safe: true, reason: null };
}

function evaluateCommandSafety(command, repoRoot = '') {
  const trimmed = String(command || '').trim();
  if (!trimmed) {
    return { safe: false, reason: 'empty command' };
  }
  if (referencesPathOutsideRepo(trimmed, repoRoot)) {
    return { safe: false, reason: 'command must stay within the caller repository scope' };
  }
  if (hasBlockedOperator(trimmed)) {
    return { safe: false, reason: 'shell chaining/redirection is not allowed' };
  }
  if (hasFileRedirection(trimmed)) {
    return { safe: false, reason: 'file redirection is not allowed' };
  }
  if (/\b(rm|del|mv|cp|move-item|copy-item|remove-item|set-content|add-content|out-file|export-[a-z0-9_-]+|tee-object|curl|wget|invoke-webrequest|invoke-restmethod|start-process)\b/iu.test(trimmed)) {
    return { safe: false, reason: 'destructive, file-writing, or network command is not allowed' };
  }

  const segments = splitTopLevelPipes(trimmed);
  const producerCommands = new Set([
    'rg',
    'get-content',
    'get-childitem',
    'select-string',
    'git',
    'pwd',
    'ls',
  ]);
  const pipeCommands = new Set([
    'select-object',
    'select-string',
    'where-object',
    'sort-object',
    'group-object',
    'measure-object',
    'foreach-object',
    'format-table',
    'format-list',
    'out-string',
    'convertto-json',
    'convertfrom-json',
    'get-unique',
    'join-string',
  ]);
  const allAllowedCommands = new Set([...producerCommands, ...pipeCommands]);

  if (segments.length === 1) {
    return evaluateSegmentSafety(segments[0], allAllowedCommands);
  }

  for (const segment of segments) {
    const result = evaluateSegmentSafety(segment, allAllowedCommands);
    if (!result.safe) {
      return result;
    }
    if (
      /\bforeach-object\b/iu.test(segment)
      && /\b(set-content|add-content|out-file|export-[a-z0-9_-]+|tee-object|remove-item|move-item|copy-item|rename-item|invoke-webrequest|invoke-restmethod|start-process)\b/iu.test(segment)
    ) {
      return { safe: false, reason: 'ForEach-Object must be read-only' };
    }
  }

  return { safe: true, reason: null };
}

function extractRgPattern(commandStr) {
  const tokens = tokenizeSegment(commandStr);
  if (!tokens.length || tokens[0].toLowerCase() !== 'rg') {
    return null;
  }
  const rgValueOptions = new Set([
    '-e', '--regexp', '-f', '--file', '-g', '--glob', '--iglob',
    '-t', '--type', '--type-not', '--type-add', '--type-clear',
    '-m', '--max-count', '-A', '-B', '-C', '--context',
    '--max-filesize', '--engine', '--encoding', '--sort', '--sortr', '--threads',
  ]);
  const rgPatternOptions = new Set(['-e', '--regexp']);
  let patternByOption = false;
  let index = 1;
  while (index < tokens.length) {
    const token = tokens[index];
    if (token === '--') {
      index += 1;
      break;
    }
    if (token.startsWith('-')) {
      const normalized = token.toLowerCase();
      if (rgValueOptions.has(normalized)) {
        if (rgPatternOptions.has(normalized)) {
          patternByOption = true;
        }
        index += 2;
        continue;
      }
      index += 1;
      continue;
    }
    if (!patternByOption) {
      return token;
    }
    index += 1;
  }
  if (index < tokens.length && !patternByOption) {
    return tokens[index];
  }
  return null;
}

function looksLikeWindowsPathLiteral(pattern) {
  return /[a-zA-Z]:\\/u.test(pattern);
}

function rewriteRgWithFixedStrings(commandStr, pattern) {
  const hasFixedFlag = /(?:^|\s)(?:-F|--fixed-strings)(?:\s|$)/u.test(commandStr);
  if (hasFixedFlag) {
    return null;
  }
  const alternatives = pattern.split('|').filter(Boolean);
  if (alternatives.length <= 1) {
    const escapedPattern = pattern.replace(/"/gu, '\\"');
    return commandStr.replace(
      `"${pattern}"`, `"${escapedPattern}"`
    ).replace(/^(rg\s)/iu, '$1-F ');
  }
  const quotedAlternatives = alternatives.map((alt) => `-e "${alt.replace(/"/gu, '\\"')}"`).join(' ');
  const withoutPattern = commandStr.replace(
    new RegExp(`(["'])${pattern.replace(/[.*+?^${}()|[\]\\]/gu, '\\$&')}\\1`),
    ''
  ).replace(/^(rg)\s+/iu, `$1 -F ${quotedAlternatives} `).replace(/\s{2,}/gu, ' ').trim();
  return withoutPattern;
}

function normalizePathForComparison(value) {
  return String(value || '').replace(/\//gu, '\\').toLowerCase();
}

function extractIgnoreNameFromGitignoreLine(line) {
  const trimmed = String(line || '').trim();
  if (!trimmed || trimmed.startsWith('#') || trimmed.startsWith('!')) {
    return '';
  }
  const normalized = trimmed
    .replace(/\\/gu, '/')
    .replace(/^\/+/u, '')
    .replace(/\/+$/u, '');
  if (!normalized || /[*?\[\]]/u.test(normalized)) {
    return '';
  }
  const firstSegment = normalized.split('/').filter(Boolean)[0] || '';
  if (!firstSegment || firstSegment === '.' || firstSegment === '..') {
    return '';
  }
  return firstSegment;
}

function buildIgnorePolicy(repoRoot) {
  if (!repoRoot) {
    return {
      names: [],
      namesLower: new Set(),
    };
  }

  const names = [];
  const seen = new Set();
  const addName = (value) => {
    const token = String(value || '').trim();
    if (!token) return;
    const key = token.toLowerCase();
    if (seen.has(key)) return;
    seen.add(key);
    names.push(token);
  };

  for (const baseline of BASELINE_IGNORED_NAMES) {
    addName(baseline);
  }

  if (repoRoot) {
    const gitignorePath = path.join(repoRoot, '.gitignore');
    try {
      if (fs.existsSync(gitignorePath)) {
        const lines = fs.readFileSync(gitignorePath, 'utf8').split(/\r?\n/gu);
        for (const line of lines) {
          const name = extractIgnoreNameFromGitignoreLine(line);
          if (name) {
            addName(name);
          }
        }
      }
    } catch {
      // Ignore policy is best-effort.
    }
  }

  return {
    names,
    namesLower: new Set(names.map((name) => name.toLowerCase())),
  };
}

function hasIgnoreDisablingRgFlag(command) {
  return /(?:^|\s)(?:-u|-uu|-uuu)(?:\s|$)|(?:^|\s)--no-ignore(?:-[a-z]+)*(?:\s|$)/iu.test(command);
}

function rgAlreadyHasIgnoreGlob(command, ignoreName) {
  const escaped = ignoreName.replace(/[.*+?^${}()|[\]\\]/gu, '\\$&');
  return new RegExp(`(?:^|\\s)(?:-g|--glob)\\s+["'][^"']*${escaped}[^"']*["']`, 'iu').test(command);
}

function appendToFirstSegment(command, addition) {
  const segments = splitTopLevelPipes(command);
  if (!segments.length) {
    return command;
  }
  segments[0] = `${segments[0]} ${addition}`.trim();
  return segments.join(' | ');
}

function extractPathsForCommandSegment(segment, commandName) {
  const configByCommand = {
    'get-content': {
      valueOptions: new Set(['-path', '-literalpath', '-encoding', '-delimiter', '-filter', '-include', '-exclude', '-raw', '-readcount', '-totalcount', '-tail']),
      pathOptions: new Set(['-path', '-literalpath']),
      positionalArePaths: true,
      rgPatternOptions: new Set(),
    },
    'select-string': {
      valueOptions: new Set(['-path', '-literalpath', '-pattern', '-simplematch', '-encoding', '-caseSensitive', '-allmatches', '-notmatch']),
      pathOptions: new Set(['-path', '-literalpath']),
      positionalArePaths: false,
      rgPatternOptions: new Set(),
    },
  };
  const config = configByCommand[commandName];
  if (!config) {
    return [];
  }
  return collectOptionPaths(tokenizeSegment(segment), { [commandName]: config });
}

function pathIsIgnoredByPolicy(pathCandidate, ignorePolicy, repoRoot) {
  if (!ignorePolicy || !ignorePolicy.namesLower || !pathCandidate) {
    return false;
  }
  const normalizedRepoRoot = normalizePathForComparison(repoRoot).replace(/\\+$/u, '');
  let normalizedPath = normalizePathCandidate(pathCandidate).replace(/\//gu, '\\');
  if (!normalizedPath) {
    return false;
  }
  if (normalizedRepoRoot && /^[a-zA-Z]:\\/u.test(normalizedPath)) {
    const candidateLower = normalizePathForComparison(normalizedPath);
    if (candidateLower.startsWith(normalizedRepoRoot)) {
      normalizedPath = normalizedPath.slice(normalizedRepoRoot.length).replace(/^\\+/u, '');
    }
  }
  const segments = normalizedPath.split(/[\\/]+/u).filter(Boolean);
  for (const segment of segments) {
    if (/[*?\[\]]/u.test(segment)) {
      continue;
    }
    if (ignorePolicy.namesLower.has(segment.toLowerCase())) {
      return true;
    }
  }
  return false;
}

function normalizePlannerCommand(command, options = {}) {
  const trimmed = String(command || '').trim();
  if (!trimmed) {
    return { command: trimmed, rewritten: false, note: '' };
  }
  const ignorePolicy = options.ignorePolicy || buildIgnorePolicy(options.repoRoot);
  const commandToken = getFirstToken(trimmed);

  let current = trimmed;
  let wasRewritten = false;
  let notes = [];

  if (commandToken === 'rg') {
    if (hasIgnoreDisablingRgFlag(current)) {
      return {
        command: current,
        rewritten: false,
        note: '',
        rejected: true,
        rejectedReason: 'ignore-disabling rg flags are not allowed',
      };
    }

    const unsupportedTypeMap = { tsx: 'ts', jsx: 'js' };
    const typeMatches = [...current.matchAll(/(?:^|\s)--type\s+(\S+)/giu)];
    const unsupportedTypes = typeMatches
      .map((m) => m[1].toLowerCase())
      .filter((t) => t in unsupportedTypeMap);

    if (unsupportedTypes.length > 0) {
      const allTypes = typeMatches.map((m) => m[1].toLowerCase());
      const finalTypes = new Set();
      for (const t of allTypes) {
        finalTypes.add(unsupportedTypeMap[t] || t);
      }
      current = current.replace(/\s--type\s+\S+/giu, '');
      for (const t of finalTypes) {
        current = `${current} --type ${t}`;
      }
      current = current.trim();
      wasRewritten = true;
      notes.push(`rewrote unsupported --type ${unsupportedTypes.join(', ')} to valid types`);
    }

    const rgPattern = extractRgPattern(current);
    if (rgPattern && looksLikeWindowsPathLiteral(rgPattern)) {
      const rewritten = rewriteRgWithFixedStrings(current, rgPattern);
      if (rewritten) {
        current = rewritten;
        wasRewritten = true;
        notes.push('added -F for Windows path literal pattern');
      }
    }

    if (Array.isArray(ignorePolicy.names) && ignorePolicy.names.length > 0) {
      const missingNames = ignorePolicy.names.filter((name) => !rgAlreadyHasIgnoreGlob(current, name));
      if (missingNames.length > 0) {
        const globArgs = missingNames
          .map((name) => `--glob "!**/${name.replace(/"/gu, '\\"')}/**"`)
          .join(' ');
        current = `${current} ${globArgs}`.trim();
        notes.push('added ignore globs from ignore policy');
        wasRewritten = true;
      }
    }
  } else if (commandToken === 'get-childitem' || commandToken === 'ls') {
    if (Array.isArray(ignorePolicy.names) && ignorePolicy.names.length > 0 && !/(?:^|\s)-exclude(?:\s|$)/iu.test(current)) {
      current = appendToFirstSegment(current, `-Exclude ${ignorePolicy.names.join(',')}`);
      notes.push('added -Exclude from ignore policy');
      wasRewritten = true;
    }
  } else if (commandToken === 'select-string') {
    const hasPathOption = /(?:^|\s)-(?:path|literalpath)(?:\s|$)/iu.test(current);
    if (
      hasPathOption
      && Array.isArray(ignorePolicy.names)
      && ignorePolicy.names.length > 0
      && !/(?:^|\s)-exclude(?:\s|$)/iu.test(current)
    ) {
      current = appendToFirstSegment(current, `-Exclude ${ignorePolicy.names.join(',')}`);
      notes.push('added -Exclude from ignore policy');
      wasRewritten = true;
    }
  } else if (commandToken === 'get-content') {
    const segments = splitTopLevelPipes(current);
    for (const segment of segments) {
      if (getFirstToken(segment) !== 'get-content') {
        continue;
      }
      const pathCandidates = extractPathsForCommandSegment(segment, 'get-content');
      if (pathCandidates.some((candidate) => pathIsIgnoredByPolicy(candidate, ignorePolicy, options.repoRoot))) {
        return {
          command: current,
          rewritten: false,
          note: '',
          rejected: true,
          rejectedReason: 'command targets a path ignored by policy',
        };
      }
    }
  }

  if (!wasRewritten) {
    return { command: current, rewritten: false, note: '' };
  }
  return {
    command: current,
    rewritten: true,
    note: `note: ${notes.join('; ')}; ran '${current}' instead`,
  };
}

function isSearchNoMatchExit(command, exitCode) {
  if (exitCode !== 1) return false;
  const trimmed = command.trimStart();
  return /^(rg|grep|egrep|fgrep|diff|find)\b/u.test(trimmed);
}

function executeRepoCommand(command, repoRoot, mockCommandResults) {
  if (mockCommandResults && Object.prototype.hasOwnProperty.call(mockCommandResults, command)) {
    const result = mockCommandResults[command];
    const delayMs = Number(result.delayMs ?? 0);
    return new Promise((resolve) => {
      const complete = () => resolve({
        exitCode: Number(result.exitCode ?? 1),
        output: `${String(result.stdout || '')}${String(result.stderr || '')}`.trim(),
      });
      if (Number.isFinite(delayMs) && delayMs > 0) {
        setTimeout(complete, delayMs);
      } else {
        complete();
      }
    });
  }

  return new Promise((resolve) => {
    const child = spawn(
      'powershell.exe',
      ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-Command', command],
      {
        cwd: repoRoot,
        windowsHide: true,
        stdio: ['ignore', 'pipe', 'pipe'],
      }
    );
    let stdout = '';
    let stderr = '';
    let spawnError = null;
    child.stdout.setEncoding('utf8');
    child.stderr.setEncoding('utf8');
    child.stdout.on('data', (chunk) => {
      stdout += String(chunk);
    });
    child.stderr.on('data', (chunk) => {
      stderr += String(chunk);
    });
    child.on('error', (error) => {
      spawnError = error;
    });
    child.on('close', (code) => {
      const outputParts = [];
      if (spawnError) {
        const errorCode = typeof spawnError.code === 'string' ? spawnError.code : 'unknown';
        const message = spawnError instanceof Error ? spawnError.message : String(spawnError);
        outputParts.push(`spawn_error=${errorCode} message=${message}`);
      }
      const textOutput = `${stdout}${stderr}`.trim();
      if (textOutput) {
        outputParts.push(textOutput);
      }
      resolve({
        exitCode: typeof code === 'number' ? code : (spawnError ? 126 : 1),
        output: outputParts.join('\n').trim(),
      });
    });
  });
}

function readAgentsMd(repoRoot) {
  if (!repoRoot) return '';
  const agentsPath = path.join(repoRoot, 'agents.md');
  try {
    if (fs.existsSync(agentsPath)) {
      const content = fs.readFileSync(agentsPath, 'utf8').trim();
      if (content) return content;
    }
  } catch { /* ignore read errors */ }
  return '';
}

function buildTaskSystemPrompt(repoRoot) {
  const agentsContent = readAgentsMd(repoRoot);
  return [
    'You are running as a repo-search planner.',
    'Return exactly one JSON action per turn.',
    'Allowed tool: {"action":"tool","tool_name":"run_repo_cmd","args":{"command":"..."}}',
    'Finish format: {"action":"finish","output":"...","confidence":0.0-1.0}',
    '',
    'You are a repository search agent. Your job is to answer the task using concrete repository evidence from tool calls.',
    '',
    'Core behavior:',
    '- Prioritize factual, file-grounded conclusions over speculation.',
    '- Treat "no evidence of X found" as a valid outcome when supported by comprehensive search.',
    '- Never fabricate file paths, line numbers, commands, or findings.',
    '',
    'Evidence rules:',
    '- Every substantive claim must be backed by concrete evidence from executed commands.',
    '- Prefer production source evidence over tests, coverage, generated artifacts, or docs unless explicitly requested.',
    '- If evidence is weak, partial, or ambiguous, explicitly say so.',
    '',
    'Search discipline:',
    '- Use iterative searches and targeted file inspection.',
    '- Avoid repeating failed commands.',
    '- Adjust strategy when searches are too broad, noisy, or low-signal.',
    '- Keep commands efficient and focused on the task objective.',
    '',
    'Final response requirements:',
    '- Always produce a final answer, even if incomplete.',
    '- If evidence is sufficient: give a direct verdict and provide file:line evidence with brief justification.',
    '- If evidence is insufficient: explicitly state insufficiency, summarize searches and findings, identify blockers/gaps, and provide a best-effort conclusion with clear uncertainty.',
    '',
    'Output style:',
    '- Concise, structured, and directly tied to the question.',
    '- Include concrete file:line references when available.',
    '- Distinguish clearly between confirmed evidence, reasonable inference, and unknown/not proven.',
    '',
    'Return exactly one JSON action per turn.',
    'Allowed tool action: {"action":"tool","tool_name":"run_repo_cmd","args":{"command":"..."}}',
    'Finish action format: {"action":"finish","output":"...","confidence":0.0-1.0}',
    '',
    'Rules:',
    '- Use only read-only commands.',
    '- This is a Windows machine so stick to PowerShell-valid commands only.',
    '- Prefer rg for search.',
    '- Ignored paths from `.gitignore` are auto-filtered by runtime policy.',
    '- One command per turn.',
    '- Finish when you have enough evidence.',
    '- Minimum depth rule: do at least 5 tool-call turns before finishing.',
    '- If you try to finish before 5 tool-call turns, you will be told: "that was a shallow search, there might be more hidden references/usages. Dive deeper".',
    '',
    'Command selection guide (Windows/PowerShell):',
    '- For broad multi-file keyword/code search: use `rg -n "<pattern>" <path>`',
    '- For filename discovery across repo: use `rg --files`',
    '- For listing directories/files in a path: use `Get-ChildItem <path>` (or `ls`)',
    '- For reading a specific file section: use `Get-Content <file>` (optionally with `| Select-Object -First N` or `-Skip N -First M`)',
    'Single-file read strategy:',
    '- Start with `rg -n` to find anchors.',
    '- Then read a larger section in one call (`-First` / `-Skip -First`), not many tiny windows.',
    '- Prefer `Get-Content <file> -Raw` for full-file inspection when manageable.',
    '- If one file has already been sampled multiple times, switch strategy (new anchor search or different file) before more reads.',
    '- Do not issue multiple consecutive reads of the same file with only small `-Skip/-First` changes.',
    '- If a command returns an output token-allocation error, switch to stronger anchors (symbol/function/regex) instead of repeatedly shrinking tiny windows.',
    '- For quick repo state context: use `git status --short`',
    '- For inspecting commit/content history: use `git log` or `git show`',
    '- For current directory context: use `pwd`',
    '',
    'JSON action examples:',
    '{"action":"tool","tool_name":"run_repo_cmd","args":{"command":"rg -n \\"buildPlannerToolDefinitions\\" src\\\\summary.ts"}}',
    '{"action":"tool","tool_name":"run_repo_cmd","args":{"command":"rg -n \\"getConfiguredLlamaNumCtx\\" src tests"}}',
    '{"action":"tool","tool_name":"run_repo_cmd","args":{"command":"rg --files"}}',
    '{"action":"tool","tool_name":"run_repo_cmd","args":{"command":"Get-ChildItem src -Recurse -Filter *.ts"}}',
    '{"action":"tool","tool_name":"run_repo_cmd","args":{"command":"Get-Content src\\\\summary.ts | Select-Object -First 240"}}',
    '{"action":"tool","tool_name":"run_repo_cmd","args":{"command":"rg -n \\"invokePlannerMode\\" src\\\\summary.ts"}}',
    '{"action":"tool","tool_name":"run_repo_cmd","args":{"command":"Get-Content src\\\\summary.ts | Select-Object -Skip 860 -First 240"}}',
    '{"action":"tool","tool_name":"run_repo_cmd","args":{"command":"git status --short"}}',
    '{"action":"finish","output":"Found definition in src/config.ts and usage sites in src/summary.ts.","confidence":0.93}',
    '',
    'Do not use Unix-only commands/flags:',
    '- `ls -la`',
    '- `head`, `find`, `xargs`, `grep`',
    '- `rg --type-all`',
    '',
    'What not to do (examples):',
    '- Do not start with coverage/test-only noise first (for example `rg -n "buildFullGraph" coverage`).',
    '- Do not run the same failed command again without changing it.',
    '- Do not claim mutations from read-only operations like `.map`, `.filter`, or `.length`.',
    '- Do not answer without concrete `file:line` evidence.',
    '- Do not search outside the repo root path.',
    '- Invalid tool usage example: `{"action":"tool","tool_name":"read_lines","args":{"path":"src/app.ts"}}`.',
    '- Invalid args example: `{"action":"tool","tool_name":"run_repo_cmd","args":{"cmd":"rg -n \\"x\\" src"}}`.',
    '- Invalid args example: `{"action":"tool","tool_name":"run_repo_cmd","args":{}}`.',
    '- Note: `--type tsx` and `--type jsx` are auto-corrected to `--type ts` and `--type js` respectively.',
    '- Invalid command parameter example: `{"action":"tool","tool_name":"run_repo_cmd","args":{"command":"rg -n \\"x\\" src; del file.txt"}}`.',
    '- Invalid command parameter example: `{"action":"tool","tool_name":"run_repo_cmd","args":{"command":"Get-Content src\\\\x.ts | Out-File out.txt"}}`.',
    ...(agentsContent ? ['', '--- agents.md (project-specific instructions) ---', '', agentsContent] : []),
  ].join('\n');
}

function buildTaskInitialUserPrompt(question) {
  return `Task: ${question}`;
}

function buildRepoSearchAssistantToolMessage(command, toolCallId) {
  return {
    role: 'assistant',
    content: '',
    tool_calls: [
      {
        id: toolCallId,
        type: 'function',
        function: {
          name: 'run_repo_cmd',
          arguments: JSON.stringify({ command }),
        },
      },
    ],
  };
}

function renderTaskTranscript(messages) {
  return messages.map((message) => {
    const sections = [`[${String(message.role || 'unknown')}]`];
    if (typeof message.content === 'string' && message.content) {
      sections.push(message.content);
    }
    if (Array.isArray(message.tool_calls)) {
      for (const toolCall of message.tool_calls) {
        sections.push(JSON.stringify({
          id: toolCall.id || null,
          type: toolCall.type || 'function',
          function: {
            name: toolCall.function?.name || '',
            arguments: toolCall.function?.arguments || {},
          },
        }));
      }
    }
    if (typeof message.tool_call_id === 'string' && message.tool_call_id) {
      sections.push(`tool_call_id=${message.tool_call_id}`);
    }
    return sections.join('\n');
  }).join('\n\n');
}

function evaluateTaskSignals(task, evidenceText) {
  const missingSignals = [];
  for (const signal of task.signals) {
    const regex = new RegExp(signal, 'iu');
    if (!regex.test(evidenceText)) {
      missingSignals.push(signal);
    }
  }
  return {
    passed: missingSignals.length === 0,
    missingSignals,
  };
}

function estimateTokenCount(config, text) {
  const charsPerToken = config
    ? Math.max(Number(getEffectiveInputCharactersPerContextToken(config) || 4), 0.1)
    : 4;
  return Math.max(1, Math.ceil(String(text || '').length / charsPerToken));
}

function resolveRepoSearchRequestMaxTokens(options = {}) {
  const explicitMaxTokens = Number(options.requestMaxTokens);
  if (Number.isFinite(explicitMaxTokens) && explicitMaxTokens > 0) {
    return Math.floor(explicitMaxTokens);
  }
  const configuredMaxTokens = Number(getConfiguredLlamaSetting(options.config || {}, 'MaxTokens'));
  if (Number.isFinite(configuredMaxTokens) && configuredMaxTokens > 0) {
    return Math.floor(Math.min(configuredMaxTokens, DEFAULT_REPO_SEARCH_REQUEST_MAX_TOKENS));
  }
  return DEFAULT_REPO_SEARCH_REQUEST_MAX_TOKENS;
}

async function countTokensWithFallback(config, text) {
  try {
    const tokenCount = await countLlamaCppTokens(config, text);
    if (Number.isFinite(tokenCount) && Number(tokenCount) > 0) {
      return Number(tokenCount);
    }
  } catch {
    // Fall back to estimate below.
  }
  return estimateTokenCount(config, text);
}

async function preflightPlannerPromptBudget(options = {}) {
  const totalContextTokens = Math.max(1, Number(options.totalContextTokens || 0));
  const thinkingBufferTokens = Math.max(0, Number(options.thinkingBufferTokens || 0));
  const requestMaxTokens = Math.max(0, Number(options.requestMaxTokens || 0));
  const promptText = typeof options.prompt === 'string'
    ? options.prompt
    : renderTaskTranscript(Array.isArray(options.messages) ? options.messages : []);
  const promptTokenCount = await countTokensWithFallback(options.config, promptText);
  const maxPromptBudget = Math.max(totalContextTokens - thinkingBufferTokens - requestMaxTokens, 0);
  const overflowTokens = Math.max(promptTokenCount - maxPromptBudget, 0);
  return {
    ok: overflowTokens === 0,
    promptTokenCount,
    maxPromptBudget,
    overflowTokens,
  };
}

function summarizeMessageForCompaction(message) {
  if (!message || typeof message !== 'object') {
    return '';
  }
  const role = String(message.role || 'unknown');
  const content = typeof message.content === 'string'
    ? message.content.replace(/\s+/gu, ' ').trim()
    : '';
  const trimmedContent = content.length > 220 ? `${content.slice(0, 220)}...` : content;
  const toolCallCount = Array.isArray(message.tool_calls) ? message.tool_calls.length : 0;
  const toolCallSuffix = toolCallCount > 0 ? ` | tool_calls=${toolCallCount}` : '';
  const toolCallIdSuffix = typeof message.tool_call_id === 'string' && message.tool_call_id
    ? ` | tool_call_id=${message.tool_call_id}`
    : '';
  return `[${role}] ${trimmedContent || '(no content)'}${toolCallSuffix}${toolCallIdSuffix}`.trim();
}

function buildCompressedHistorySummary(droppedMessages) {
  const sampled = droppedMessages.slice(-8).map((message) => summarizeMessageForCompaction(message)).filter(Boolean);
  const body = sampled.length > 0 ? sampled.join('\n') : '(no retained details)';
  const droppedCount = droppedMessages.length;
  return [
    `${COMPRESSED_HISTORY_MARKER}`,
    `Dropped older planner messages: ${droppedCount}.`,
    'Use this as compressed prior context only:',
    body,
  ].join('\n');
}

function buildCompactedMessages(messages, keptIndices) {
  const keptOrdered = messages
    .map((message, index) => ({ message, index }))
    .filter((entry) => keptIndices.has(entry.index))
    .map((entry) => ({ ...entry.message }));
  const droppedMessages = messages.filter((_, index) => !keptIndices.has(index));
  if (droppedMessages.length === 0) {
    return {
      messages: keptOrdered,
      droppedMessageCount: 0,
      summaryInserted: false,
    };
  }
  const summaryMessage = {
    role: 'assistant',
    content: buildCompressedHistorySummary(droppedMessages),
  };
  const insertAt = keptOrdered[0] && String(keptOrdered[0].role || '') === 'system' ? 1 : 0;
  const compacted = [
    ...keptOrdered.slice(0, insertAt),
    summaryMessage,
    ...keptOrdered.slice(insertAt),
  ];
  return {
    messages: compacted,
    droppedMessageCount: droppedMessages.length,
    summaryInserted: true,
  };
}

async function compactPlannerMessagesOnce(options = {}) {
  const sourceMessages = Array.isArray(options.messages) ? options.messages : [];
  const maxPromptBudget = Math.max(0, Number(options.maxPromptBudget || 0));
  if (sourceMessages.length === 0) {
    return {
      messages: [],
      droppedMessageCount: 0,
      summaryInserted: false,
      promptTokenCount: 0,
    };
  }
  const requiredIndices = new Set();
  if (String(sourceMessages[0]?.role || '') === 'system') {
    requiredIndices.add(0);
  }
  for (let index = sourceMessages.length - 1; index >= 0; index -= 1) {
    if (String(sourceMessages[index]?.role || '') === 'user') {
      requiredIndices.add(index);
      break;
    }
  }
  let selectedIndices = new Set(requiredIndices);
  const candidateIndices = [];
  for (let index = sourceMessages.length - 1; index >= 0; index -= 1) {
    if (!requiredIndices.has(index)) {
      candidateIndices.push(index);
    }
  }

  for (const index of candidateIndices) {
    const tentativeIndices = new Set(selectedIndices);
    tentativeIndices.add(index);
    const tentative = buildCompactedMessages(sourceMessages, tentativeIndices).messages;
    const tentativePromptTokens = await countTokensWithFallback(options.config, renderTaskTranscript(tentative));
    if (tentativePromptTokens <= maxPromptBudget) {
      selectedIndices = tentativeIndices;
    }
  }

  const compacted = buildCompactedMessages(sourceMessages, selectedIndices);
  const promptTokenCount = await countTokensWithFallback(options.config, renderTaskTranscript(compacted.messages));
  return {
    messages: compacted.messages,
    droppedMessageCount: compacted.droppedMessageCount,
    summaryInserted: compacted.summaryInserted,
    promptTokenCount,
  };
}

async function runTaskLoop(task, options) {
  const taskStartedAt = Date.now();
  const maxTurns = Math.max(1, Number(options.maxTurns || DEFAULT_MAX_TURNS));
  const maxInvalidResponses = Math.max(1, Number(options.maxInvalidResponses || DEFAULT_MAX_INVALID_RESPONSES));
  const history = [];
  const commands = [];
  let finalOutput = '';
  let invalidResponses = 0;
  let commandFailures = 0;
  let safetyRejects = 0;
  let reason = 'max_turns';
  let turnsUsed = 0;
  let mockResponseIndex = 0;
  let forceThinkingOnNextTurn = false;
  let modelPromptTokens = 0;
  let modelPromptCacheTokens = 0;
  let modelPromptEvalTokens = 0;
  const attemptedCommands = new Set();
  const minToolCallsBeforeFinish = Math.max(0, Number(options.minToolCallsBeforeFinish ?? MIN_TOOL_CALLS_BEFORE_FINISH));
  const thinkingInterval = Math.max(1, Math.floor(Number(options.thinkingInterval || 5)));
  const totalContextTokens = Math.max(
    1,
    Number(options.totalContextTokens || (options.config ? getConfiguredLlamaNumCtx(options.config) : 32000))
  );
  const thinkingBufferTokens = Math.max(
    Math.ceil(totalContextTokens * THINKING_BUFFER_RATIO),
    THINKING_BUFFER_MIN_TOKENS
  );
  const usablePromptTokens = Math.max(totalContextTokens - thinkingBufferTokens, 0);
  const requestMaxTokens = resolveRepoSearchRequestMaxTokens(options);
  const followupOnNonThinkingFinish = options.enforceThinkingFinish === true;
  let zeroOutputStreak = 0;
  let forcedFinishAttemptsRemaining = 0;
  let previousPlannerThinkingEnabled = null;
  let nonThinkingFinishFollowupUsed = false;
  const slotId = allocateLlamaCppSlotId(options.config || {});
  const ignorePolicy = buildIgnorePolicy(options.repoRoot);
  const messages = [
    { role: 'system', content: buildTaskSystemPrompt(options.repoRoot) },
    { role: 'user', content: buildTaskInitialUserPrompt(task.question) },
  ];

  for (let turn = 1; turn <= maxTurns; turn += 1) {
    turnsUsed = turn;
    const inForcedFinishMode = forcedFinishAttemptsRemaining > 0;
    const plannerThinkingEnabled = inForcedFinishMode
      ? true
      : (forceThinkingOnNextTurn || (((commands.length + 1) % thinkingInterval) === 0));
    if (forceThinkingOnNextTurn && !inForcedFinishMode) {
      forceThinkingOnNextTurn = false;
    }
    let prompt = renderTaskTranscript(messages);
    let preflight = await preflightPlannerPromptBudget({
      config: options.config,
      prompt,
      totalContextTokens,
      thinkingBufferTokens,
      requestMaxTokens,
    });
    options.logger?.write({
      kind: 'turn_preflight_budget',
      taskId: task.id,
      turn,
      promptTokenCount: preflight.promptTokenCount,
      maxPromptBudget: preflight.maxPromptBudget,
      overflowTokens: preflight.overflowTokens,
      ok: preflight.ok,
      compacted: false,
    });
    if (!preflight.ok) {
      const compacted = await compactPlannerMessagesOnce({
        messages,
        config: options.config,
        maxPromptBudget: preflight.maxPromptBudget,
      });
      messages.splice(0, messages.length, ...compacted.messages);
      prompt = renderTaskTranscript(messages);
      const afterCompaction = await preflightPlannerPromptBudget({
        config: options.config,
        prompt,
        totalContextTokens,
        thinkingBufferTokens,
        requestMaxTokens,
      });
      options.logger?.write({
        kind: 'turn_preflight_compaction_applied',
        taskId: task.id,
        turn,
        beforePromptTokenCount: preflight.promptTokenCount,
        afterPromptTokenCount: afterCompaction.promptTokenCount,
        maxPromptBudget: afterCompaction.maxPromptBudget,
        droppedMessageCount: compacted.droppedMessageCount,
        summaryInserted: compacted.summaryInserted,
      });
      options.logger?.write({
        kind: 'turn_preflight_budget',
        taskId: task.id,
        turn,
        promptTokenCount: afterCompaction.promptTokenCount,
        maxPromptBudget: afterCompaction.maxPromptBudget,
        overflowTokens: afterCompaction.overflowTokens,
        ok: afterCompaction.ok,
        compacted: true,
      });
      preflight = afterCompaction;
    }
    if (!preflight.ok) {
      const overflowError = new Error(
        `planner_preflight_overflow prompt_tokens=${preflight.promptTokenCount} `
        + `max_prompt_tokens=${preflight.maxPromptBudget} overflow_tokens=${preflight.overflowTokens} `
        + `request_max_tokens=${requestMaxTokens} total_context_tokens=${totalContextTokens} `
        + `thinking_buffer_tokens=${thinkingBufferTokens}`
      );
      options.logger?.write({
        kind: 'turn_preflight_overflow_fail',
        taskId: task.id,
        turn,
        promptTokenCount: preflight.promptTokenCount,
        maxPromptBudget: preflight.maxPromptBudget,
        overflowTokens: preflight.overflowTokens,
        requestMaxTokens,
        totalContextTokens,
        thinkingBufferTokens,
        error: overflowError.message,
      });
      throw overflowError;
    }
    options.logger?.write({
      kind: 'turn_model_request',
      taskId: task.id,
      turn,
      thinkingEnabled: plannerThinkingEnabled,
    });
    options.logger?.write({
      kind: 'turn_prompt',
      taskId: task.id,
      turn,
      prompt,
    });

    const plannerRequestOptions = {
      baseUrl: options.baseUrl,
      model: options.model,
      messages,
      slotId,
      timeoutMs: options.timeoutMs || DEFAULT_TIMEOUT_MS,
      mockResponses: options.mockResponses,
      mockResponseIndex,
      thinkingEnabled: plannerThinkingEnabled,
      requestMaxTokens,
      logger: options.logger || null,
    };
    const switchedThinkingMode = previousPlannerThinkingEnabled !== null
      && previousPlannerThinkingEnabled !== plannerThinkingEnabled;
    const maxProviderAttempts = switchedThinkingMode ? 2 : 1;
    let providerAttempt = 0;
    let response = null;
    while (providerAttempt < maxProviderAttempts) {
      providerAttempt += 1;
      try {
        response = options.onProgress
          ? await requestPlannerActionStreaming(plannerRequestOptions, (accumulatedThinking) => {
            options.onProgress({ kind: 'thinking', turn, maxTurns, thinkingText: accumulatedThinking });
          })
          : await requestPlannerAction(plannerRequestOptions);
        break;
      } catch (error) {
        const shouldRetry = providerAttempt < maxProviderAttempts && isTransientProviderError(error);
        if (!shouldRetry) {
          throw error;
        }
        options.logger?.write({
          kind: 'provider_request_retry',
          taskId: task.id,
          turn,
          stage: 'planner_action',
          attempt: providerAttempt,
          nextAttempt: providerAttempt + 1,
          thinkingEnabled: plannerThinkingEnabled,
          error: error instanceof Error ? error.message : String(error),
        });
      }
    }
    if (response.thinkingText && options.onProgress) {
      options.onProgress({ kind: 'thinking', turn, maxTurns, thinkingText: response.thinkingText });
    }
    previousPlannerThinkingEnabled = plannerThinkingEnabled;
    if (typeof response.nextMockResponseIndex === 'number') {
      mockResponseIndex = response.nextMockResponseIndex;
    }
    options.logger?.write({
      kind: 'turn_model_response',
      taskId: task.id,
      turn,
      text: response.text,
      thinkingText: response.thinkingText || '',
      mockExhausted: Boolean(response.mockExhausted),
      promptTokens: Number.isFinite(response.promptTokens) ? Number(response.promptTokens) : null,
      promptCacheTokens: Number.isFinite(response.promptCacheTokens) ? Number(response.promptCacheTokens) : null,
      promptEvalTokens: Number.isFinite(response.promptEvalTokens) ? Number(response.promptEvalTokens) : null,
    });
    if (Number.isFinite(response.promptTokens) && Number(response.promptTokens) >= 0) {
      modelPromptTokens += Number(response.promptTokens);
    }
    if (Number.isFinite(response.promptCacheTokens) && Number(response.promptCacheTokens) >= 0) {
      modelPromptCacheTokens += Number(response.promptCacheTokens);
    }
    if (Number.isFinite(response.promptEvalTokens) && Number(response.promptEvalTokens) >= 0) {
      modelPromptEvalTokens += Number(response.promptEvalTokens);
    }
    if (response.mockExhausted) {
      reason = 'mock_responses_exhausted';
      break;
    }

    let action;
    try {
      action = parsePlannerAction(response.text);
      options.logger?.write({
        kind: 'turn_action_parsed',
        taskId: task.id,
        turn,
        action,
      });
    } catch (error) {
      invalidResponses += 1;
      if (String(response.text || '').trim()) {
        messages.push({ role: 'assistant', content: String(response.text).trim() });
      }
      messages.push({
        role: 'user',
        content: `Invalid action: ${error instanceof Error ? error.message : String(error)}. Return exactly one valid JSON action.`,
      });
      options.logger?.write({
        kind: 'turn_action_invalid',
        taskId: task.id,
        turn,
        invalidResponses,
        error: error instanceof Error ? error.message : String(error),
      });
      if (invalidResponses >= maxInvalidResponses) {
        reason = 'invalid_response_limit';
        break;
      }
      history.push({
        command: '[invalid action]',
        resultText: `Invalid action: ${error instanceof Error ? error.message : String(error)}`,
      });
      continue;
    }

    if (action.action === 'finish') {
      if (commands.length < minToolCallsBeforeFinish) {
        const warning = 'that was a shallow search, there might be more hidden references/usages. Dive deeper';
        messages.push({
          role: 'assistant',
          content: response.text,
        });
        messages.push({
          role: 'user',
          content: warning,
        });
        history.push({
          command: '[finish rejected]',
          resultText: warning,
        });
        options.logger?.write({
          kind: 'turn_finish_rejected',
          taskId: task.id,
          turn,
          toolCallTurns: commands.length,
          minToolCallsBeforeFinish,
          warning,
        });
        continue;
      }
      if (followupOnNonThinkingFinish && !plannerThinkingEnabled && !nonThinkingFinishFollowupUsed) {
        nonThinkingFinishFollowupUsed = true;
        messages.push({
          role: 'assistant',
          content: response.text,
        });
        messages.push({
          role: 'user',
          content: NON_THINKING_FINISH_FOLLOWUP_PROMPT,
        });
        history.push({
          command: '[follow-up]',
          resultText: NON_THINKING_FINISH_FOLLOWUP_PROMPT,
        });
        forceThinkingOnNextTurn = true;
        options.logger?.write({
          kind: 'turn_non_thinking_finish_followup',
          taskId: task.id,
          turn,
          followupPrompt: NON_THINKING_FINISH_FOLLOWUP_PROMPT,
          forcedThinkingOnNextTurn: true,
        });
        continue;
      }
      options.logger?.write({
        kind: 'turn_finish_validation_skipped',
        taskId: task.id,
        turn,
        reason: 'planner_already_thinking',
      });
      finalOutput = action.output;
      reason = 'finish';
      break;
    }

    const command = action.args.command;
    const toolCallId = `call_${commands.length + 1}`;
    if (attemptedCommands.has(command)) {
      const duplicateReason = 'Exact command was already executed';
      commandFailures += 1;
      options.logger?.write({
        kind: 'turn_command_duplicate_blocked',
        taskId: task.id,
        turn,
        command,
        reason: duplicateReason,
      });
      commands.push({
        command,
        safe: false,
        reason: duplicateReason,
        exitCode: null,
        output: `Rejected command: ${duplicateReason}`,
      });
      messages.push(buildRepoSearchAssistantToolMessage(command, toolCallId));
      messages.push({
        role: 'tool',
        tool_call_id: toolCallId,
        content: `Rejected command: ${duplicateReason}`,
      });
      history.push({ command, resultText: `Rejected command: ${duplicateReason}` });
      continue;
    }
    attemptedCommands.add(command);
    if (inForcedFinishMode) {
      forcedFinishAttemptsRemaining = Math.max(forcedFinishAttemptsRemaining - 1, 0);
      const forcedReason = `Forced finish mode active. Return a finish action now. Attempts remaining: ${forcedFinishAttemptsRemaining}.`;
      commandFailures += 1;
      options.logger?.write({
        kind: 'turn_forced_finish_tool_blocked',
        taskId: task.id,
        turn,
        command,
        attemptsRemaining: forcedFinishAttemptsRemaining,
      });
      commands.push({
        command,
        safe: false,
        reason: forcedReason,
        exitCode: null,
        output: `Rejected command: ${forcedReason}`,
      });
      messages.push(buildRepoSearchAssistantToolMessage(command, toolCallId));
      messages.push({
        role: 'tool',
        tool_call_id: toolCallId,
        content: `Rejected command: ${forcedReason}`,
      });
      history.push({ command, resultText: `Rejected command: ${forcedReason}` });
      if (forcedFinishAttemptsRemaining === 0) {
        reason = 'forced_finish_attempt_limit';
        break;
      }
      continue;
    }
    const normalized = normalizePlannerCommand(command, {
      repoRoot: options.repoRoot,
      ignorePolicy,
    });
    if (normalized.rejected) {
      safetyRejects += 1;
      const rejection = `Rejected command: ${normalized.rejectedReason}`;
      options.logger?.write({
        kind: 'turn_command_safety',
        taskId: task.id,
        turn,
        command,
        safe: false,
        reason: normalized.rejectedReason,
      });
      commands.push({
        command,
        safe: false,
        reason: normalized.rejectedReason,
        exitCode: null,
        output: rejection,
      });
      messages.push(buildRepoSearchAssistantToolMessage(command, toolCallId));
      messages.push({
        role: 'tool',
        tool_call_id: toolCallId,
        content: rejection,
      });
      history.push({ command, resultText: rejection });
      continue;
    }
    const commandToRun = normalized.command;
    const safety = evaluateCommandSafety(commandToRun, options.repoRoot);
    options.logger?.write({
      kind: 'turn_command_safety',
      taskId: task.id,
      turn,
      command: commandToRun,
      safe: safety.safe,
      reason: safety.reason,
    });
    if (!safety.safe) {
      safetyRejects += 1;
      const rejection = `Rejected command: ${safety.reason}`;
      commands.push({
        command: commandToRun,
        safe: false,
        reason: safety.reason,
        exitCode: null,
        output: rejection,
      });
      messages.push(buildRepoSearchAssistantToolMessage(commandToRun, toolCallId));
      messages.push({
        role: 'tool',
        tool_call_id: toolCallId,
        content: rejection,
      });
      history.push({ command: commandToRun, resultText: rejection });
      continue;
    }

    const useEstimatedTokensOnly = Array.isArray(options.mockResponses);
    const promptTokenCount = useEstimatedTokensOnly
      ? estimateTokenCount(options.config, prompt)
      : await countTokensWithFallback(options.config, prompt);
    if (options.onProgress) {
      options.onProgress({
        kind: 'tool_start',
        turn,
        maxTurns,
        command: commandToRun,
        promptTokenCount,
        elapsedMs: Date.now() - taskStartedAt,
      });
    }
    const executed = await executeRepoCommand(commandToRun, options.repoRoot, options.mockCommandResults || null);
    const baseOutput = `${String(executed.output || '')}`.trim();
    if (options.onProgress) {
      const snippet = baseOutput.length > 200 ? baseOutput.slice(0, 200) + '...' : baseOutput;
      options.onProgress({
        kind: 'tool_result',
        turn,
        maxTurns,
        command: commandToRun,
        exitCode: executed.exitCode,
        outputSnippet: snippet,
        promptTokenCount,
        elapsedMs: Date.now() - taskStartedAt,
      });
    }
    const outputWithRewriteNote = normalized.rewritten && normalized.note
      ? `${normalized.note}\n${baseOutput}`.trim()
      : baseOutput;
    if (Number(executed.exitCode) !== 0 && !isSearchNoMatchExit(commandToRun, executed.exitCode)) {
      commandFailures += 1;
    }
    if (outputWithRewriteNote.length === 0) {
      zeroOutputStreak += 1;
      const remainingBeforeForce = Math.max(ZERO_OUTPUT_FORCE_THRESHOLD - zeroOutputStreak, 0);
      const warningText = remainingBeforeForce > 0
        ? `Zero-output warning: ${remainingBeforeForce} more zero-output command(s) and you will be forced to answer.`
        : `Zero-output limit reached: you are now forced to answer within ${FORCED_FINISH_MAX_ATTEMPTS} attempt(s).`;
      history.push({
        command: '[zero-output-warning]',
        resultText: warningText,
      });
      options.logger?.write({
        kind: 'turn_zero_output_countdown',
        taskId: task.id,
        turn,
        zeroOutputStreak,
        remainingBeforeForce,
      });
      if (remainingBeforeForce === 0 && forcedFinishAttemptsRemaining === 0) {
        forcedFinishAttemptsRemaining = FORCED_FINISH_MAX_ATTEMPTS;
        messages.push({
          role: 'user',
          content: 'Forced finish mode active. Return {"action":"finish",...} now. Tool calls are blocked.',
        });
        options.logger?.write({
          kind: 'turn_forced_finish_mode_started',
          taskId: task.id,
          turn,
          attemptsRemaining: forcedFinishAttemptsRemaining,
        });
      }
    } else {
      zeroOutputStreak = 0;
    }
    let resultText = `exit_code=${executed.exitCode}\n${outputWithRewriteNote}`.trim();
    const resultTokenCount = useEstimatedTokensOnly
      ? estimateTokenCount(options.config, resultText)
      : await countTokensWithFallback(options.config, resultText);
    const dynamicPerToolRatio = Math.max(
      PER_TOOL_RESULT_RATIO,
      Number(commands.length) / Number(maxTurns)
    );
    const perToolCapTokens = Math.max(1, Math.floor(usablePromptTokens * dynamicPerToolRatio));
    const remainingTokenAllowance = Math.max(usablePromptTokens - promptTokenCount, 0);
    if (resultTokenCount > perToolCapTokens || resultTokenCount > remainingTokenAllowance) {
      resultText = `Error: requested output would consume ${resultTokenCount} tokens, remaining token allowance: ${remainingTokenAllowance}, per tool call allowance: ${perToolCapTokens}`;
      writeRedConsoleLine(`repo_search warning: ${resultText}`);
    }
    options.logger?.write({
      kind: 'turn_command_result',
      taskId: task.id,
      turn,
      command: commandToRun,
      exitCode: executed.exitCode,
      output: outputWithRewriteNote,
      promptTokenCount,
      resultTokenCount,
      perToolCapTokens,
      remainingTokenAllowance,
      insertedResultText: resultText,
    });
    commands.push({
      command: commandToRun,
      safe: true,
      reason: null,
      exitCode: executed.exitCode,
      output: outputWithRewriteNote,
    });
    messages.push(buildRepoSearchAssistantToolMessage(commandToRun, toolCallId));
    messages.push({
      role: 'tool',
      tool_call_id: toolCallId,
      content: resultText,
    });
    history.push({ command: commandToRun, resultText });
  }

  if (!String(finalOutput || '').trim()) {
    let usedFallback = false;
    const synthesisPrompt = buildTerminalSynthesisPrompt({
      question: task.question,
      reason,
      history,
    });
    options.logger?.write({
      kind: 'task_terminal_synthesis_requested',
      taskId: task.id,
      reason,
    });
    try {
      const synthesisResponse = await requestTerminalSynthesis({
        baseUrl: options.baseUrl,
        model: options.model,
        prompt: synthesisPrompt,
        timeoutMs: options.timeoutMs || DEFAULT_TIMEOUT_MS,
        mockResponses: options.mockResponses,
        mockResponseIndex,
        requestMaxTokens,
        logger: options.logger || null,
      });
      if (typeof synthesisResponse.nextMockResponseIndex === 'number') {
        mockResponseIndex = synthesisResponse.nextMockResponseIndex;
      }
      options.logger?.write({
        kind: 'task_terminal_synthesis_raw_response',
        taskId: task.id,
        text: synthesisResponse.text,
        thinkingText: synthesisResponse.thinkingText || '',
        mockExhausted: Boolean(synthesisResponse.mockExhausted),
        promptTokens: Number.isFinite(synthesisResponse.promptTokens) ? Number(synthesisResponse.promptTokens) : null,
        promptCacheTokens: Number.isFinite(synthesisResponse.promptCacheTokens) ? Number(synthesisResponse.promptCacheTokens) : null,
        promptEvalTokens: Number.isFinite(synthesisResponse.promptEvalTokens) ? Number(synthesisResponse.promptEvalTokens) : null,
      });
      if (Number.isFinite(synthesisResponse.promptTokens) && Number(synthesisResponse.promptTokens) >= 0) {
        modelPromptTokens += Number(synthesisResponse.promptTokens);
      }
      if (Number.isFinite(synthesisResponse.promptCacheTokens) && Number(synthesisResponse.promptCacheTokens) >= 0) {
        modelPromptCacheTokens += Number(synthesisResponse.promptCacheTokens);
      }
      if (Number.isFinite(synthesisResponse.promptEvalTokens) && Number(synthesisResponse.promptEvalTokens) >= 0) {
        modelPromptEvalTokens += Number(synthesisResponse.promptEvalTokens);
      }
      if (!synthesisResponse.mockExhausted && String(synthesisResponse.text || '').trim()) {
        finalOutput = String(synthesisResponse.text).trim();
      } else {
        usedFallback = true;
        finalOutput = buildTerminalSynthesisFallback({ reason, commands });
      }
    } catch (error) {
      options.logger?.write({
        kind: 'task_terminal_synthesis_error',
        taskId: task.id,
        error: error instanceof Error ? error.message : String(error),
      });
      usedFallback = true;
      finalOutput = buildTerminalSynthesisFallback({ reason, commands });
    }
    options.logger?.write({
      kind: 'task_terminal_synthesis_result',
      taskId: task.id,
      usedFallback,
      finalOutput,
    });
  }

  const evidenceParts = [finalOutput, ...commands.map((item) => item.output)];
  const signalCheck = evaluateTaskSignals(task, evidenceParts.join('\n'));
  const passed = signalCheck.passed && commandFailures === 0;
  options.logger?.write({
    kind: 'task_done',
    taskId: task.id,
    reason,
    turnsUsed,
    safetyRejects,
    invalidResponses,
    commandFailures,
    passed,
    missingSignals: signalCheck.missingSignals,
  });

  return {
    id: task.id,
    question: task.question,
    reason,
    turnsUsed,
    safetyRejects,
    invalidResponses,
    commandFailures,
    commands,
    finalOutput,
    passed,
    missingSignals: signalCheck.missingSignals,
    promptTokens: modelPromptTokens,
    promptCacheTokens: modelPromptCacheTokens,
    promptEvalTokens: modelPromptEvalTokens,
  };
}

function buildScorecard(options) {
  const totals = {
    tasks: options.tasks.length,
    passed: options.tasks.filter((task) => task.passed).length,
    failed: options.tasks.filter((task) => !task.passed).length,
    commandsExecuted: options.tasks.reduce((sum, task) => sum + task.commands.length, 0),
    safetyRejects: options.tasks.reduce((sum, task) => sum + task.safetyRejects, 0),
    invalidResponses: options.tasks.reduce((sum, task) => sum + task.invalidResponses, 0),
    commandFailures: options.tasks.reduce((sum, task) => sum + Number(task.commandFailures || 0), 0),
    promptTokens: options.tasks.reduce((sum, task) => sum + Number(task.promptTokens || 0), 0),
    promptCacheTokens: options.tasks.reduce((sum, task) => sum + Number(task.promptCacheTokens || 0), 0),
    promptEvalTokens: options.tasks.reduce((sum, task) => sum + Number(task.promptEvalTokens || 0), 0),
  };

  const failureReasons = [];
  for (const task of options.tasks) {
    if (task.passed) {
      continue;
    }
    if (Array.isArray(task.missingSignals) && task.missingSignals.length > 0) {
      failureReasons.push(`${task.id}: missing signals [${task.missingSignals.join(', ')}]`);
    }
    if (Number(task.commandFailures || 0) > 0) {
      failureReasons.push(`${task.id}: command failures ${Number(task.commandFailures || 0)}`);
    }
    if ((task.missingSignals?.length || 0) === 0 && Number(task.commandFailures || 0) === 0) {
      failureReasons.push(`${task.id}: task failed`);
    }
  }

  return {
    runId: options.runId,
    model: options.model,
    tasks: options.tasks,
    totals,
    verdict: totals.failed === 0 ? 'pass' : 'fail',
    failureReasons,
  };
}

function assertConfiguredModelPresent(model, availableModels) {
  if (!Array.isArray(availableModels) || !availableModels.includes(model)) {
    throw new Error(
      `Configured model not found: ${model}. Available models: ${Array.isArray(availableModels) ? availableModels.join(', ') : 'none'}`
    );
  }
}

async function runMockRepoSearch(options = {}) {
  const repoRoot = path.resolve(options.repoRoot || process.cwd());
  const config = options.config || await loadConfig({ ensure: true });
  const model = options.model || getConfiguredModel(config);
  const baseUrl = options.baseUrl || getConfiguredLlamaBaseUrl(config);
  options.logger?.write({
    kind: 'run_start',
    repoRoot,
    requestedModel: options.model || null,
    configuredModel: model,
    baseUrl,
  });
  const availableModels = options.availableModels || await listLlamaCppModels(config);
  options.logger?.write({
    kind: 'model_inventory',
    configuredModel: model,
    availableModels,
  });

  const tasksToRun = options.taskPrompt
    ? [{
      id: 'repo-search',
      question: String(options.taskPrompt),
      signals: [],
    }]
    : TASK_PACK;
  const tasks = [];
  const requestMaxTokens = resolveRepoSearchRequestMaxTokens({
    config,
    requestMaxTokens: options.requestMaxTokens,
  });
  for (const task of tasksToRun) {
    const result = await runTaskLoop(task, {
      repoRoot,
      model,
      baseUrl,
      config,
      totalContextTokens: getConfiguredLlamaNumCtx(config),
      timeoutMs: options.timeoutMs || DEFAULT_TIMEOUT_MS,
      maxTurns: options.maxTurns || DEFAULT_MAX_TURNS,
      maxInvalidResponses: options.maxInvalidResponses || DEFAULT_MAX_INVALID_RESPONSES,
      minToolCallsBeforeFinish: options.minToolCallsBeforeFinish,
      thinkingInterval: options.thinkingInterval,
      requestMaxTokens,
      enforceThinkingFinish: true,
      mockResponses: options.mockResponses,
      mockCommandResults: options.mockCommandResults,
      logger: options.logger || null,
      onProgress: options.onProgress || null,
    });
    tasks.push(result);
  }

  const scorecard = buildScorecard({
    runId: randomUUID(),
    model,
    tasks,
  });
  options.logger?.write({
    kind: 'run_done',
    scorecard,
  });
  return scorecard;
}

function parseCliArgs(argv) {
  const parsed = {
    maxTurns: DEFAULT_MAX_TURNS,
    timeoutMs: DEFAULT_TIMEOUT_MS,
    logFile: path.join(os.tmpdir(), `siftkit-mock-repo-search-${Date.now()}.jsonl`),
  };
  for (let i = 0; i < argv.length; i += 1) {
    const token = argv[i];
    if (token === '--max-turns') {
      parsed.maxTurns = Number(argv[++i]);
    } else if (token === '--timeout-ms') {
      parsed.timeoutMs = Number(argv[++i]);
    } else if (token === '--repo-root') {
      parsed.repoRoot = argv[++i];
    } else if (token === '--model') {
      parsed.model = argv[++i];
    } else if (token === '--log-file') {
      parsed.logFile = argv[++i];
    }
  }
  return parsed;
}

async function main() {
  const args = parseCliArgs(process.argv.slice(2));
  const logger = createJsonlLogger(args.logFile);
  const scorecard = await runMockRepoSearch({
    repoRoot: args.repoRoot,
    maxTurns: args.maxTurns,
    timeoutMs: args.timeoutMs,
    model: args.model,
    logger,
  });
  process.stdout.write(`${JSON.stringify(scorecard, null, 2)}\n`);
  process.stdout.write(
    `Summary: verdict=${scorecard.verdict} passed=${scorecard.totals.passed}/${scorecard.totals.tasks} `
    + `commands=${scorecard.totals.commandsExecuted} safetyRejects=${scorecard.totals.safetyRejects}\n`
  );
  process.stdout.write(`Transcript: ${logger.path}\n`);
}

if (require.main === module) {
  main().catch((error) => {
    const message = error instanceof Error ? error.message : String(error);
    process.stderr.write(`${message}\n`);
    process.exit(1);
  });
}

module.exports = {
  TASK_PACK,
  parsePlannerAction,
  evaluateCommandSafety,
  runTaskLoop,
  buildScorecard,
  assertConfiguredModelPresent,
  runMockRepoSearch,
  resolveRepoSearchRequestMaxTokens,
  estimateTokenCount,
  countTokensWithFallback,
  preflightPlannerPromptBudget,
  compactPlannerMessagesOnce,
};
