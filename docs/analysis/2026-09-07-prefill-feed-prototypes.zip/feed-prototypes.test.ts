import { execFileSync } from 'node:child_process';
import assert from 'node:assert/strict';
import { test } from 'node:test';

const python = 'C:/envs/rl313-turbo/Scripts/python.exe';
const host = process.env.FEED_HOST ?? 'pristine_exle/exllamav3-upstream/exllamav3/model/moe_cpu_host.py';
const dualHost = process.env.FEED_DUAL_HOST ?? 'pristine_exle/exllamav3-upstream/exllamav3/model/moe_cpu_host.py';

test('numerical probe skips autosplit calls with no CPU contribution', () => {
  const output = execFileSync(python, ['-c', `
import ast,pathlib
from types import SimpleNamespace
tree=ast.parse(pathlib.Path('.scratch-staging/feed-control/block_sparse_mlp_cpu.py').read_text())
method=next(n for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name=='cpu_split_combine')
ns={'os':SimpleNamespace(environ={'FEED_CHECK_MODE':'record'})}
exec(compile(ast.fix_missing_locations(ast.Module(body=[method],type_ignores=[])),'<actual combine>','exec'),ns)
class AllocationPass:
 shape=(4096,2560)
 def reshape(self,*args): raise AssertionError('probe entered allocation-only pass')
result=AllocationPass()
assert ns['cpu_split_combine'](SimpleNamespace(),result,None,None,None) is result
print('allocation-only call skipped')
`], { encoding: 'utf8' });
  assert.match(output, /allocation-only call skipped/);
});

test('prefill yields after the initial DMA window and consumes every slot before reuse', () => {
  const output = execFileSync(python, ['-c', `
import ast, pathlib
tree = ast.parse(pathlib.Path(${JSON.stringify(host)}).read_text())
cls = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == 'MoeCpuHost')
method = next(n for n in cls.body if isinstance(n, ast.FunctionDef) and n.name == '_submit_prefill_streamed')
start = next((i for i,n in enumerate(method.body) if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'pending' for t in n.targets)), None)
assert start is not None, 'missing two-phase prefill DMA window'
end = next(i for i in range(start, len(method.body)) if isinstance(method.body[i], ast.If) and isinstance(method.body[i].test, ast.Name) and method.body[i].test.id == 'tail_jobs')
scheduler = ast.FunctionDef(name='schedule', args=ast.arguments(posonlyargs=[], args=[ast.arg(arg=n) for n in ['self','streamed','per_slot','enqueue_batch','compute_batch']], kwonlyargs=[], kw_defaults=[], defaults=[]), body=method.body[start:end], decorator_list=[])
ns = {}
exec(compile(ast.fix_missing_locations(ast.Module(body=[scheduler], type_ignores=[])), '<real scheduler>', 'exec'), ns)
from types import SimpleNamespace
for slots in [1,2,4,8]:
 for count in [0,1,2,3,4,5,9,17]:
  trace, occupied = [], {}
  def enqueue(i):
   slot = i % slots
   assert slot not in occupied, ('overwrite before consume', slots, count, i, trace)
   occupied[slot] = i
   trace.append(('dma',i))
   return ([i],slot,None)
  def compute(batch,slot,pr):
   i = batch[0]
   assert occupied.pop(slot) == i
   trace.append(('compute',i))
  gen = ns['schedule'](SimpleNamespace(num_wslots=slots), list(range(count)), 1, enqueue, compute)
  next(gen)
  assert trace == [('dma',i) for i in range(min(slots,count))], trace
  trace.append(('resident',0))
  assert list(gen) == []
  assert not occupied
  assert [i for kind,i in trace if kind == 'compute'] == list(range(count))
print('32 scheduling boundary cases passed')
`], { encoding: 'utf8' });
  assert.match(output, /32 scheduling boundary cases passed/);
});

test('dual copy streams wait for slot reuse and join before readiness', () => {
  const output = execFileSync(python, ['-c', `
import ast, pathlib
from types import SimpleNamespace
tree = ast.parse(pathlib.Path(${JSON.stringify(dualHost)}).read_text())
cls = next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name == 'MoeCpuHost')
method = next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name == '_submit_prefill_streamed')
source = ast.unparse(method)
assert 'copy_stream2' in source, 'missing second copy stream'
outer = next(n for n in ast.walk(method) if isinstance(n,ast.With) and ast.unparse(n.items[0].context_expr) == 'torch.cuda.stream(copy_stream)')
# Execute the actual DMA branch with instrumented CUDA operations, excluding cache setup.
branch = next(n for n in outer.body if isinstance(n,ast.If) and isinstance(n.test,ast.Name) and n.test.id == 'pe')
start = next(i for i,n in enumerate(branch.body) if isinstance(n,ast.If) and 'copy_stream2' in ast.unparse(n))
finish = next(i for i in range(start,len(branch.body)) if isinstance(branch.body[i],ast.If) and isinstance(branch.body[i].test,ast.Name) and branch.body[i].test.id == 'dups')
body = outer.body[:1] + branch.body[start:finish] + outer.body[-1:]
code = compile(ast.fix_missing_locations(ast.Module(body=body,type_ignores=[])), '<actual DMA dispatch>', 'exec')
for pieces in [1,2,3,4,7]:
 for count in [1,2,3,4,5,9]:
  trace, active = [], ['copy1']
  class Stream:
   def __init__(self,name): self.name=name
   def wait_event(self,event): trace.append(('wait',self.name,event.name))
  class Context:
   def __init__(self,stream): self.stream=stream
   def __enter__(self): active.append(self.stream.name)
   def __exit__(self,*args): active.pop()
  class Event:
   def __init__(self,name): self.name=name
   def record(self,stream): trace.append(('record',stream.name,self.name))
  class Tensor:
   def __getitem__(self,key): return self
   def copy_(self,pv,non_blocking): trace.append(('dma',active[-1],None))
  s1,s2=Stream('copy1'),Stream('copy2')
  st={'copy_stream2':s2,'wslot_used':[True],'wconsumed_ev':[Event('consumed')], 'copy_join':Event('join'),'wready_ev':[Event('ready')],'vram_slots':[Tensor()]}
  ext=SimpleNamespace(exl3_moe_flag_wait=lambda *args:trace.append(('stage',active[-1],None)),exl3_moe_flag_write=lambda *args:trace.append(('free',active[-1],None)))
  ns=dict(st=st,copy_stream=s1,torch=SimpleNamespace(cuda=SimpleNamespace(stream=Context)),self=SimpleNamespace(piece_seq=0,ring_seq=0,pieces=pieces,stage_done_addr=[0],pinned_free_addr=list(range(pieces))),ws=0,hits=[],fills=[],batch=list(range(count)),dups=[],pe=1,exp_b=2,pviews=[Tensor() for _ in range(pieces)],ext=ext,abort=0,pr=None)
  exec(code,ns)
  assert trace[:2] == [('wait','copy1','consumed'),('wait','copy2','consumed')],trace
  assert [stream for kind,stream,_ in trace if kind=='dma'] == ['copy1' if i%2==0 else 'copy2' for i in range(count)]
  assert trace[-3:] == [('record','copy2','join'),('wait','copy1','join'),('record','copy1','ready')],trace
print('30 dual-stream dependency cases passed')
`], { encoding: 'utf8' });
  assert.match(output, /30 dual-stream dependency cases passed/);
});

test('two-phase handles collect immediate and delayed results and propagate failures', () => {
  const output = execFileSync(python, ['-c', `
import ast, pathlib
tree=ast.parse(pathlib.Path(${JSON.stringify(host)}).read_text())
cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='MoeCpuHost')
names={'submit_prefill','submit_prefill_issue','submit_prefill_collect'}
methods=[n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name in names]
assert len(methods)==3, 'missing two-phase methods'
ns={}
exec(compile(ast.fix_missing_locations(ast.Module(body=[ast.ClassDef(name='Host',bases=[],keywords=[],body=methods,decorator_list=[])],type_ignores=[])),'<real handles>','exec'),ns)
result=object()
def immediate(*args):
 if False: yield
 return result
def delayed(*args):
 yield
 return result
for pipeline in [immediate,delayed]:
 host=ns['Host']()
 host._prefill_pipeline=pipeline
 assert host.submit_prefill_collect(host.submit_prefill_issue(0,None,None,None)) is result
 assert host.submit_prefill(0,None,None,None) is result
def fail(*args):
 yield
 raise ValueError('worker failure')
host._prefill_pipeline=fail
try: host.submit_prefill(0,None,None,None)
except ValueError as e: assert str(e)=='worker failure'
else: raise AssertionError('failure swallowed')
def twice(*args):
 yield
 yield
host._prefill_pipeline=twice
try: host.submit_prefill(0,None,None,None)
except RuntimeError as e: assert 'more than once' in str(e)
else: raise AssertionError('unexpected yield accepted')
print('handle completion and failure cases passed')
`], { encoding: 'utf8' });
  assert.match(output, /handle completion and failure cases passed/);
});
