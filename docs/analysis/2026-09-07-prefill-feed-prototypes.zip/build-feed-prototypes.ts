import { mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';

const root = 'pristine_exle/exllamav3-upstream';
const hostPath = 'exllamav3/model/moe_cpu_host.py';
const splitPath = 'exllamav3/modules/block_sparse_mlp_cpu.py';
const originalHost = readFileSync(`${root}/${hostPath}`, 'utf8').replaceAll('\r\n', '\n');
const originalSplit = readFileSync(`${root}/${splitPath}`, 'utf8').replaceAll('\r\n', '\n');
function replaceOnce(source: string, before: string, after: string) {
  if (source.split(before).length !== 2) throw new Error(`Expected unique source: ${before.slice(0, 100)}`);
  return source.replace(before, after);
}

let a = originalHost;
const profileStart = a.indexOf('    def submit_prefill(');
const profileEnd = a.indexOf('    def _submit_prefill(', profileStart);
if (profileStart < 0 || profileEnd < 0) throw new Error('Missing prefill methods');
const profile = a.slice(profileStart, profileEnd)
  .replace('def submit_prefill(', 'def _prefill_pipeline(')
  .replaceAll('return self._submit_prefill(', 'return (yield from self._submit_prefill(')
  .replaceAll('layer_idx, y, selected_experts, routing_weights)\n', 'layer_idx, y, selected_experts, routing_weights))\n');
a = a.slice(0, profileStart) + `    def submit_prefill(self, layer_idx, y, selected_experts, routing_weights):
        return self.submit_prefill_collect(self.submit_prefill_issue(
            layer_idx, y, selected_experts, routing_weights))

    def submit_prefill_issue(self, layer_idx, y, selected_experts, routing_weights):
        pending = self._prefill_pipeline(layer_idx, y, selected_experts, routing_weights)
        try:
            next(pending)
        except StopIteration as done:
            return None, done.value
        return pending, None

    def submit_prefill_collect(self, handle):
        pending, result = handle
        if pending is None:
            return result
        try:
            next(pending)
        except StopIteration as done:
            return done.value
        raise RuntimeError("prefill pipeline yielded more than once")

` + profile + a.slice(profileEnd);
a = replaceOnce(a, '            return self._submit_prefill_streamed(\n', '            return (yield from self._submit_prefill_streamed(\n');
a = replaceOnce(a, '                counts_h, flat, shifted, neg)\n', '                counts_h, flat, shifted, neg))\n');
a = replaceOnce(a, '        for i0 in range(0, len(streamed), per_slot):\n', '        def enqueue_batch(i0):\n');
a = replaceOnce(a, '            # Compute the batch on the current stream once the DMA lands\n', `            return batch, ws, pr

        def compute_batch(batch, ws, pr):
            # Compute the batch on the current stream once the DMA lands
`);
a = replaceOnce(a, '        # Collect the CPU tail (by now usually complete) and merge\n', `        pr = self.prof if TUNING.stream_prof else None
        pending = [enqueue_batch(i0) for i0 in
                   range(0, min(len(streamed), self.num_wslots * per_slot), per_slot)]
        yield
        for index in range((len(streamed) + per_slot - 1) // per_slot):
            slot = index % self.num_wslots
            compute_batch(*pending[slot])
            following = (index + self.num_wslots) * per_slot
            if following < len(streamed):
                pending[slot] = enqueue_batch(following)

        # Collect the CPU tail (by now usually complete) and merge
`);
let splitA = replaceOnce(originalSplit,
  '        return self.cpu_host.submit_prefill(\n            self.cpu_layer_idx, y, sel_cpu, routing_weights), None',
  '        return None, ("stream", self.cpu_host.submit_prefill_issue(\n            self.cpu_layer_idx, y, sel_cpu, routing_weights))');
splitA = replaceOnce(splitA, '            cpu_partial = self.cpu_host.submit_collect(cpu_pending)\n', `            if isinstance(cpu_pending, tuple) and cpu_pending[0] == "stream":
                cpu_partial = self.cpu_host.submit_prefill_collect(cpu_pending[1])
            else:
                cpu_partial = self.cpu_host.submit_collect(cpu_pending)
`);
splitA = replaceOnce(splitA, '        big prefill batches take the single-phase streamed path, which overlaps internally.',
  '        big prefill batches pre-issue the DMA window before resident expert compute.');

function dualCopy(source: string) {
  let result = replaceOnce(source, '            copy_stream = torch.cuda.Stream(device = device),\n',
    '            copy_stream = torch.cuda.Stream(device = device),\n            copy_stream2 = torch.cuda.Stream(device = device),\n            copy_join = torch.cuda.Event(),\n');
  const start = result.indexOf('                    for k in range(len(hits) + len(fills),');
  const end = result.indexOf('                    if dups:', start);
  if (start < 0 || end < 0) throw new Error('Missing piece loop');
  const loop = result.slice(start, end);
  const gate = loop.indexOf('                        ext.exl3_moe_flag_wait');
  if (gate < 0) throw new Error('Missing piece gate');
  const body = loop.slice(gate).replaceAll('e0.record(copy_stream)', 'e0.record(piece_stream)')
    .replaceAll('e1.record(copy_stream)', 'e1.record(piece_stream)')
    .split('\n').map(line => line ? `    ${line}` : line).join('\n');
  const replacement = `                    if st["wslot_used"][ws]:
                        st["copy_stream2"].wait_event(st["wconsumed_ev"][ws])
` + loop.slice(0, gate) + `                        piece_stream = copy_stream if r % 2 == 0 else st["copy_stream2"]
                        with torch.cuda.stream(piece_stream):
` + body + `                    st["copy_join"].record(st["copy_stream2"])
                    copy_stream.wait_event(st["copy_join"])
`;
  return result.slice(0, start) + replacement + result.slice(end);
}

function checkedSplit(source: string) {
  return replaceOnce(source, '        return final_hidden_states\n\n    @override\n', `        if cpu_partial is not None and os.environ.get("FEED_CHECK_MODE") and not getattr(self, "_feed_checked", False):
            flat = final_hidden_states.reshape(-1, final_hidden_states.shape[-1])
            if flat.shape[0] == 4096:
                self._feed_checked = True
                from pathlib import Path
                import sys
                assert torch.isfinite(flat).all().item(), "nonfinite prefill output"
                sample = flat[::64].float().cpu()
                path = Path(os.environ["FEED_CHECK_DIR"]) / (str(self.cpu_layer_idx) + ".pt")
                if os.environ["FEED_CHECK_MODE"] == "record":
                    torch.save(sample, path)
                    print(f"FEED_CHECK layer={self.cpu_layer_idx} recorded", file=sys.stderr)
                else:
                    expected = torch.load(path, weights_only=True)
                    torch.testing.assert_close(sample, expected, rtol=1e-4, atol=1e-4)
                    delta = (sample - expected).abs().max().item()
                    print(f"FEED_CHECK layer={self.cpu_layer_idx} max_abs={delta}", file=sys.stderr)
        return final_hidden_states

    @override
`);
}

function checkedHost(source: string) {
  return replaceOnce(source, '        return out\n\n    def unregister(self):', `        if os.environ.get("FEED_SELF_CHECK") and rows == 4096:
            checked = getattr(self, "_feed_validated", None)
            if checked is None:
                checked = self._feed_validated = set()
            if layer_idx not in checked:
                checked.add(layer_idx)
                if not hasattr(self, "_feed_reference"):
                    import importlib.util
                    module_spec = importlib.util.spec_from_file_location(
                        "exllamav3.model.feed_reference", os.environ["FEED_REFERENCE"])
                    if module_spec is None or module_spec.loader is None:
                        raise RuntimeError("missing reference scheduler")
                    self._feed_reference = importlib.util.module_from_spec(module_spec)
                    module_spec.loader.exec_module(self._feed_reference)
                reference = self._feed_reference.MoeCpuHost._submit_prefill_streamed(
                    self, layer_idx, y, selected_experts, routing_weights, spec,
                    streamed, st, counts_h, flat, shifted, neg)
                torch.testing.assert_close(out, reference, rtol=1e-4, atol=1e-4)
                import sys
                delta = (out - reference).abs().max().item()
                print(f"FEED_SELF_CHECK layer={layer_idx} max_abs={delta} elements={out.numel()}", file=sys.stderr)
        return out

    def unregister(self):`);
}

writeFileSync('.scratch-staging/feed-reference.py', originalHost);

for (const [name, host, split] of [
  ['control', originalHost, originalSplit], ['a', a, splitA],
  ['b', dualCopy(originalHost), originalSplit], ['ab', dualCopy(a), splitA],
]) {
  if (name === undefined || host === undefined || split === undefined) throw new Error('Missing variant');
  const directory = `.scratch-staging/feed-${name}`;
  mkdirSync(directory, { recursive: true });
  writeFileSync(`${directory}/moe_cpu_host.py`, checkedHost(host));
  writeFileSync(`${directory}/block_sparse_mlp_cpu.py`, checkedSplit(split));
}
writeFileSync('.scratch-staging/feed-original-hashes.json', JSON.stringify(
  [hostPath, splitPath].map(path => ({ path, sha256: createHash('sha256').update(readFileSync(`${root}/${path}`)).digest('hex') })), null, 2));
console.log('Generated control, A, B, and combined scratch variants. Checkout untouched.');
