import { readFileSync, writeFileSync } from 'node:fs';
import { z } from 'zod';

const names = ['feed-ctl-3', 'feed-a-default-3', 'feed-ctl-wide', 'feed-a-wide',
  'feed-ctl-tail', 'feed-a-tail', 'feed-ctl-wide-tail', 'feed-a-wide-tail',
  'feed-ctl-b', 'feed-b-default'];
function number(text: string, pattern: RegExp) {
  const match = pattern.exec(text);
  if (match?.[1] === undefined) throw new Error(`Missing ${pattern}`);
  return z.coerce.number().finite().nonnegative().parse(match[1]);
}
const results = names.map(name => {
  const out = readFileSync(`.scratch-staging/${name}.txt`, 'utf8').replace(/\u001b\[[0-9;]*m/g, '');
  const err = readFileSync(`.scratch-staging/${name}-stderr.txt`, 'utf8');
  const status = readFileSync(`.scratch-staging/${name}-status.txt`, 'utf8');
  z.literal(0).parse(number(status, /exit_code (\d+)/));
  const checks = [...err.matchAll(/FEED_SELF_CHECK layer=\d+ max_abs=([\deE.+-]+) elements=(\d+)/g)];
  z.literal(47).parse(checks.length);
  const pieces = number(err, /stage prof: (\d+) ring pieces/);
  const gate = number(err, /gate wait ([\d.]+) s/);
  const copy = number(err, /copy ([\d.]+) s/);
  return {
    name,
    tps32k: z.number().positive().parse(number(out, /Length\s+32768:\s+([\d.]+)/)),
    selfChecks: checks.length,
    comparedElements: checks.reduce((sum, match) => sum + z.coerce.number().int().positive().parse(match[2]), 0),
    maxAbs: Math.max(...checks.map(match => z.coerce.number().finite().nonnegative().parse(match[1]))),
    weightWaitSeconds: number(out, /stalled on wready ([\d.]+) s/),
    dmaGBps: number(out, /DMA active [\d.]+ s \(([\d.]+) GB\/s/),
    pieceWallMs: (gate + copy) * 1000 / pieces,
  };
});
writeFileSync('.scratch-staging/feed-results.json', JSON.stringify(results, null, 2) + '\n');
console.log(JSON.stringify(results));
