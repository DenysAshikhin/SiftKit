#!/bin/bash
set -eu
cd 'C:/Users/denys/Documents/GitHub/SiftKit'
bash .scratch-staging/run_upstream.sh feed-ctl-0 'EXL3_MOE_MEMOPS=1 EXL3_MOE_STREAM_T=8 EXL3_MOE_STREAM_PROF=1 EXL3_MOE_STAGE_PROF=1' -mcs 410 -mct 12 -cs 32768 -chunk_size 4096 -ngr -max_length 32768 -sg
grep -q 'exit_code 0' .scratch-staging/feed-ctl-0-status.txt
echo done > .scratch-staging/feed-control-done.txt
