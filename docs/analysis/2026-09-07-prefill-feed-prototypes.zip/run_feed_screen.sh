#!/bin/bash
set -eu
cd 'C:/Users/denys/Documents/GitHub/SiftKit'
UP=pristine_exle/exllamav3-upstream
OUT=.scratch-staging
BACKUP=$OUT/cur-backup/feed-screen
mkdir -p "$BACKUP" "$OUT/feed-check"
cp "$UP/exllamav3/model/moe_cpu_host.py" "$BACKUP/moe_cpu_host.py"
cp "$UP/exllamav3/modules/block_sparse_mlp_cpu.py" "$BACKUP/block_sparse_mlp_cpu.py"
restore() {
  result=$?
  cp "$BACKUP/moe_cpu_host.py" "$UP/exllamav3/model/moe_cpu_host.py"
  cp "$BACKUP/block_sparse_mlp_cpu.py" "$UP/exllamav3/modules/block_sparse_mlp_cpu.py"
  cmp "$BACKUP/moe_cpu_host.py" "$UP/exllamav3/model/moe_cpu_host.py"
  cmp "$BACKUP/block_sparse_mlp_cpu.py" "$UP/exllamav3/modules/block_sparse_mlp_cpu.py"
  echo "exit_code $result restored" > "$OUT/feed-screen-done.txt"
}
trap restore EXIT
B='EXL3_MOE_MEMOPS=1 EXL3_MOE_STREAM_T=8 EXL3_MOE_STREAM_PROF=1 EXL3_MOE_STAGE_PROF=1'
A='-mcs 410 -mct 12 -cs 32768 -chunk_size 4096 -ngr -max_length 32768 -sg'
CHECK='FEED_CHECK_DIR=C:/Users/denys/Documents/GitHub/SiftKit/.scratch-staging/feed-check'
run() {
  variant=$1; name=$2; extra=$3
  cp "$OUT/feed-$variant/moe_cpu_host.py" "$UP/exllamav3/model/moe_cpu_host.py"
  cp "$OUT/feed-$variant/block_sparse_mlp_cpu.py" "$UP/exllamav3/modules/block_sparse_mlp_cpu.py"
  bash "$OUT/run_upstream.sh" "$name" "$B $CHECK $extra" $A
  grep -q 'exit_code 0' "$OUT/$name-status.txt"
}
run control feed-ctl-2 'FEED_CHECK_MODE=record'
run a feed-a-default-2 'FEED_CHECK_MODE=compare'
run control feed-ctl-wide 'EXL3_MOE_CPU_WSLOTS=4 EXL3_MOE_CPU_WSLOT_MB=64 FEED_CHECK_MODE=compare'
run a feed-a-wide 'EXL3_MOE_CPU_WSLOTS=4 EXL3_MOE_CPU_WSLOT_MB=64 FEED_CHECK_MODE=compare'
run control feed-ctl-tail 'EXL3_MOE_CPU_SLOTS=8 EXL3_MOE_CPU_SLOT_ROWS=512 FEED_CHECK_MODE=compare'
run a feed-a-tail 'EXL3_MOE_CPU_SLOTS=8 EXL3_MOE_CPU_SLOT_ROWS=512 FEED_CHECK_MODE=compare'
run control feed-ctl-wide-tail 'EXL3_MOE_CPU_WSLOTS=4 EXL3_MOE_CPU_WSLOT_MB=64 EXL3_MOE_CPU_SLOTS=8 EXL3_MOE_CPU_SLOT_ROWS=512 FEED_CHECK_MODE=compare'
run a feed-a-wide-tail 'EXL3_MOE_CPU_WSLOTS=4 EXL3_MOE_CPU_WSLOT_MB=64 EXL3_MOE_CPU_SLOTS=8 EXL3_MOE_CPU_SLOT_ROWS=512 FEED_CHECK_MODE=compare'
run control feed-ctl-b 'FEED_CHECK_MODE=compare'
run b feed-b-default 'FEED_CHECK_MODE=compare'
