#!/bin/bash
set -eu
OUT=/mnt/c/Users/denys/Documents/GitHub/SiftKit/.scratch-upstream-staging
REPO=/opt/exllamav3-incremental-20260907
/opt/exl3/bin/python - <<'PY'
import torch, sys, json
print(json.dumps({'python':sys.version,'torch':torch.__version__,'cuda':torch.cuda.is_available()}))
PY
git clone --branch dev --single-branch https://github.com/turboderp-org/exllamav3.git "$REPO"
git -C "$REPO" checkout --detach a99c30994f6d9173e505254e81b0e5d784caa36e
git -C "$REPO" branch baseline/upstream-dev-20260907
git -C "$REPO" config user.name 'Denys Ashikhin'
git -C "$REPO" config user.email 'denysashikhin@gmail.com'
printf '\n/exllamav3_ext*.so\n' >> "$REPO/.git/info/exclude"
cd "$REPO"
export CUDA_HOME=/usr/local/cuda-13.2
export PATH=/opt/exl3/bin:$CUDA_HOME/bin:$PATH
export TORCH_CUDA_ARCH_LIST=8.9 MAX_JOBS=12 PYTHONDONTWRITEBYTECODE=1
set +e
/opt/exl3/bin/python setup.py build_ext --inplace > "$OUT/linux-build.txt" 2> "$OUT/linux-build-stderr.txt"
result=$?
printf '%s\n' "$result" > "$OUT/linux-build-status.txt"
exit "$result"
