import { spawn } from 'node:child_process';
import { existsSync, readFileSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { z } from 'zod';
import { parseRun, runtimeSchema, runRecordSchema } from './metrics.ts';

const platform = z.enum(['windows', 'linux']).parse(process.argv[2]);
const label = z.string().regex(/^[a-z0-9-]+$/).parse(process.argv[3]);
const count = z.coerce.number().int().min(1).max(5).parse(process.argv[4] ?? '5');
const start = z.coerce.number().int().min(1).max(5).parse(process.argv[5] ?? '1');
const extra = z.string().regex(/^(?:EXL3_[A-Z_]+=\d+(?: |$))*$/).parse(process.argv[6] ?? '');
if (start + count > 6) throw new Error('Run indices exceed five');
const directory = resolve('.scratch-upstream-staging');
const statePath = resolve(directory, `${platform}-${label}-state.json`);

for (let index = start; index < start + count; index++) {
  const name = `${platform}-${label}-${index}`;
  const resultPath = resolve(directory, `${name}-result.json`);
  if (existsSync(resultPath) || existsSync(resolve(directory, `${name}.txt`))) {
    throw new Error(`Refusing to overwrite run ${name}`);
  }
  const started = new Date().toISOString();
  const command = platform === 'windows' ? 'C:/personal/Git/bin/bash.exe' : 'C:/Windows/System32/wsl.exe';
  const args = platform === 'windows'
    ? [resolve(directory, 'benchmark.sh'), platform, name, ...(extra ? [extra] : [])]
    : ['-d', 'SiftKit-EXL3-Perf-20260905', '--exec', 'bash',
      '/mnt/c/Users/denys/Documents/GitHub/SiftKit/.scratch-upstream-staging/benchmark.sh', platform, name, ...(extra ? [extra] : [])];
  writeFileSync(statePath, JSON.stringify({ name, status: 'running', started, command, args }, null, 2));
  console.log(`${started} starting ${name}`);
  const code = await new Promise<number>((done, reject) => {
    const child = spawn(command, args, { cwd: process.cwd(), windowsHide: true, stdio: ['ignore', 'inherit', 'inherit'] });
    child.on('error', reject);
    child.on('close', (exitCode, signal) => {
      if (exitCode === null) reject(new Error(`Run terminated by ${signal}`));
      else done(exitCode);
    });
  });
  if (code !== 0) {
    writeFileSync(statePath, JSON.stringify({ name, status: 'failed', started, exitCode: code }, null, 2));
    throw new Error(`${name} exited ${code}; failed attempt preserved`);
  }
  try {
    const runtime = runtimeSchema.parse(JSON.parse(readFileSync(resolve(directory, `${name}-runtime.json`), 'utf8')));
    const metrics = parseRun(readFileSync(resolve(directory, `${name}.txt`), 'utf8'),
      readFileSync(resolve(directory, `${name}-stderr.txt`), 'utf8'));
    const finished = new Date().toISOString();
    writeFileSync(resultPath, JSON.stringify(runRecordSchema.parse({ name, platform, started, finished, runtime, metrics }), null, 2));
    const pp32k = metrics.prefill.find(row => row.length === 32768);
    if (pp32k === undefined) throw new Error('Validated 32k result missing');
    console.log(`${finished} completed ${name}: PP32k=${pp32k.tokensPerSecond}`);
    writeFileSync(statePath, JSON.stringify({ name, status: 'completed', started, finished, resultPath }, null, 2));
  } catch (error) {
    writeFileSync(statePath, JSON.stringify({ name, status: 'invalid-output', started,
      error: error instanceof Error ? error.message : 'Unrecognized result validation failure' }, null, 2));
    throw error;
  }
}
