import assert from 'node:assert/strict';
import { test } from 'node:test';
import { parseRun } from './metrics.ts';

const pp = [256, 512, 1024, 2048, 4096, 8192, 16384, 32768];
const decode = [0, 256, 512, 1024, 2048, 4096, 8192, 16384, 32512];
const fixture = [...pp.map(length => `Length ${length}: \u001b[32;1m1000.50\u001b[0m tokens/s`),
  ...decode.map(length => `Context ${length}: S=\u001b[90m1 \u001b[32;1m25.25\u001b[0m tokens/s`)].join('\n');

test('extracts every PP and decode context through ANSI formatting', () => {
  const result = parseRun(fixture, '');
  assert.deepEqual(result, {
    prefill: pp.map(length => ({ length, tokensPerSecond: 1000.5 })),
    decode: decode.map(length => ({ length, tokensPerSecond: 25.25 })),
  });
});

test('rejects missing and duplicate contexts', () => {
  assert.throws(() => parseRun(fixture.replace(/^Length 32768:.*\n/m, ''), ''));
  assert.throws(() => parseRun(fixture.replace('Length 32768:', 'Length 16384:'), ''));
  assert.throws(() => parseRun(fixture.replace(/^Context 32512:.*$/m, ''), ''));
});

test('rejects nonfinite and nonpositive rates', () => {
  for (const invalid of ['NaN', 'Infinity', '0', '-1']) {
    assert.throws(() => parseRun(fixture.replace('1000.50', invalid), ''));
    assert.throws(() => parseRun(fixture.replace('25.25', invalid), ''));
  }
});

test('rejects a traceback even when all rates were printed', () => {
  assert.throws(() => parseRun(fixture, 'Traceback (most recent call last):\nRuntimeError: worker failed'));
  assert.throws(() => parseRun(fixture + '\nCUDA error: illegal memory access', ''));
});
