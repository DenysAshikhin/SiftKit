import { readFileSync, writeFileSync } from 'node:fs';
import { z } from 'zod';
import { runRecordSchema, metricsSchema } from './metrics.ts';

const platform = z.enum(['windows', 'linux']).parse(process.argv[2]);
const label = z.string().regex(/^[a-z0-9-]+$/).parse(process.argv[3]);
const records = Array.from({ length: 5 }, (_, index) => {
  const name = `${platform}-${label}-${index + 1}`;
  const record = runRecordSchema.parse(JSON.parse(readFileSync(`.scratch-upstream-staging/${name}-result.json`, 'utf8')));
  if (record.name !== name || record.platform !== platform) throw new Error(`Mismatched run ${name}`);
  return record;
});
if (new Set(records.map(record => record.runtime.source)).size !== 1 ||
    new Set(records.map(record => record.runtime.extensionSha256)).size !== 1) throw new Error('Mixed source or native builds');
const first = records[0];
if (first === undefined) throw new Error('Missing runs');
const summary = { platform, label, source: first.runtime.source, extensionSha256: first.runtime.extensionSha256,
  metrics: { prefill: summarize('prefill'), decode: summarize('decode') } };

function stats(values: number[]) {
  const sorted = [...values].sort((a, b) => a - b);
  const median = sorted[Math.floor(sorted.length / 2)];
  if (median === undefined) throw new Error('Empty observations');
  return { observations: values, median, min: Math.min(...values), max: Math.max(...values) };
}
function summarize(kind: keyof z.infer<typeof metricsSchema>) {
  if (first === undefined) throw new Error('Missing runs');
  return first.metrics[kind].map(row => ({ length: row.length, ...stats(records.map(record => {
    const match = record.metrics[kind].find(value => value.length === row.length);
    if (match === undefined) throw new Error(`Missing ${kind} context`);
    return match.tokensPerSecond;
  })) }));
}
writeFileSync(`.scratch-upstream-staging/${platform}-${label}-summary.json`, JSON.stringify(summary, null, 2));
console.log(JSON.stringify(summary));
