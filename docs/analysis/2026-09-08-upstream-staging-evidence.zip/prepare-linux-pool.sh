#!/bin/bash
set -eu
OUT=/mnt/c/Users/denys/Documents/GitHub/SiftKit/.scratch-upstream-staging
REPO=/opt/exllamav3-incremental-20260907
cd "$REPO"
mkdir -p "$OUT/native/linux/base" "$OUT/native/linux/pool"
cp exllamav3_ext.cpython-313-x86_64-linux-gnu.so "$OUT/native/linux/base/"
git fetch "$OUT/candidates.bundle" \
  refs/heads/perf/staging-probe-retry:refs/heads/perf/staging-probe-retry \
  refs/heads/perf/staging-worker-pool:refs/heads/perf/staging-worker-pool
git switch perf/staging-worker-pool
export CUDA_HOME=/usr/local/cuda-13.2
export PATH=/opt/exl3/bin:$CUDA_HOME/bin:$PATH
export TORCH_CUDA_ARCH_LIST=8.9 MAX_JOBS=12 PYTHONDONTWRITEBYTECODE=1 PYTHONPATH="$REPO"
set +e
/opt/exl3/bin/python setup.py build_ext --inplace > "$OUT/linux-pool-build.txt" 2> "$OUT/linux-pool-build-stderr.txt"
result=$?
printf '%s\n' "$result" > "$OUT/linux-pool-build-status.txt"
if [ "$result" != 0 ]; then exit "$result"; fi
cp exllamav3_ext.cpython-313-x86_64-linux-gnu.so "$OUT/native/linux/pool/"
/opt/exl3/bin/python -m pytest tests/test_moe_staging_workers.py tests/test_moe_cpu_pool_.py -q \
  > "$OUT/linux-pool-tests.txt" 2>&1
result=$?
printf '%s\n' "$result" > "$OUT/linux-pool-tests-status.txt"
exit "$result"
