import { z } from 'zod';

const rate = z.object({
  length: z.coerce.number().int().nonnegative(),
  tokensPerSecond: z.coerce.number().finite().positive(),
});
function observations(contexts: readonly number[]) {
  return z.array(rate).length(contexts.length).refine(
    values => contexts.every(length => values.some(value => value.length === length)),
    'Missing or duplicate benchmark contexts');
}
export const metricsSchema = z.object({
  prefill: observations([256, 512, 1024, 2048, 4096, 8192, 16384, 32768]),
  decode: observations([0, 256, 512, 1024, 2048, 4096, 8192, 16384, 32512]),
});

export const runtimeSchema = z.object({
  source: z.string().regex(/^[a-f0-9]{40}$/), module: z.string().min(1), extension: z.string().min(1),
  extensionSha256: z.string().regex(/^[a-f0-9]{64}$/), python: z.string(), torch: z.string(), cuda: z.string(),
  environment: z.record(z.string(), z.string()),
});
export const runRecordSchema = z.object({
  name: z.string(), platform: z.enum(['windows', 'linux']), started: z.iso.datetime(), finished: z.iso.datetime(),
  runtime: runtimeSchema, metrics: metricsSchema,
});

export function parseRun(stdout: string, stderr: string) {
  if (/Traceback \(most recent call last\)|CUDA error:|AssertionError:|RuntimeError:/i.test(stdout + stderr)) {
    throw new Error('Benchmark reported a runtime failure');
  }
  const clean = stdout.replace(/\u001b\[[0-9;]*m/g, '');
  return metricsSchema.parse({
    prefill: [...clean.matchAll(/^\s*Length\s+(\d+):\s+(\S+)\s+tokens\/s\s*$/gm)]
      .map(match => ({ length: match[1], tokensPerSecond: match[2] })),
    decode: [...clean.matchAll(/^\s*Context\s+(\d+):\s+S=\s*1\s+(\S+)\s+tokens\/s\s*$/gm)]
      .map(match => ({ length: match[1], tokensPerSecond: match[2] })),
  });
}
