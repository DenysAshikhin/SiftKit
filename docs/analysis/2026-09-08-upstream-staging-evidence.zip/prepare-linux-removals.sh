#!/bin/bash
set -eu
OUT=/mnt/c/Users/denys/Documents/GitHub/SiftKit/.scratch-upstream-staging
REPO=/opt/exllamav3-incremental-20260907
cd "$REPO"
git diff --exit-code --quiet
git diff --cached --exit-code --quiet
git fetch "$OUT/removals.bundle" \
  refs/heads/perf/staging-piece-ring-minimum:refs/heads/perf/staging-piece-ring-minimum \
  refs/heads/perf/staging-piece-ring-no-pool:refs/heads/perf/staging-piece-ring-no-pool
export PYTHONPATH="$REPO" PYTHONDONTWRITEBYTECODE=1
git switch perf/staging-piece-ring-minimum
cp "$OUT/native/linux/ring/exllamav3_ext.cpython-313-x86_64-linux-gnu.so" .
/opt/exl3/bin/python -m pytest tests/test_moe_staging_pieces.py tests/test_moe_staging_workers.py -q \
  > "$OUT/linux-minimum-tests.txt" 2>&1
printf '0\n' > "$OUT/linux-minimum-tests-status.txt"
git switch perf/staging-piece-ring-no-pool
export CUDA_HOME=/usr/local/cuda-13.2
export PATH=/opt/exl3/bin:$CUDA_HOME/bin:$PATH
export TORCH_CUDA_ARCH_LIST=8.9 MAX_JOBS=12
set +e
/opt/exl3/bin/python setup.py build_ext --inplace > "$OUT/linux-no-pool-build.txt" 2> "$OUT/linux-no-pool-build-stderr.txt"
result=$?
printf '%s\n' "$result" > "$OUT/linux-no-pool-build-status.txt"
if [ "$result" != 0 ]; then exit "$result"; fi
mkdir -p "$OUT/native/linux/no-pool"
cp exllamav3_ext.cpython-313-x86_64-linux-gnu.so "$OUT/native/linux/no-pool/"
/opt/exl3/bin/python -m pytest tests/test_moe_staging_geometry.py tests/test_moe_staging_pieces.py \
  tests/test_moe_staging_concurrency.py tests/test_moe_cpu_pool_.py -q > "$OUT/linux-no-pool-tests.txt" 2>&1
result=$?
printf '%s\n' "$result" > "$OUT/linux-no-pool-tests-status.txt"
if [ "$result" != 0 ]; then exit "$result"; fi
/opt/exl3/bin/python -m pytest "$OUT/validation/test_moe_cpu_offload.py" -q > "$OUT/linux-no-pool-broader.txt" 2>&1
result=$?
printf '%s\n' "$result" > "$OUT/linux-no-pool-broader-status.txt"
exit "$result"
