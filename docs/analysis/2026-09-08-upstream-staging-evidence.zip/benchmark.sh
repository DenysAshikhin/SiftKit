#!/bin/bash
set -eu
PLATFORM=$1
NAME=$2
EXTRA=${3-}
if [ "$PLATFORM" = windows ]; then
    REPO='C:/Users/denys/Documents/GitHub/SiftKit/pristine_exle/exllamav3-incremental'
    OUT='C:/Users/denys/Documents/GitHub/SiftKit/.scratch-upstream-staging'
    PYTHON='C:/envs/rl313-turbo/Scripts/python.exe'
    MODEL='D:/personal/models/elx3/td_flash-next_4.05bpw_h6_ng6'
else
    REPO=/opt/exllamav3-incremental-20260907
    OUT=/mnt/c/Users/denys/Documents/GitHub/SiftKit/.scratch-upstream-staging
    PYTHON=/opt/exl3/bin/python
    MODEL=/mnt/d/personal/models/elx3/td_flash-next_4.05bpw_h6_ng6
fi
for variable in ${!EXL3_@}; do unset "$variable"; done
export PYTHONPATH="$REPO" PYTHONDONTWRITEBYTECODE=1 PYTHONUNBUFFERED=1
export PYTORCH_ALLOC_CONF=backend:native
for kv in $EXTRA; do export "$kv"; done
cd "$REPO"
git diff --exit-code --quiet
git diff --cached --exit-code --quiet
"$PYTHON" - "$REPO" > "$OUT/$NAME-runtime.json" <<'PY'
import sys, pathlib, hashlib, json, subprocess, os
import torch, exllamav3
from exllamav3.ext import exllamav3_ext
root = pathlib.Path(sys.argv[1]).resolve()
module = pathlib.Path(exllamav3.__file__).resolve()
extension = pathlib.Path(exllamav3_ext.__file__).resolve()
assert root in module.parents, module
assert root in extension.parents, extension
assert torch.cuda.is_available()
print(json.dumps({
    'source':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
    'module':str(module),'extension':str(extension),
    'extensionSha256':hashlib.sha256(extension.read_bytes()).hexdigest(),
    'python':sys.version,'torch':str(torch.__version__),'cuda':str(torch.version.cuda),
    'environment':{k:v for k,v in os.environ.items() if k.startswith('EXL3_') or k in ['PYTORCH_ALLOC_CONF','PYTHONPATH']}
}))
PY
printf 'start %s\n' "$(date -Iseconds)" > "$OUT/$NAME-status.txt"
printf '%s\n' '-mcs 410 -mct 12 -cs 32768 -chunk_size 4096 -ngr -max_length 32768' > "$OUT/$NAME-args.txt"
set +e
timeout --kill-after=20s 1200 "$PYTHON" eval/perf.py -m "$MODEL" -mcs 410 -mct 12 -cs 32768 -chunk_size 4096 -ngr -max_length 32768 \
    > "$OUT/$NAME.txt" 2> "$OUT/$NAME-stderr.txt"
RESULT=$?
printf 'exit_code %s\nend %s\n' "$RESULT" "$(date -Iseconds)" >> "$OUT/$NAME-status.txt"
printf '%s exit_code=%s\n' "$NAME" "$RESULT"
exit "$RESULT"
