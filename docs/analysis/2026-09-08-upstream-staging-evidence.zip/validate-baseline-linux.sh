#!/bin/bash
set -eu
cd /opt/exllamav3-incremental-20260907
export PYTHONPATH=$PWD PYTHONDONTWRITEBYTECODE=1
OUT=/mnt/c/Users/denys/Documents/GitHub/SiftKit/.scratch-upstream-staging
set +e
/opt/exl3/bin/python -m pytest tests/test_moe_cpu_pool_.py -q > "$OUT/linux-baseline-tests.txt" 2>&1
result=$?
printf '%s\n' "$result" > "$OUT/linux-baseline-tests-status.txt"
exit "$result"
