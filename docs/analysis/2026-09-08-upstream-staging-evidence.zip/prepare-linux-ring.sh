#!/bin/bash
set -eu
OUT=/mnt/c/Users/denys/Documents/GitHub/SiftKit/.scratch-upstream-staging
REPO=/opt/exllamav3-incremental-20260907
cd "$REPO"
git diff --exit-code --quiet
git diff --cached --exit-code --quiet
git fetch "$OUT/ring.bundle" refs/heads/perf/staging-piece-ring:refs/heads/perf/staging-piece-ring
git switch perf/staging-piece-ring
export CUDA_HOME=/usr/local/cuda-13.2
export PATH=/opt/exl3/bin:$CUDA_HOME/bin:$PATH
export TORCH_CUDA_ARCH_LIST=8.9 MAX_JOBS=12 PYTHONDONTWRITEBYTECODE=1 PYTHONPATH="$REPO"
set +e
/opt/exl3/bin/python setup.py build_ext --inplace > "$OUT/linux-ring-build.txt" 2> "$OUT/linux-ring-build-stderr.txt"
result=$?
printf '%s\n' "$result" > "$OUT/linux-ring-build-status.txt"
if [ "$result" != 0 ]; then exit "$result"; fi
mkdir -p "$OUT/native/linux/ring"
cp exllamav3_ext.cpython-313-x86_64-linux-gnu.so "$OUT/native/linux/ring/"
bash "$OUT/validate-linux-ring.sh"
exit $?
