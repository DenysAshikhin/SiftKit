#!/bin/bash
set -eu
OUT=/mnt/c/Users/denys/Documents/GitHub/SiftKit/.scratch-upstream-staging
REPO=/opt/exllamav3-incremental-20260907
cd "$REPO"
git diff --exit-code --quiet
git diff --cached --exit-code --quiet
git fetch "$OUT/ring-probe.bundle" refs/heads/perf/staging-piece-ring-probe:refs/heads/perf/staging-piece-ring-probe
git switch perf/staging-piece-ring-probe
cp "$OUT/native/linux/ring/exllamav3_ext.cpython-313-x86_64-linux-gnu.so" .
export PYTHONPATH="$REPO" PYTHONDONTWRITEBYTECODE=1
set +e
/opt/exl3/bin/python -m pytest tests/test_moe_bandwidth_probe.py tests/test_moe_staging_geometry.py \
  tests/test_moe_staging_pieces.py tests/test_moe_staging_workers.py -q > "$OUT/linux-ring-probe-tests.txt" 2>&1
result=$?
printf '%s\n' "$result" > "$OUT/linux-ring-probe-tests-status.txt"
exit "$result"
