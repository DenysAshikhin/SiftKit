#!/bin/bash
set -eu
OUT=/mnt/c/Users/denys/Documents/GitHub/SiftKit/.scratch-upstream-staging
REPO=/opt/exllamav3-incremental-20260907
cd "$REPO"
export PYTHONPATH="$REPO" PYTHONDONTWRITEBYTECODE=1
set +e
/opt/exl3/bin/python -m pytest tests/test_moe_staging_geometry.py tests/test_moe_staging_pieces.py \
  tests/test_moe_staging_workers.py tests/test_moe_cpu_pool_.py -q > "$OUT/linux-ring-tests.txt" 2>&1
result=$?
printf '%s\n' "$result" > "$OUT/linux-ring-tests-status.txt"
if [ "$result" != 0 ]; then exit "$result"; fi
/opt/exl3/bin/python -m pytest "$OUT/validation/test_moe_cpu_offload.py" -q > "$OUT/linux-ring-broader.txt" 2>&1
result=$?
printf '%s\n' "$result" > "$OUT/linux-ring-broader-status.txt"
exit "$result"
