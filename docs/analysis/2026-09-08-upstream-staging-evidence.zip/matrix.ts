import { execFileSync, spawn } from 'node:child_process';
import { copyFileSync, existsSync, readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { resolve } from 'node:path';
import { z } from 'zod';
import { runRecordSchema } from './metrics.ts';

const platform = z.enum(['windows', 'linux']).parse(process.argv[2]);
const label = z.string().regex(/^[a-z0-9-]+$/).parse(process.argv[3] ?? 'matrix');
const caseSchema = z.object({
  name: z.string().regex(/^[a-z0-9-]+$/), ref: z.string().regex(/^(baseline|perf)\/[a-z0-9-]+$/),
  source: z.string().regex(/^[a-f0-9]{40}$/), nativeTree: z.string().regex(/^[a-f0-9]{40}$/),
  artifact: z.string().regex(/^[a-z0-9-]+$/),
  windowsSha256: z.string().regex(/^[a-f0-9]{64}$/), linuxSha256: z.string().regex(/^[a-f0-9]{64}$/),
});
const cases = z.array(caseSchema).min(2).parse(JSON.parse(readFileSync('.scratch-upstream-staging/cases.json', 'utf8')));
const base = cases[0]; // The first case is the control and is restored when the set finishes.
if (base === undefined) throw new Error('Control case missing');
const directory = resolve('.scratch-upstream-staging');
const repo = resolve('pristine_exle/exllamav3-incremental');
const statePath = resolve(directory, `${platform}-${label}-matrix-state.json`);
const knownWindowsHashes = new Set(cases.map(entry => entry.windowsSha256));

function git(args: string[]) {
  return execFileSync('git', ['-C', repo, ...args], { encoding: 'utf8' }).trim();
}
function sha256(path: string) {
  return createHash('sha256').update(readFileSync(path)).digest('hex');
}
async function command(program: string, args: string[]) {
  await new Promise<void>((done, reject) => {
    const child = spawn(program, args, { cwd: process.cwd(), stdio: 'inherit', windowsHide: true });
    child.on('error', reject);
    child.on('close', (code, signal) => {
      if (code === 0) done();
      else reject(new Error(`${program} exited ${code}, signal ${signal}`));
    });
  });
}
async function select(entry: z.infer<typeof caseSchema>) {
  if (platform === 'windows') {
    if (git(['status', '--porcelain', '--untracked-files=no'])) throw new Error('Tracked worktree is dirty');
    git(['switch', entry.ref]);
    if (git(['rev-parse', 'HEAD']) !== entry.source ||
        git(['rev-parse', 'HEAD:exllamav3/exllamav3_ext']) !== entry.nativeTree) throw new Error('Source identity mismatch');
    const source = resolve(directory, 'native/windows', entry.artifact, 'exllamav3_ext.cp313-win_amd64.pyd');
    const target = resolve(repo, 'exllamav3_ext.cp313-win_amd64.pyd');
    if (sha256(source) !== entry.windowsSha256) throw new Error('Cached native binary changed');
    if (existsSync(target) && !knownWindowsHashes.has(sha256(target))) throw new Error('Refusing to overwrite an unrecognized native binary');
    copyFileSync(source, target);
  } else {
    await command('C:/Windows/System32/wsl.exe', ['-d', 'SiftKit-EXL3-Perf-20260905', '--exec', 'bash',
      '/mnt/c/Users/denys/Documents/GitHub/SiftKit/.scratch-upstream-staging/select-linux-case.sh',
      entry.ref, entry.source, entry.nativeTree, entry.artifact, entry.linuxSha256]);
  }
}

function checkResult(path: string, name: string, entry: z.infer<typeof caseSchema>) {
  const record = runRecordSchema.parse(JSON.parse(readFileSync(path, 'utf8')));
  if (record.name !== name || record.runtime.source !== entry.source ||
      record.runtime.extensionSha256 !== (platform === 'windows' ? entry.windowsSha256 : entry.linuxSha256)) {
    throw new Error(`Result identity mismatch: ${name}`);
  }
}

try {
  for (let index = 1; index <= 5; index++) {
    const ordered = index % 2 ? cases : [...cases].reverse();
    for (const entry of ordered) {
      const name = `${platform}-${label}-${entry.name}-${index}`;
      const resultPath = resolve(directory, `${name}-result.json`);
      if (existsSync(resultPath)) {
        checkResult(resultPath, name, entry);
        continue;
      }
      writeFileSync(statePath, JSON.stringify({ status: 'running', name, index, entry }, null, 2));
      await select(entry);
      await command(process.execPath, ['--experimental-strip-types', resolve(directory, 'run.ts'),
        platform, `${label}-${entry.name}`, '1', String(index)]);
      checkResult(resultPath, name, entry);
    }
  }
  await select(base);
  writeFileSync(statePath, JSON.stringify({ status: 'completed', finished: new Date().toISOString() }, null, 2));
} catch (error) {
  writeFileSync(statePath, JSON.stringify({ status: 'failed',
    error: error instanceof Error ? error.message : 'Unexpected matrix failure' }, null, 2));
  throw error;
}
