#!/bin/bash
set -eu
OUT=/mnt/c/Users/denys/Documents/GitHub/SiftKit/.scratch-upstream-staging
REPO=/opt/exllamav3-incremental-20260907
cd "$REPO"
export PYTHONPATH="$REPO" PYTHONDONTWRITEBYTECODE=1
/opt/exl3/bin/python -m pytest "$OUT/validation/test_moe_cpu_offload.py" -q > "$OUT/linux-pool-broader.txt" 2>&1
git switch perf/staging-probe-retry
cp "$OUT/native/linux/base/exllamav3_ext.cpython-313-x86_64-linux-gnu.so" .
/opt/exl3/bin/python -m pytest tests/test_moe_bandwidth_probe.py -q > "$OUT/linux-probe-green.txt" 2>&1
git switch baseline/upstream-dev-20260907
printf '0\n' > "$OUT/linux-extra-validation-status.txt"
