$ErrorActionPreference = 'Stop'
$pagefileIdentity = [Security.Principal.WindowsIdentity]::GetCurrent()
$pagefilePrincipal = [Security.Principal.WindowsPrincipal]::new($pagefileIdentity)
if (-not $pagefilePrincipal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    throw 'Administrator privileges are required. No settings changed.'
}
$pagefileSettings = @(Get-CimInstance Win32_PageFileSetting | Where-Object { $_.Name -ieq 'D:\pagefile.sys' })
if ($pagefileSettings.Count -ne 1) { throw 'Expected exactly one D:\pagefile.sys configuration. No settings changed.' }
$pagefileSetting = $pagefileSettings[0]
if ($pagefileSetting.InitialSize -ne 16 -or $pagefileSetting.MaximumSize -ne 64000) {
    throw 'Pagefile settings differ from the reviewed 16/64000 MB configuration. No settings changed.'
}
$pagefileUsage = @(Get-CimInstance Win32_PageFileUsage | Where-Object { $_.Name -ieq 'D:\pagefile.sys' })
if ($pagefileUsage.Count -ne 1) { throw 'Expected one allocated D:\pagefile.sys. No settings changed.' }
$pagefileDisk = Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='D:'"
$pagefileGrowth = [Math]::Max(0, 32768MB - $pagefileUsage[0].AllocatedBaseSize * 1MB)
if (-not $pagefileDisk -or $pagefileDisk.FreeSpace -lt $pagefileGrowth) {
    throw 'D: has insufficient free space for the requested initial size. No settings changed.'
}
$pagefileSetting | Set-CimInstance -Property @{ InitialSize = [uint32]32768 }
Get-CimInstance Win32_PageFileSetting | Select-Object Name,InitialSize,MaximumSize | Format-Table
Get-CimInstance Win32_PageFileUsage | Select-Object Name,AllocatedBaseSize,CurrentUsage | Format-Table
Write-Output 'Initial size configured as 32768 MB; maximum unchanged. No reboot was initiated.'
Write-Output 'If allocated size remains below 32768 MB, a user-controlled restart may be needed.'
