#!/bin/bash
set -eu
REF=$1
SOURCE=$2
NATIVE=$3
ARTIFACT=$4
HASH=$5
REPO=/opt/exllamav3-incremental-20260907
OUT=/mnt/c/Users/denys/Documents/GitHub/SiftKit/.scratch-upstream-staging
cd "$REPO"
git diff --exit-code --quiet
git diff --cached --exit-code --quiet
git switch "$REF"
test "$(git rev-parse HEAD)" = "$SOURCE"
test "$(git rev-parse HEAD:exllamav3/exllamav3_ext)" = "$NATIVE"
ASSET="$OUT/native/linux/$ARTIFACT/exllamav3_ext.cpython-313-x86_64-linux-gnu.so"
ACTUAL=$(sha256sum "$ASSET")
test "${ACTUAL%% *}" = "$HASH"
cp "$ASSET" "$REPO/exllamav3_ext.cpython-313-x86_64-linux-gnu.so"
