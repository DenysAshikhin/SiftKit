@echo off
set PATH=C:\Program Files (x86)\Microsoft Visual Studio\Installer;%PATH%
call "C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars64.bat" >nul
set T=D:\personal\models\elx3\.tmp\turbo-match\cuda-13.2.2-build\toolkit
cd /d C:\Users\denys\Documents\GitHub\SiftKit\.scratch-staging
cl /nologo /O2 /arch:AVX2 /EHsc /I"%T%\include" stagepipe.cpp /Fe:stagepipe.exe /link /LIBPATH:"%T%\lib\x64" cudart_static.lib >build_pipe.log 2>&1
type build_pipe.log
