#!/bin/bash
# Decisive correctness pair: same warm-pass harness with the cache off vs on (two cache runs).
export PATH="/c/personal/Git/usr/bin:$PATH"
export MSYS_NO_PATHCONV=1 MSYS2_ARG_CONV_EXCL='*'
cd "C:/Users/denys/Documents/GitHub/SiftKit/.scratch-staging"
P="progress_logits_cache2.txt"
PY='C:/envs/rl313-turbo/Scripts/python.exe'
M='D:/personal/models/elx3/td_flash-next_4.05bpw_h6_ng6'
export PYTHONPATH='C:/Users/denys/Documents/GitHub/SiftKit/pristine_exle/exllamav3-upstream'
export PYTHONDONTWRITEBYTECODE=1 PYTHONUNBUFFERED=1 PYTORCH_ALLOC_CONF='backend:native' EXL3_LOAD_ARENA=1
B="EXL3_MOE_CPU_WSLOT_MB=64 EXL3_MOE_STREAM_BATCH_EXPERTS=24 EXL3_MOE_CPU_STAGE_THREADS=4 EXL3_MOE_MEMOPS=1 EXL3_MOE_CPU_PIECE_EXPERTS=5 EXL3_MOE_CPU_PIECES=2 EXL3_MOE_STREAM_T=8"
echo "start $(date)" >> "$P"
env $B $PY logits_check_cache.py --save logits_warm_nocache.pt -m "$M" -mcs 410 -mct 12 -cs 32768 > logits_warm_nocache.log 2>&1
echo "warm_nocache exit_code=$?" >> "$P"
env $B EXL3_MOE_CPU_PIN_CACHE_MB=2048 $PY logits_check_cache.py --save logits_cache2.pt -m "$M" -mcs 410 -mct 12 -cs 32768 > logits_cache2.log 2>&1
echo "cache2 exit_code=$?" >> "$P"
env $B EXL3_MOE_CPU_PIN_CACHE_MB=2048 $PY logits_check_cache.py --save logits_cache3.pt -m "$M" -mcs 410 -mct 12 -cs 32768 > logits_cache3.log 2>&1
echo "cache3 exit_code=$?" >> "$P"
for pair in "logits_warm_nocache.pt logits_cache2.pt" "logits_warm_nocache.pt logits_cache3.pt" "logits_cache2.pt logits_cache3.pt" "logits_base.pt logits_warm_nocache.pt"; do
  echo "compare $pair: $($PY compare_pt.py $pair 2>&1 | tail -1)" >> "$P"
done
echo "DONE $(date)" >> "$P"
