#!/bin/bash
# Piece-ring prototype: correctness (baseline vs piece mode logits) then the performance sweep.
export PATH="/c/personal/Git/usr/bin:$PATH"
export MSYS_NO_PATHCONV=1 MSYS2_ARG_CONV_EXCL='*'
cd "C:/Users/denys/Documents/GitHub/SiftKit/.scratch-staging"
P="progress_sweep2.txt"
PY='C:/envs/rl313-turbo/Scripts/python.exe'
export PYTHONPATH='C:/Users/denys/Documents/GitHub/SiftKit/pristine_exle/exllamav3-upstream'
export PYTHONDONTWRITEBYTECODE=1 PYTHONUNBUFFERED=1 PYTORCH_ALLOC_CONF='backend:native'
export EXL3_LOAD_ARENA=1 EXL3_MOE_MEMOPS=0
M='D:/personal/models/elx3/td_flash-next_4.05bpw_h6_ng6'
echo "logits start $(date)" >> "$P"
$PY logits_check_up.py --save logits_base.pt -m "$M" -mcs 410 -mct 12 -cs 32768 > logits_base.log 2>&1
echo "logits_base exit_code=$?" >> "$P"
EXL3_MOE_CPU_WSLOT_MB=64 EXL3_MOE_STREAM_BATCH_EXPERTS=24 EXL3_MOE_CPU_PIECE_EXPERTS=3 EXL3_MOE_CPU_PIECES=2 \
  $PY logits_check_up.py --save logits_piece.pt -m "$M" -mcs 410 -mct 12 -cs 32768 > logits_piece.log 2>&1
echo "logits_piece exit_code=$?" >> "$P"
$PY compare_pt.py logits_base.pt logits_piece.pt > logits_compare.txt 2>&1
echo "compare: $(cat logits_compare.txt)" >> "$P"
bash ./run_sweep2.sh
