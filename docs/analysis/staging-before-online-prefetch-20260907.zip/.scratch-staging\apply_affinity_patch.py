"""EXL3_MOE_STAGE_CPUS="16,18,20,22" (or ranges "16-22"): pin the stager thread (index 0) and
the stage-pool helpers (1..n) to the listed logical CPUs, round-robin. The compute pool already
pins one worker per physical core (physical-core-first order), so unpinned stager threads land
on SMT siblings of busy cores; this lets them take the cores the pool leaves free."""
import os

root = os.path.join(os.path.dirname(__file__), "..", "pristine_exle", "exllamav3-upstream")


def patch(rel, pairs):
    p = os.path.join(root, rel)
    s = open(p, encoding="utf-8").read()
    for a, b in pairs:
        assert s.count(a) == 1, (rel, a[:70])
        s = s.replace(a, b)
    open(p, "w", encoding="utf-8", newline="\n").write(s)


patch("exllamav3/exllamav3_ext/cpu/moe_mul1.h", [
    ('''// Packed bytes of one expert of the layer (gate + up + down trellis), the per-expert stride
''', '''// Pin the calling stager thread (0 = stager, 1.. = pool helpers) to EXL3_MOE_STAGE_CPUS[idx mod n];
// no-op when the variable is unset
void exl3_moe_cpu_stage_pin(int idx);

// Packed bytes of one expert of the layer (gate + up + down trellis), the per-expert stride
'''),
])

patch("exllamav3/exllamav3_ext/cpu/moe_mul1.cpp", [
    ('''namespace {

// Persistent helper threads for stage_experts''', '''namespace {

// EXL3_MOE_STAGE_CPUS, parsed once: comma-separated logical CPU indices or ranges ("16-22")
const std::vector<int>& stage_cpus()
{
    static const std::vector<int> v = []()
    {
        std::vector<int> out;
        const char* e = getenv("EXL3_MOE_STAGE_CPUS");
        if (!e) return out;
        std::string s(e);
        size_t i = 0;
        while (i < s.size())
        {
            size_t j = s.find(',', i);
            if (j == std::string::npos) j = s.size();
            std::string tok = s.substr(i, j - i);
            size_t dash = tok.find('-');
            if (dash == std::string::npos) { if (!tok.empty()) out.push_back(atoi(tok.c_str())); }
            else
            {
                int a = atoi(tok.substr(0, dash).c_str()), b = atoi(tok.substr(dash + 1).c_str());
                for (int c = a; c <= b; ++c) out.push_back(c);
            }
            i = j + 1;
        }
        return out;
    }();
    return v;
}

} // namespace

void exl3_moe_cpu_stage_pin(int idx)
{
    const std::vector<int>& cpus = stage_cpus();
    if (cpus.empty()) return;
    const int cpu = cpus[idx % cpus.size()];
#ifdef __linux__
    cpu_set_t set;
    CPU_ZERO(&set);
    CPU_SET(cpu, &set);
    pthread_setaffinity_np(pthread_self(), sizeof(set), &set);
#else
    SetThreadAffinityMask(GetCurrentThread(), DWORD_PTR(1) << cpu);
#endif
}

namespace {

// Persistent helper threads for stage_experts'''),
    ('''    void loop(int worker)
    {
        uint32_t seen = 0;
        int idle = 0;
''', '''    void loop(int worker)
    {
        exl3_moe_cpu_stage_pin(worker);
        uint32_t seen = 0;
        int idle = 0;
'''),
])

patch("exllamav3/exllamav3_ext/cpu/moe_handoff.cu", [
    ('''    std::thread stager([&]()
    {
        uint32_t shead = load_acquire_u32(stage_head);
''', '''    std::thread stager([&]()
    {
        exl3_moe_cpu_stage_pin(0);
        uint32_t shead = load_acquire_u32(stage_head);
'''),
])
print("affinity ok")
