"""EXL3_MOE_STREAM_PROF=1: per-piece DMA event pairs on the copy stream (DMA-active time and
bytes), host time inside submit_prefill, and the wall span of back-to-back submits. Printed at
shutdown. Python only."""
import os

p = os.path.join(os.path.dirname(__file__), "..", "pristine_exle", "exllamav3-upstream",
                 "exllamav3", "model", "moe_cpu_host.py")
s = open(p, encoding="utf-8").read()


def rep(a, b):
    global s
    assert s.count(a) == 1, a[:70]
    s = s.replace(a, b)


rep('''        self.stream_trace = os.environ.get("EXL3_MOE_STREAM_TRACE")
''', '''        self.stream_trace = os.environ.get("EXL3_MOE_STREAM_TRACE")
        self.stream_prof = bool(os.environ.get("EXL3_MOE_STREAM_PROF"))
''')
rep('''        self.cache_slots = 0          # set in ensure_started; zero keeps shutdown's report quiet
        self.cache_total_b = 0
''', '''        self.cache_slots = 0          # set in ensure_started; zero keeps shutdown's report quiet
        self.cache_total_b = 0
        self.prof = dict(host_s = 0.0, span_s = 0.0, last_t = None, dma_ev = [], dma_b = 0,
                         pieces = 0, batches = 0, submits = 0)
''')
rep('''    def submit_prefill(self, layer_idx, y, selected_experts, routing_weights):
        """''', '''    def submit_prefill(self, layer_idx, y, selected_experts, routing_weights):
        if not TUNING.stream_prof:
            return self._submit_prefill(layer_idx, y, selected_experts, routing_weights)
        import time
        t0 = time.perf_counter()
        pr = self.prof
        if pr["last_t"] is not None and t0 - pr["last_t"] < 1.0:
            pr["span_s"] += t0 - pr["last_t"]
        try:
            return self._submit_prefill(layer_idx, y, selected_experts, routing_weights)
        finally:
            t1 = time.perf_counter()
            pr["host_s"] += t1 - t0
            pr["span_s"] += t1 - t0
            pr["last_t"] = t1
            pr["submits"] += 1

    def _submit_prefill(self, layer_idx, y, selected_experts, routing_weights):
        """''')
rep('''            used = (len(batch) * exp_b) // 2
            with torch.cuda.stream(copy_stream):
''', '''            used = (len(batch) * exp_b) // 2
            pr = self.prof if TUNING.stream_prof else None
            if pr is not None:
                pr["batches"] += 1
            with torch.cuda.stream(copy_stream):
''')
rep('''                        ext.exl3_moe_flag_wait(self.stage_done_addr[ws], g + 1, abort)
                        st["vram_slots"][ws][(k * exp_b) // 2 : (k * exp_b + n * exp_b) // 2].copy_(
                            pv[:(n * exp_b) // 2], non_blocking = True)
                        ext.exl3_moe_flag_write(self.pinned_free_addr[p], r + 1)
''', '''                        ext.exl3_moe_flag_wait(self.stage_done_addr[ws], g + 1, abort)
                        if pr is not None:
                            e0 = torch.cuda.Event(enable_timing = True)
                            e0.record(copy_stream)
                        st["vram_slots"][ws][(k * exp_b) // 2 : (k * exp_b + n * exp_b) // 2].copy_(
                            pv[:(n * exp_b) // 2], non_blocking = True)
                        if pr is not None:
                            e1 = torch.cuda.Event(enable_timing = True)
                            e1.record(copy_stream)
                            pr["dma_ev"].append((e0, e1))
                            pr["dma_b"] += n * exp_b
                            pr["pieces"] += 1
                        ext.exl3_moe_flag_write(self.pinned_free_addr[p], r + 1)
''')
rep('''    def shutdown(self):
        if self.cache_slots and self.cache_total_b:
''', '''    def shutdown(self):
        pr = self.prof
        if TUNING.stream_prof and pr["pieces"]:
            torch.cuda.synchronize()
            dma_s = sum(a.elapsed_time(b) for a, b in pr["dma_ev"]) * 1e-3
            print(f" -- stream prof: {pr['submits']} submits, {pr['batches']} batches, "
                  f"{pr['pieces']} ring pieces, {pr['dma_b'] / 1e9:.1f} GB via ring; "
                  f"DMA active {dma_s:.2f} s ({pr['dma_b'] / max(dma_s, 1e-9) / 1e9:.1f} GB/s while active), "
                  f"host in submit {pr['host_s']:.2f} s, submit span {pr['span_s']:.2f} s "
                  f"(DMA duty {100 * dma_s / max(pr['span_s'], 1e-9):.0f}%, host busy "
                  f"{100 * pr['host_s'] / max(pr['span_s'], 1e-9):.0f}%)")
        if self.cache_slots and self.cache_total_b:
''')
open(p, "w", encoding="utf-8", newline="\n").write(s)
print("prof ok")
