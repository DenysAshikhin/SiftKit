"""Cache prototype fix 1: cache fills must not advance the ring's slot/gating counter. Split the
global piece counter (stage_done signalling) from the ring counter (slot selection, pinned_free
gating) on both sides."""
import os

root = os.path.join(os.path.dirname(__file__), "..", "pristine_exle", "exllamav3-upstream")


def patch(rel, pairs):
    p = os.path.join(root, rel)
    s = open(p, encoding="utf-8").read()
    for a, b in pairs:
        assert s.count(a) == 1, (rel, a[:70])
        s = s.replace(a, b)
    open(p, "w", encoding="utf-8", newline="\n").write(s)


patch("exllamav3/exllamav3_ext/cpu/moe_handoff.cu", [
    ('''        uint32_t s_gpiece = 0;
''', '''        uint32_t s_gpiece = 0;   // every piece (ring or cache fill): stage_done value - 1
        uint32_t s_rpiece = 0;   // ring pieces only: slot = r % depth, gate on pinned_free
'''),
    ('''                    const uint32_t g = s_gpiece;
                    const uint32_t p = g % np;
                    uint32_t* pf = pinned_free + size_t(p) * 16;
                    const uint32_t need = g - np + 1;
''', '''                    const uint32_t g = s_gpiece;
                    const uint32_t r = s_rpiece;
                    const uint32_t p = r % np;
                    uint32_t* pf = pinned_free + size_t(p) * 16;
                    const uint32_t need = r - np + 1;
'''),
    ('''                    s_gpiece = g + 1;
                    store_release_u32(stage_done + size_t(job.slot) * 16, g + 1);
                    k += n;
''', '''                    s_gpiece = g + 1;
                    s_rpiece = r + 1;
                    store_release_u32(stage_done + size_t(job.slot) * 16, g + 1);
                    k += n;
'''),
])

patch("exllamav3/model/moe_cpu_host.py", [
    ('''                        g = self.piece_seq
                        self.piece_seq += 1
                        p = g % self.pieces
                        pv = pviews[p]
                        ext.exl3_moe_flag_wait(self.stage_done_addr[ws], g + 1, abort)
                        st["vram_slots"][ws][(k * exp_b) // 2 : (k * exp_b + n * exp_b) // 2].copy_(
                            pv[:(n * exp_b) // 2], non_blocking = True)
                        ext.exl3_moe_flag_write(self.pinned_free_addr[p], g + 1)
''', '''                        g = self.piece_seq
                        self.piece_seq += 1
                        r = self.ring_seq
                        self.ring_seq += 1
                        p = r % self.pieces
                        pv = pviews[p]
                        ext.exl3_moe_flag_wait(self.stage_done_addr[ws], g + 1, abort)
                        st["vram_slots"][ws][(k * exp_b) // 2 : (k * exp_b + n * exp_b) // 2].copy_(
                            pv[:(n * exp_b) // 2], non_blocking = True)
                        ext.exl3_moe_flag_write(self.pinned_free_addr[p], r + 1)
'''),
])
print("fix1 ok")
