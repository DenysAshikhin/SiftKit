#!/bin/bash
# Resident pinned subset: byte-level verify at 10 GB, then 10 / 20 / 40 GB perf runs.
export PATH="/c/personal/Git/usr/bin:$PATH"
export MSYS_NO_PATHCONV=1 MSYS2_ARG_CONV_EXCL='*'
cd "C:/Users/denys/Documents/GitHub/SiftKit/.scratch-staging"
R="./run_upstream.sh"
P="progress_batchE.txt"
PY='C:/envs/rl313-turbo/Scripts/python.exe'
M='D:/personal/models/elx3/td_flash-next_4.05bpw_h6_ng6'
export PYTHONPATH='C:/Users/denys/Documents/GitHub/SiftKit/pristine_exle/exllamav3-upstream'
export PYTHONDONTWRITEBYTECODE=1 PYTHONUNBUFFERED=1 PYTORCH_ALLOC_CONF='backend:native' EXL3_LOAD_ARENA=1
A="-mcs 410 -mct 12 -cs 32768 -chunk_size 4096 -ngr -max_length 32768 -sg"
B="EXL3_MOE_STREAM_BATCH_EXPERTS=24 EXL3_MOE_CPU_STAGE_THREADS=4 EXL3_MOE_MEMOPS=1 EXL3_MOE_CPU_PIECE_EXPERTS=5 EXL3_MOE_CPU_PIECES=2 EXL3_MOE_STREAM_T=8"
echo "start $(date)" >> "$P"
env $B EXL3_MOE_CPU_WSLOT_MB=128 EXL3_MOE_CPU_PIN_RESIDENT_MB=10240 EXL3_MOE_CPU_PIN_CACHE_VERIFY=1 $PY logits_check_up.py --save logits_resident.pt -m "$M" -mcs 410 -mct 12 -cs 32768 > logits_resident.log 2>&1
echo "logits_resident exit_code=$? $(grep -a 'pin cache verify\|resident subset' logits_resident.log | tr '\n' ' ')" >> "$P"
echo "compare base vs resident: $($PY compare_pt.py logits_base.pt logits_resident.pt 2>&1 | tail -1)" >> "$P"
bash "$R" u-E-res10 "$B EXL3_MOE_CPU_WSLOT_MB=64 EXL3_MOE_CPU_PIN_RESIDENT_MB=10240" $A >> "$P" 2>&1
bash "$R" u-E-res20 "$B EXL3_MOE_CPU_WSLOT_MB=64 EXL3_MOE_CPU_PIN_RESIDENT_MB=20480" $A >> "$P" 2>&1
bash "$R" u-E-res40 "$B EXL3_MOE_CPU_WSLOT_MB=64 EXL3_MOE_CPU_PIN_RESIDENT_MB=40960" $A >> "$P" 2>&1
echo "SWEEP DONE $(date)" >> "$P"
