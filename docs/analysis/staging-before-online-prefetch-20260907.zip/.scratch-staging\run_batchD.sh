#!/bin/bash
# Dedicated-L3 experiment: compute pool on CCD0 (-mct 6, physical-core-first), stager threads
# pinned to CCD1 (logical 12-23). Then piece-size re-sweep on the dedicated L3. Profilers on.
export PATH="/c/personal/Git/usr/bin:$PATH"
export MSYS_NO_PATHCONV=1 MSYS2_ARG_CONV_EXCL='*'
cd "C:/Users/denys/Documents/GitHub/SiftKit/.scratch-staging"
R="./run_upstream.sh"
P="progress_batchD.txt"
A="-mcs 410 -cs 32768 -chunk_size 4096 -ngr -max_length 32768 -sg"
B="EXL3_MOE_CPU_WSLOT_MB=64 EXL3_MOE_STREAM_BATCH_EXPERTS=24 EXL3_MOE_MEMOPS=1 EXL3_MOE_STREAM_T=8 EXL3_MOE_STREAM_PROF=1 EXL3_MOE_STAGE_PROF=1"
echo "start $(date)" >> "$P"
bash "$R" u-D-mct6-ccd1-5x2 "$B EXL3_MOE_CPU_STAGE_THREADS=6 EXL3_MOE_STAGE_CPUS=12-23 EXL3_MOE_CPU_PIECE_EXPERTS=5 EXL3_MOE_CPU_PIECES=2" -mct 6 $A >> "$P" 2>&1
bash "$R" u-D-mct6-ccd1-6x2 "$B EXL3_MOE_CPU_STAGE_THREADS=6 EXL3_MOE_STAGE_CPUS=12-23 EXL3_MOE_CPU_PIECE_EXPERTS=6 EXL3_MOE_CPU_PIECES=2" -mct 6 $A >> "$P" 2>&1
bash "$R" u-D-mct6-ccd1-8x2 "$B EXL3_MOE_CPU_STAGE_THREADS=6 EXL3_MOE_STAGE_CPUS=12-23 EXL3_MOE_CPU_PIECE_EXPERTS=8 EXL3_MOE_CPU_PIECES=2" -mct 6 $A >> "$P" 2>&1
bash "$R" u-D-mct6-ccd1-4x3 "$B EXL3_MOE_CPU_STAGE_THREADS=6 EXL3_MOE_STAGE_CPUS=12-23 EXL3_MOE_CPU_PIECE_EXPERTS=4 EXL3_MOE_CPU_PIECES=3" -mct 6 $A >> "$P" 2>&1
bash "$R" u-D-mct8-ccd1-5x2 "$B EXL3_MOE_CPU_STAGE_THREADS=4 EXL3_MOE_STAGE_CPUS=16-23 EXL3_MOE_CPU_PIECE_EXPERTS=5 EXL3_MOE_CPU_PIECES=2" -mct 8 $A >> "$P" 2>&1
echo "SWEEP DONE $(date)" >> "$P"
