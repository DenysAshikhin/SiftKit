#!/bin/bash
# usage: run_upstream.sh <name> "<extra env assignments>" <perf args...>
set -u
NAME="$1"; EXTRA="$2"; shift 2
cd "C:/Users/denys/Documents/GitHub/SiftKit"
OUT=".scratch-staging"
export PYTHONPATH='C:/Users/denys/Documents/GitHub/SiftKit/pristine_exle/exllamav3-upstream'
export PYTHONDONTWRITEBYTECODE=1 PYTHONUNBUFFERED=1
export PYTORCH_ALLOC_CONF='backend:native'
export EXL3_LOAD_ARENA=1 EXL3_MOE_MEMOPS=0
for kv in $EXTRA; do export "$kv"; done
env | grep -E '^(PYTHONPATH|PYTORCH_ALLOC_CONF|EXL3_)' > "$OUT/$NAME-env.txt"
echo "args: $*" >> "$OUT/$NAME-env.txt"
echo "start $(date -Iseconds)" > "$OUT/$NAME-status.txt"
'C:/envs/rl313-turbo/Scripts/python.exe' pristine_exle/exllamav3-upstream/eval/perf.py \
  -m 'D:/personal/models/elx3/td_flash-next_4.05bpw_h6_ng6' "$@" \
  > "$OUT/$NAME.txt" 2> "$OUT/$NAME-stderr.txt"
RC=$?
echo "exit_code $RC" >> "$OUT/$NAME-status.txt"
echo "end $(date -Iseconds)" >> "$OUT/$NAME-status.txt"
echo "$NAME exit_code=$RC"
