import glob, re, os
os.chdir(os.path.dirname(os.path.abspath(__file__)))
rows = []
for f in sorted(glob.glob("u-*.txt")):
    if f.endswith("-stderr.txt") or f.endswith("-env.txt") or f.endswith("-status.txt"):
        continue
    txt = re.sub(r"\x1b\[[0-9;]*m", "", open(f, encoding="utf-8", errors="replace").read())
    pf = dict(re.findall(r"Length\s+(\d+):\s+([\d.]+) tokens/s", txt))
    env = open(f[:-4] + "-env.txt", encoding="utf-8").read() if os.path.exists(f[:-4] + "-env.txt") else ""
    w = re.search(r"WSLOT_MB=(\d+)", env); t = re.search(r"STAGE_THREADS=(\d+)", env)
    pe = re.search(r"PIECE_EXPERTS=(\d+)", env); pc = re.search(r"PIECES=(\d+)", env)
    be = re.search(r"BATCH_EXPERTS=(\d+)", env)
    piece = f"{pe.group(1)}x{pc.group(1) if pc else 2}" if pe else "off"
    st = open(f[:-4] + "-status.txt", encoding="utf-8").read() if os.path.exists(f[:-4] + "-status.txt") else ""
    rc = re.search(r"exit_code (\d+)", st)
    mo = re.search(r"MEMOPS=(\d)", env)
    rows.append((f[:-4], w.group(1) if w else "32", be.group(1) if be else "24", piece, t.group(1) if t else "4",
                 mo.group(1) if mo else "0",
                 *[pf.get(k, "") for k in ("4096", "8192", "16384", "32768")], rc.group(1) if rc else "running"))
print("| run | WSLOT_MB | BATCH | pieces | STAGE_THREADS | memops | 4k | 8k | 16k | 32k | exit |")
print("|---|---:|---:|---|---:|---:|---:|---:|---:|---:|---|")
for r in rows:
    print("| " + " | ".join(str(x) for x in r) + " |")
