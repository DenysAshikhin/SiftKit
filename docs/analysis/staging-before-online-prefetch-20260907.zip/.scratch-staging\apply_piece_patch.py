"""Prototype: decouple the pinned staging granularity from the VRAM compute batch.

With EXL3_MOE_CPU_PIECE_EXPERTS=N (N > 0), the stager copies each batch through a ring of
EXL3_MOE_CPU_PIECES small pinned pieces (N experts each) carved out of the existing pinned
wstage region, and the GPU DMAs each piece into its place in the (unchanged, large) VRAM slot.
The pinned working set is PIECES * N * expert_bytes (e.g. 2 * 3 * 2.4 MB = 14 MB), small
enough to stay in L3, while the compute batch stays at wslot_size / expert_bytes experts.

Flag protocol (piece mode): a global piece counter g (0-based, identical on both sides because
stage jobs are consumed in ring order). Worker: before writing piece g into ring slot p = g % P,
wait pinned_free[p] >= g - P + 1 (cyclic compare); after copying, stage_done[ws] = g + 1. GPU
copy stream: wait stage_done[ws] >= g + 1, DMA piece p -> vram_slot[ws] at expert offset,
write pinned_free[p] = g + 1. Job fields reused for the two parameters: topk = N, prev_seq = P.
"""
import os, sys
root = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "pristine_exle", "exllamav3-upstream", "exllamav3")

def patch(rel, edits):
    p = os.path.join(root, rel)
    s = open(p, encoding="utf-8").read()
    for old, new in edits:
        assert s.count(old) == 1, (rel, old[:80])
        s = s.replace(old, new)
    open(p, "w", encoding="utf-8", newline="\n").write(s)
    print("patched", rel)

patch("exllamav3_ext/cpu/moe_mul1.h", [(
"""void exl3_moe_cpu_stage_experts
(
    int64_t handle,
    const uint32_t* expert_ids,
    int count,
    uint8_t* dst,
    int threads
);
""",
"""void exl3_moe_cpu_stage_experts
(
    int64_t handle,
    const uint32_t* expert_ids,
    int count,
    uint8_t* dst,
    int threads
);

// Packed bytes of one expert of the layer (gate + up + down trellis), the per-expert stride
// used by stage_experts and by the parent's VRAM-side views
size_t exl3_moe_cpu_expert_bytes(int64_t handle);
""")])

patch("exllamav3_ext/cpu/moe_mul1.cpp", [(
"""bool exl3_moe_cpu_has_avx2() { return g_isa != Isa::Scalar; }""",
"""size_t exl3_moe_cpu_expert_bytes(int64_t handle)
{
    const MoeCpuLayer* layer = get_layer(handle);
    const bool gated = !layer->gates.empty();
    return (gated ? trellis_bytes(layer->gates[0]) : 0) + trellis_bytes(layer->ups[0]) + trellis_bytes(layer->downs[0]);
}

bool exl3_moe_cpu_has_avx2() { return g_isa != Isa::Scalar; }""")])

patch("exllamav3_ext/cpu/moe_handoff.cu", [(
"""            // Wait until the slot's previous tenant has been DMA'd out
            uint32_t* pf = pinned_free + size_t(job.slot) * 16;
            while ((int32_t)(load_acquire_u32(pf) - job.prev_seq) < 0)
            {
                if (load_acquire_u32(quit)) return;
                cpu_pause_();
            }
            exl3_moe_cpu_stage_experts(
                static_cast<int64_t>(job.layer),
                job.experts,
                static_cast<int>(job.rows),
                wstage + size_t(job.slot) * wslot_size,
                stage_threads_
            );
            store_release_u32(stage_done + size_t(job.slot) * 16, job.seq);
""",
"""            if (job.topk > 0)
            {
                // Piece mode (prototype): stream the batch through a ring of small pinned
                // pieces; topk = experts per piece, prev_seq = ring depth. See apply_piece_patch.py
                const uint32_t pe = job.topk, np = job.prev_seq;
                const size_t piece_bytes = size_t(pe) * exl3_moe_cpu_expert_bytes(static_cast<int64_t>(job.layer));
                for (uint32_t k = 0; k < job.rows; k += pe)
                {
                    const uint32_t n = (job.rows - k < pe) ? (job.rows - k) : pe;
                    const uint32_t g = s_gpiece;
                    const uint32_t p = g % np;
                    uint32_t* pf = pinned_free + size_t(p) * 16;
                    const uint32_t need = g - np + 1;
                    while ((int32_t)(load_acquire_u32(pf) - need) < 0)
                    {
                        if (load_acquire_u32(quit)) return;
                        cpu_pause_();
                    }
                    exl3_moe_cpu_stage_experts(
                        static_cast<int64_t>(job.layer),
                        job.experts + k,
                        static_cast<int>(n),
                        wstage + size_t(p) * piece_bytes,
                        stage_threads_
                    );
                    s_gpiece = g + 1;
                    store_release_u32(stage_done + size_t(job.slot) * 16, g + 1);
                }
                continue;
            }
            // Wait until the slot's previous tenant has been DMA'd out
            uint32_t* pf = pinned_free + size_t(job.slot) * 16;
            while ((int32_t)(load_acquire_u32(pf) - job.prev_seq) < 0)
            {
                if (load_acquire_u32(quit)) return;
                cpu_pause_();
            }
            exl3_moe_cpu_stage_experts(
                static_cast<int64_t>(job.layer),
                job.experts,
                static_cast<int>(job.rows),
                wstage + size_t(job.slot) * wslot_size,
                stage_threads_
            );
            store_release_u32(stage_done + size_t(job.slot) * 16, job.seq);
"""), (
"""        uint32_t shead = load_acquire_u32(stage_head);
        uint32_t s_last_wake = 0;
        int s_idle = 0;
""",
"""        uint32_t shead = load_acquire_u32(stage_head);
        uint32_t s_last_wake = 0;
        uint32_t s_gpiece = 0;
        int s_idle = 0;
""")])

patch("model/moe_cpu_host.py", [(
"""        self.stage_threads = int(os.environ.get("EXL3_MOE_CPU_STAGE_THREADS", 4))
""",
"""        self.stage_threads = int(os.environ.get("EXL3_MOE_CPU_STAGE_THREADS", 4))
        # Prototype piece ring (see apply_piece_patch.py): experts per pinned piece (0 = off)
        # and ring depth. Pinned working set = pieces * piece_experts * expert_bytes
        self.piece_experts = int(os.environ.get("EXL3_MOE_CPU_PIECE_EXPERTS", 0))
        self.pieces = int(os.environ.get("EXL3_MOE_CPU_PIECES", 2))
"""), (
"""        self.wseq = 0
""",
"""        self.wseq = 0
        self.piece_seq = 0
        self.piece_experts = TUNING.piece_experts
        self.pieces = TUNING.pieces
"""), (
"""                        for s in range(MOE_MAX_WSLOTS):
                            u32[(fl + s * 64) // 4] = wseq                          # stage_done
                            u32[(fl + 64 * MOE_MAX_WSLOTS + s * 64) // 4] = wseq    # pinned_free
""",
"""                        wseq = max(wseq, self.piece_seq + 1)
                        for s in range(MOE_MAX_WSLOTS):
                            u32[(fl + s * 64) // 4] = wseq                          # stage_done
                            u32[(fl + 64 * MOE_MAX_WSLOTS + s * 64) // 4] = wseq    # pinned_free
"""), (
"""            job[3] = 0
            job[4] = ws
            job[5] = 1    # MOE_JOB_KIND_STAGE
            job[6] = self.wslot_prev_seq[ws]
""",
"""            pe = self.piece_experts
            job[3] = pe
            job[4] = ws
            job[5] = 1    # MOE_JOB_KIND_STAGE
            job[6] = self.pieces if pe else self.wslot_prev_seq[ws]
"""), (
"""                ext.exl3_moe_flag_wait(self.stage_done_addr[ws], seq, abort)
                st["vram_slots"][ws][:used].copy_(self.wviews[ws][:used], non_blocking = True)
                ext.exl3_moe_flag_write(self.pinned_free_addr[ws], seq)
""",
"""                if pe:
                    piece_b = pe * exp_b
                    pviews = st.get("pviews")
                    if pviews is None or pviews[0].numel() * 2 != piece_b:
                        assert 1 <= self.pieces <= MOE_MAX_WSLOTS and \\
                            self.pieces * piece_b <= self.num_wslots * self.wslot_size, \\
                            "piece ring exceeds the pinned wstage region or MOE_MAX_WSLOTS"
                        pviews = [torch.frombuffer(self.shm.buf, dtype = torch.int16, count = piece_b // 2,
                                                   offset = self.layout["wstage_off"] + p * piece_b)
                                  for p in range(self.pieces)]
                        st["pviews"] = pviews
                    for k in range(0, len(batch), pe):
                        n = min(pe, len(batch) - k)
                        g = self.piece_seq
                        self.piece_seq += 1
                        p = g % self.pieces
                        pv = pviews[p]
                        ext.exl3_moe_flag_wait(self.stage_done_addr[ws], g + 1, abort)
                        st["vram_slots"][ws][(k * exp_b) // 2 : (k * exp_b + n * exp_b) // 2].copy_(
                            pv[:(n * exp_b) // 2], non_blocking = True)
                        ext.exl3_moe_flag_write(self.pinned_free_addr[p], g + 1)
                else:
                    ext.exl3_moe_flag_wait(self.stage_done_addr[ws], seq, abort)
                    st["vram_slots"][ws][:used].copy_(self.wviews[ws][:used], non_blocking = True)
                    ext.exl3_moe_flag_write(self.pinned_free_addr[ws], seq)
""")])
print("done")
