"""From a stream trace: how much of a layer's streamed set in chunk k was streamed in chunk k-1
(the accuracy of "prefetch the previous chunk's hot set"), by bytes, over the 4096-token chunks
of the 32k prefill. Also the miss volume that would still need a post-routing fetch."""
import sys
from sim_cache import load, split_prefills

calls = load(sys.argv[1])
prefills = split_prefills(calls)
eb = calls[0][2]
rows = []
for length, pf in prefills:
    if len(pf) < 2:
        continue
    prev = None
    for ch in pf:
        cur = {c[0]: set(c[3]) for c in ch}
        if prev is not None:
            tot = sum(len(v) for v in cur.values())
            hit = sum(len(cur[l] & prev.get(l, set())) for l in cur)
            extra = sum(len(prev.get(l, set()) - cur[l]) for l in cur)
            rows.append((length, tot, hit, extra))
        prev = cur
print("| prefill | chunk's streamed experts | in previous chunk's set | wasted prefetch (prev not in cur) |")
print("|---:|---:|---:|---:|")
for length, tot, hit, extra in rows:
    print(f"| {length} | {tot} ({tot * eb / 1e9:.1f} GB) | {100 * hit / tot:.0f}% | {100 * extra / tot:.0f}% |")
