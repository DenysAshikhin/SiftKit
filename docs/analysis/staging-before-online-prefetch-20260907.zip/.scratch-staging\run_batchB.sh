#!/bin/bash
# Byte-level cache verify (logits harness + 32k perf run), then the stager-timing profile.
export PATH="/c/personal/Git/usr/bin:$PATH"
export MSYS_NO_PATHCONV=1 MSYS2_ARG_CONV_EXCL='*'
cd "C:/Users/denys/Documents/GitHub/SiftKit/.scratch-staging"
R="./run_upstream.sh"
P="progress_batchB.txt"
PY='C:/envs/rl313-turbo/Scripts/python.exe'
M='D:/personal/models/elx3/td_flash-next_4.05bpw_h6_ng6'
export PYTHONPATH='C:/Users/denys/Documents/GitHub/SiftKit/pristine_exle/exllamav3-upstream'
export PYTHONDONTWRITEBYTECODE=1 PYTHONUNBUFFERED=1 PYTORCH_ALLOC_CONF='backend:native' EXL3_LOAD_ARENA=1
A="-mcs 410 -mct 12 -cs 32768 -chunk_size 4096 -ngr -max_length 32768 -sg"
B="EXL3_MOE_STREAM_BATCH_EXPERTS=24 EXL3_MOE_CPU_STAGE_THREADS=4 EXL3_MOE_MEMOPS=1 EXL3_MOE_CPU_PIECE_EXPERTS=5 EXL3_MOE_CPU_PIECES=2 EXL3_MOE_STREAM_T=8"
V="EXL3_MOE_CPU_WSLOT_MB=128 EXL3_MOE_CPU_PIN_CACHE_MB=2048 EXL3_MOE_CPU_PIN_CACHE_VERIFY=1"
echo "start $(date)" >> "$P"
env $B $V $PY logits_check_cache.py --save logits_verify.pt -m "$M" -mcs 410 -mct 12 -cs 32768 > logits_verify.log 2>&1
echo "logits_verify exit_code=$? $(grep -a 'pin cache verify' logits_verify.log)" >> "$P"
bash "$R" u-B-verify "$B $V" $A >> "$P" 2>&1
echo "verify: $(grep -a 'pin cache verify' u-B-verify.txt)" >> "$P"
bash "$R" u-B-sprof "$B EXL3_MOE_CPU_WSLOT_MB=64 EXL3_MOE_STREAM_PROF=1 EXL3_MOE_STAGE_PROF=1" $A >> "$P" 2>&1
echo "SWEEP DONE $(date)" >> "$P"
