#!/bin/bash
# Expert-reuse trace: one run per chunk size, with the best pool config, trace on.
export PATH="/c/personal/Git/usr/bin:$PATH"
export MSYS_NO_PATHCONV=1 MSYS2_ARG_CONV_EXCL='*'
cd "C:/Users/denys/Documents/GitHub/SiftKit/.scratch-staging"
R="./run_upstream.sh"
P="progress_trace.txt"
B="EXL3_MOE_CPU_WSLOT_MB=64 EXL3_MOE_STREAM_BATCH_EXPERTS=24 EXL3_MOE_CPU_STAGE_THREADS=4 EXL3_MOE_MEMOPS=1 EXL3_MOE_CPU_PIECE_EXPERTS=5 EXL3_MOE_CPU_PIECES=2"
T="C:/Users/denys/Documents/GitHub/SiftKit/.scratch-staging"
echo "start $(date)" >> "$P"
rm -f "$T/trace_c4096.txt" "$T/trace_c1024.txt"
bash "$R" u-trace-c4096 "$B EXL3_MOE_STREAM_TRACE=$T/trace_c4096.txt" -mcs 410 -mct 12 -cs 32768 -chunk_size 4096 -ngr -max_length 32768 -sg >> "$P" 2>&1
bash "$R" u-trace-c1024 "$B EXL3_MOE_STREAM_TRACE=$T/trace_c1024.txt" -mcs 410 -mct 12 -cs 32768 -chunk_size 1024 -ngr -max_length 32768 -sg >> "$P" 2>&1
echo "SWEEP DONE $(date)" >> "$P"
