#!/bin/bash
# Stager pool with a 4M-pause spin budget (u-r*): reruns of the three pathological points,
# repeats of the best point, and the remaining 4-thread geometries.
export PATH="/c/personal/Git/usr/bin:$PATH"
export MSYS_NO_PATHCONV=1 MSYS2_ARG_CONV_EXCL='*'
cd "C:/Users/denys/Documents/GitHub/SiftKit/.scratch-staging"
R="./run_upstream.sh"
A="-mcs 410 -mct 12 -cs 32768 -chunk_size 4096 -ngr -max_length 32768 -sg"
P="progress_sweep6.txt"
B="EXL3_MOE_CPU_WSLOT_MB=64 EXL3_MOE_STREAM_BATCH_EXPERTS=24 EXL3_MOE_MEMOPS=1 EXL3_MOE_CPU_PIECES=2"
echo "start $(date)" >> "$P"
bash "$R" u-r64-base-t4 "$B EXL3_MOE_CPU_STAGE_THREADS=4" $A >> "$P" 2>&1
bash "$R" u-r64-4x2-t4  "$B EXL3_MOE_CPU_PIECE_EXPERTS=4 EXL3_MOE_CPU_STAGE_THREADS=4" $A >> "$P" 2>&1
bash "$R" u-r64-6x2-t4  "$B EXL3_MOE_CPU_PIECE_EXPERTS=6 EXL3_MOE_CPU_STAGE_THREADS=4" $A >> "$P" 2>&1
bash "$R" u-r64-3x2-t2  "$B EXL3_MOE_CPU_PIECE_EXPERTS=3 EXL3_MOE_CPU_STAGE_THREADS=2" $A >> "$P" 2>&1
bash "$R" u-r64-3x2-t4  "$B EXL3_MOE_CPU_PIECE_EXPERTS=3 EXL3_MOE_CPU_STAGE_THREADS=4" $A >> "$P" 2>&1
bash "$R" u-r64-5x2-t4  "$B EXL3_MOE_CPU_PIECE_EXPERTS=5 EXL3_MOE_CPU_STAGE_THREADS=4" $A >> "$P" 2>&1
bash "$R" u-r64-4x2-t4b "$B EXL3_MOE_CPU_PIECE_EXPERTS=4 EXL3_MOE_CPU_STAGE_THREADS=4" $A >> "$P" 2>&1
bash "$R" u-r64-4x2-t4c "$B EXL3_MOE_CPU_PIECE_EXPERTS=4 EXL3_MOE_CPU_STAGE_THREADS=4" $A >> "$P" 2>&1
echo "SWEEP DONE $(date)" >> "$P"
