"""Profiler extension: compute-stream stall on wready (event pair around the wait) and compute
time per batch (after the wait to wconsumed), plus the bandwidth probe reading. Python only."""
import os

p = os.path.join(os.path.dirname(__file__), "..", "pristine_exle", "exllamav3-upstream",
                 "exllamav3", "model", "moe_cpu_host.py")
s = open(p, encoding="utf-8").read()


def rep(a, b):
    global s
    assert s.count(a) == 1, a[:70]
    s = s.replace(a, b)


rep('''        self.prof = dict(host_s = 0.0, span_s = 0.0, last_t = None, dma_ev = [], dma_b = 0,
                         pieces = 0, batches = 0, submits = 0)
''', '''        self.prof = dict(host_s = 0.0, span_s = 0.0, last_t = None, dma_ev = [], dma_b = 0,
                         pieces = 0, batches = 0, submits = 0, stall_ev = [], comp_ev = [])
''')
rep('''            # Compute the batch on the current stream once the DMA lands
            torch.cuda.current_stream().wait_event(st["wready_ev"][ws])
''', '''            # Compute the batch on the current stream once the DMA lands
            if pr is not None:
                c0 = torch.cuda.Event(enable_timing = True)
                c0.record(torch.cuda.current_stream())
            torch.cuda.current_stream().wait_event(st["wready_ev"][ws])
            if pr is not None:
                c1 = torch.cuda.Event(enable_timing = True)
                c1.record(torch.cuda.current_stream())
                pr["stall_ev"].append((c0, c1))
''')
rep('''            st["wconsumed_ev"][ws].record(torch.cuda.current_stream())
''', '''            st["wconsumed_ev"][ws].record(torch.cuda.current_stream())
            if pr is not None:
                c2 = torch.cuda.Event(enable_timing = True)
                c2.record(torch.cuda.current_stream())
                pr["comp_ev"].append((c1, c2))
''')
rep('''            dma_s = sum(a.elapsed_time(b) for a, b in pr["dma_ev"]) * 1e-3
''', '''            dma_s = sum(a.elapsed_time(b) for a, b in pr["dma_ev"]) * 1e-3
            stall_s = sum(a.elapsed_time(b) for a, b in pr["stall_ev"]) * 1e-3
            comp_s = sum(a.elapsed_time(b) for a, b in pr["comp_ev"]) * 1e-3
            bws = ", ".join(f"cuda:{k} {v['bw']:.1f} GB/s stream_t {v['stream_t']}" for k, v in self.sstate.items())
            print(f" -- stream prof: compute stream stalled on wready {stall_s:.2f} s, "
                  f"streamed-expert compute {comp_s:.2f} s; probe {bws}")
''')
open(p, "w", encoding="utf-8", newline="\n").write(s)
print("prof2 ok")
