"""EXL3_MOE_CPU_PIN_CACHE_VERIFY=1: every cache hit and fill is additionally staged through the
ring into a spare region of the VRAM slot and compared on the copy stream against the copy that
came from the cache. Mismatching experts are counted on the GPU and reported at shutdown.
Needs a VRAM slot with room for two copies of the batch (WSLOT_MB=128 at 24 experts)."""
import os

p = os.path.join(os.path.dirname(__file__), "..", "pristine_exle", "exllamav3-upstream",
                 "exllamav3", "model", "moe_cpu_host.py")
s = open(p, encoding="utf-8").read()


def rep(a, b):
    global s
    assert s.count(a) == 1, a[:70]
    s = s.replace(a, b)


rep('''        self.pin_cache_mb = int(os.environ.get("EXL3_MOE_CPU_PIN_CACHE_MB", 0))
''', '''        self.pin_cache_mb = int(os.environ.get("EXL3_MOE_CPU_PIN_CACHE_MB", 0))
        self.pin_cache_verify = bool(os.environ.get("EXL3_MOE_CPU_PIN_CACHE_VERIFY"))
''')
rep('''        self.cache_hit_b = 0
        self.cache_total_b = 0
        # Per-device CUDA state''', '''        self.cache_hit_b = 0
        self.cache_total_b = 0
        self.verify_bad = None       # GPU counters: [mismatching experts, checked experts]
        # Per-device CUDA state''')
rep('''                hits.sort(key = lambda x: x[1])
                batch = [e for e, _ in hits] + [e for e, _ in fills] + ring
                self.cache_hit_b += len(hits) * exp_b
                self.cache_total_b += len(batch) * exp_b
            staged = batch[len(hits):]
''', '''                hits.sort(key = lambda x: x[1])
                batch = [e for e, _ in hits] + [e for e, _ in fills] + ring
                self.cache_hit_b += len(hits) * exp_b
                self.cache_total_b += len(batch) * exp_b
            # Verify mode: cached experts are staged through the ring as well, into the slot
            # region past the batch, and compared against the cache copy after the DMAs
            dups = [e for e, _ in hits] + [e for e, _ in fills] if TUNING.pin_cache_verify else []
            assert (len(batch) + len(dups)) * exp_b <= self.wslot_size, "verify mode needs a larger WSLOT_MB"
            staged = batch[len(hits):] + dups
''')
rep('''                    for k in range(len(hits) + len(fills), len(batch), pe):
                        n = min(pe, len(batch) - k)
''', '''                    for k in range(len(hits) + len(fills), len(batch) + len(dups), pe):
                        n = min(pe, len(batch) + len(dups) - k)
''')
rep('''                else:
                    ext.exl3_moe_flag_wait(self.stage_done_addr[ws], seq, abort)
                    st["vram_slots"][ws][:used].copy_(self.wviews[ws][:used], non_blocking = True)
                    ext.exl3_moe_flag_write(self.pinned_free_addr[ws], seq)
''', '''                    if dups:
                        if self.verify_bad is None:
                            self.verify_bad = torch.zeros(2, dtype = torch.long, device = y.device)
                        v = st["vram_slots"][ws]
                        nb = len(batch)
                        for i in range(len(dups)):
                            a = v[(i * exp_b) // 2 : ((i + 1) * exp_b) // 2]
                            b = v[((nb + i) * exp_b) // 2 : ((nb + i + 1) * exp_b) // 2]
                            self.verify_bad[0] += (a != b).any().long()
                        self.verify_bad[1] += len(dups)
                else:
                    ext.exl3_moe_flag_wait(self.stage_done_addr[ws], seq, abort)
                    st["vram_slots"][ws][:used].copy_(self.wviews[ws][:used], non_blocking = True)
                    ext.exl3_moe_flag_write(self.pinned_free_addr[ws], seq)
''')
rep('''        if self.cache_slots and self.cache_total_b:
            print(f" -- pin cache: ''', '''        if self.verify_bad is not None:
            torch.cuda.synchronize()
            bad, checked = self.verify_bad.tolist()
            print(f" -- pin cache verify: {bad} mismatching experts of {checked} checked "
                  f"({'OK' if bad == 0 else 'CORRUPT'})")
        if self.cache_slots and self.cache_total_b:
            print(f" -- pin cache: ''')
open(p, "w", encoding="utf-8", newline="\n").write(s)
print("verify ok")
