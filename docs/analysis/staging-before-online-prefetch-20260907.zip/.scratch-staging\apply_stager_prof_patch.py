"""Stager-side timing (C++, child process): per ring piece, time spent gated on pinned_free vs
in stage_experts, plus idle time on an empty stage ring; printed to stderr at quit. Host side:
time blocked collecting the CPU tail inside submit_prefill (added to the stream prof line)."""
import os

root = os.path.join(os.path.dirname(__file__), "..", "pristine_exle", "exllamav3-upstream")


def patch(rel, pairs):
    p = os.path.join(root, rel)
    s = open(p, encoding="utf-8").read()
    for a, b in pairs:
        assert s.count(a) == 1, (rel, a[:70])
        s = s.replace(a, b)
    open(p, "w", encoding="utf-8", newline="\n").write(s)


patch("exllamav3/exllamav3_ext/cpu/moe_handoff.cu", [
    ('''        uint32_t s_gpiece = 0;   // every piece (ring or cache fill): stage_done value - 1
''', '''        // Stager timing (EXL3_MOE_STAGE_PROF): gate wait vs copy per ring piece, idle on empty ring
        const bool sprof = getenv("EXL3_MOE_STAGE_PROF") != nullptr;
        using sclock = std::chrono::steady_clock;
        int64_t sp_gate_ns = 0, sp_copy_ns = 0, sp_idle_ns = 0, sp_pieces = 0, sp_bytes = 0;
        sclock::time_point sp_idle_t0 = sclock::now();
        bool sp_idling = false;
        auto sp_report = [&]()
        {
            if (!sprof) return;
            fprintf(stderr, " -- stage prof: %lld ring pieces, %.1f GB, gate wait %.2f s, copy %.2f s "
                            "(%.1f GB/s while copying), idle on empty ring %.2f s\\n",
                    (long long) sp_pieces, sp_bytes / 1e9, sp_gate_ns / 1e9, sp_copy_ns / 1e9,
                    sp_copy_ns > 0 ? sp_bytes / (sp_copy_ns / 1e9) / 1e9 : 0.0, sp_idle_ns / 1e9);
            fflush(stderr);
        };
        uint32_t s_gpiece = 0;   // every piece (ring or cache fill): stage_done value - 1
'''),
    ('''        while (true)
        {
            if (load_acquire_u32(quit)) return;
            const uint32_t wake = load_acquire_u32(pass_wake);
            if (wake != s_last_wake) { s_last_wake = wake; s_idle = 0; }
            if (load_acquire_u32(stage_tail) == shead)
            {
                if (++s_idle < 65536) { cpu_pause_(); continue; }
                std::this_thread::sleep_for(std::chrono::microseconds(50));
                continue;
            }
            s_idle = 0;
''', '''        while (true)
        {
            if (load_acquire_u32(quit)) { sp_report(); return; }
            const uint32_t wake = load_acquire_u32(pass_wake);
            if (wake != s_last_wake) { s_last_wake = wake; s_idle = 0; }
            if (load_acquire_u32(stage_tail) == shead)
            {
                if (sprof && !sp_idling) { sp_idling = true; sp_idle_t0 = sclock::now(); }
                if (++s_idle < 65536) { cpu_pause_(); continue; }
                std::this_thread::sleep_for(std::chrono::microseconds(50));
                continue;
            }
            if (sprof && sp_idling)
            {
                sp_idling = false;
                sp_idle_ns += std::chrono::duration_cast<std::chrono::nanoseconds>(sclock::now() - sp_idle_t0).count();
            }
            s_idle = 0;
'''),
    ('''                    const uint32_t need = r - np + 1;
                    while ((int32_t)(load_acquire_u32(pf) - need) < 0)
                    {
                        if (load_acquire_u32(quit)) return;
                        cpu_pause_();
                    }
                    exl3_moe_cpu_stage_experts(
                        static_cast<int64_t>(job.layer),
                        job.experts + k,
                        static_cast<int>(n),
                        wstage + size_t(p) * piece_bytes,
                        stage_threads_
                    );
''', '''                    const uint32_t need = r - np + 1;
                    sclock::time_point t0 = sprof ? sclock::now() : sclock::time_point();
                    while ((int32_t)(load_acquire_u32(pf) - need) < 0)
                    {
                        if (load_acquire_u32(quit)) { sp_report(); return; }
                        cpu_pause_();
                    }
                    sclock::time_point t1 = sprof ? sclock::now() : sclock::time_point();
                    exl3_moe_cpu_stage_experts(
                        static_cast<int64_t>(job.layer),
                        job.experts + k,
                        static_cast<int>(n),
                        wstage + size_t(p) * piece_bytes,
                        stage_threads_
                    );
                    if (sprof)
                    {
                        sclock::time_point t2 = sclock::now();
                        sp_gate_ns += std::chrono::duration_cast<std::chrono::nanoseconds>(t1 - t0).count();
                        sp_copy_ns += std::chrono::duration_cast<std::chrono::nanoseconds>(t2 - t1).count();
                        sp_pieces += 1;
                        sp_bytes += (int64_t) n * (int64_t) exl3_moe_cpu_expert_bytes(static_cast<int64_t>(job.layer));
                    }
'''),
])

patch("exllamav3/model/moe_cpu_host.py", [
    ('''                         pieces = 0, batches = 0, submits = 0, stall_ev = [], comp_ev = [])
''', '''                         pieces = 0, batches = 0, submits = 0, stall_ev = [], comp_ev = [],
                         tail_s = 0.0)
'''),
    ('''        # Collect the CPU tail (by now usually complete) and merge
        if tail_jobs:
            self._collect_compute(tail_jobs, out_t, rtmp, h)
            out.index_add_(0, tidx, out_t)
        return out
''', '''        # Collect the CPU tail (by now usually complete) and merge
        if tail_jobs:
            if pr is not None:
                import time
                t0 = time.perf_counter()
            self._collect_compute(tail_jobs, out_t, rtmp, h)
            if pr is not None:
                pr["tail_s"] += time.perf_counter() - t0
            out.index_add_(0, tidx, out_t)
        return out
'''),
    ('''            print(f" -- stream prof: compute stream stalled on wready {stall_s:.2f} s, "
                  f"streamed-expert compute {comp_s:.2f} s; probe {bws}")
''', '''            print(f" -- stream prof: compute stream stalled on wready {stall_s:.2f} s, "
                  f"streamed-expert compute {comp_s:.2f} s, host blocked on tail collect "
                  f"{pr['tail_s']:.2f} s; probe {bws}")
'''),
])
print("stager prof ok")
