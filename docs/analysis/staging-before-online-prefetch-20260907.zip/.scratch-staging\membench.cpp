#include <cstring>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <thread>
#include <vector>
#include <chrono>
#include <immintrin.h>
// dst/src: 64-byte aligned. Non-temporal AVX2 copy (streaming stores, no RFO).
static void nt_copy(uint8_t* d, const uint8_t* s, size_t n) {
    size_t i = 0;
    for (; i + 128 <= n; i += 128) {
        __m256i a = _mm256_loadu_si256((const __m256i*)(s + i));
        __m256i b = _mm256_loadu_si256((const __m256i*)(s + i + 32));
        __m256i c = _mm256_loadu_si256((const __m256i*)(s + i + 64));
        __m256i e = _mm256_loadu_si256((const __m256i*)(s + i + 96));
        _mm256_stream_si256((__m256i*)(d + i), a);
        _mm256_stream_si256((__m256i*)(d + i + 32), b);
        _mm256_stream_si256((__m256i*)(d + i + 64), c);
        _mm256_stream_si256((__m256i*)(d + i + 96), e);
    }
    _mm_sfence();
    if (i < n) memcpy(d + i, s + i, n - i);
}
static double run(const uint8_t* src, size_t src_bytes, uint8_t* dst, int units, size_t mat, int threads, int reps, bool nt, bool seq) {
    std::vector<size_t> offs(units);
    uint64_t r = 88172645463325252ull;
    for (int u = 0; u < units; ++u) {
        if (seq) offs[u] = size_t(u) * mat;
        else { r ^= r << 13; r ^= r >> 7; r ^= r << 17; offs[u] = (r % (src_bytes / mat - 1)) * mat; }
    }
    double best = 1e9;
    for (int rep = 0; rep < reps; ++rep) {
        auto t0 = std::chrono::steady_clock::now();
        std::vector<std::thread> ts;
        for (int t = 0; t < threads; ++t)
            ts.emplace_back([&, t]() {
                for (int u = t; u < units; u += threads) {
                    if (nt) nt_copy(dst + size_t(u) * mat, src + offs[u], mat);
                    else memcpy(dst + size_t(u) * mat, src + offs[u], mat);
                }
            });
        for (auto& th : ts) th.join();
        double s = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
        if (s < best) best = s;
    }
    return double(units) * mat / best / 1e9;
}
int main() {
    setvbuf(stdout, nullptr, _IONBF, 0);
    const size_t SRC = size_t(4) << 30;
    uint8_t* src = (uint8_t*)_aligned_malloc(SRC, 64);
    for (size_t i = 0; i < SRC; i += 4096) src[i] = 1;
    // A: sequential 1 GiB in 1 MiB units (pure memory copy ceiling)
    const size_t MAT = 819200; const int UNITS_SEQ = int((size_t(1) << 30) / MAT); const int UNITS_GATHER = 24 * 3;
    uint8_t* dst = (uint8_t*)_aligned_malloc((size_t(1) << 30) + 4096, 64);
    memset(dst, 2, size_t(UNITS_SEQ) * MAT);
    for (int nt = 0; nt < 2; ++nt)
        for (int th : {1, 2, 4, 6, 8, 12})
            printf("sequential 1 GiB, %-6s, %2d threads: %5.1f GB/s\n", nt ? "NT" : "memcpy", th, run(src, SRC, dst, UNITS_SEQ, MAT, th, 5, nt, true));
    for (int nt = 0; nt < 2; ++nt)
        for (int th : {1, 2, 4, 8, 12})
            printf("gather 24 experts x3 x 819200, %-6s, %2d threads: %5.1f GB/s\n", nt ? "NT" : "memcpy", th, run(src, SRC, dst, UNITS_GATHER, MAT, th, 40, nt, false));
    // read-only and write-only ceilings, 12 threads, 1 GiB
    {
        const size_t N = size_t(1) << 30; int th = 12; const size_t SL = (N / th) & ~size_t(4095); double best = 1e9;
        for (int rep = 0; rep < 5; ++rep) {
            auto t0 = std::chrono::steady_clock::now();
            std::vector<std::thread> ts; std::vector<uint64_t> acc(th);
            for (int t = 0; t < th; ++t) ts.emplace_back([&, t]() { __m256i s = _mm256_setzero_si256(); const uint8_t* p = src + SL * t; for (size_t i = 0; i < SL; i += 32) s = _mm256_add_epi64(s, _mm256_loadu_si256((const __m256i*)(p + i))); acc[t] = _mm256_extract_epi64(s, 0); });
            for (auto& x : ts) x.join();
            double s = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count(); if (s < best) best = s;
        }
        printf("read-only 1 GiB, 12 threads: %5.1f GB/s\n", N / best / 1e9);
        best = 1e9;
        for (int rep = 0; rep < 5; ++rep) {
            auto t0 = std::chrono::steady_clock::now();
            std::vector<std::thread> ts;
            for (int t = 0; t < th; ++t) ts.emplace_back([&, t]() { __m256i z = _mm256_set1_epi8(7); uint8_t* p = dst + SL * t; for (size_t i = 0; i < SL; i += 32) _mm256_stream_si256((__m256i*)(p + i), z); _mm_sfence(); });
            for (auto& x : ts) x.join();
            double s = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count(); if (s < best) best = s;
        }
        printf("write-only NT 1 GiB, 12 threads: %5.1f GB/s\n", N / best / 1e9);
    }
    return 0;
}
