@echo off
set PATH=C:\Program Files (x86)\Microsoft Visual Studio\Installer;%PATH%
call "C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars64.bat" >nul
cd /d C:\Users\denys\Documents\GitHub\SiftKit\.scratch-staging
cl /nologo /O2 /arch:AVX2 /EHsc membench.cpp /Fe:membench.exe >build.log 2>&1
if errorlevel 1 (type build.log & exit /b 1)
membench.exe

