"""EXL3_MOE_CPU_PIN_RESIDENT_MB=N: commit-neutral pinned subset. Whole layers, in load order, are
placed in a registered shared region instead of the anonymous arena while they fit the budget,
packed [gate|up|down] per expert (the same byte layout the stager produces). The parent DMAs
those experts straight from the region (reusing the cache hit path with a pre-filled map) and
never stages them; the child computes cold-tail experts from the region like from the arena.
No duplicate memory: the arena shrinks by what the region holds. Python only."""
import os

p = os.path.join(os.path.dirname(__file__), "..", "pristine_exle", "exllamav3-upstream",
                 "exllamav3", "model", "moe_cpu_host.py")
s = open(p, encoding="utf-8").read()


def rep(a, b):
    global s
    assert s.count(a) == 1, a[:70]
    s = s.replace(a, b)


rep('''        self.pin_cache_verify = bool(os.environ.get("EXL3_MOE_CPU_PIN_CACHE_VERIFY"))
''', '''        self.pin_cache_verify = bool(os.environ.get("EXL3_MOE_CPU_PIN_CACHE_VERIFY"))
        # Prototype resident subset (piece mode only): whole layers placed in a pinned shared
        # region at load, DMA'd directly, never staged. Exclusive with the fill cache.
        self.pin_resident_mb = int(os.environ.get("EXL3_MOE_CPU_PIN_RESIDENT_MB", 0))
        assert not self.pin_resident_mb or self.piece_experts, "EXL3_MOE_CPU_PIN_RESIDENT_MB needs piece mode"
        assert not (self.pin_resident_mb and self.pin_cache_mb), "resident subset and fill cache are exclusive"
''')

# child: resident region as a second arena, per-expert packed rehome for resident layers
rep('''def _moe_cpu_child_main(conn, model_dir, threads, stage_threads):
''', '''def _moe_cpu_child_main(conn, model_dir, threads, stage_threads, resident_shm_name = None):
''')
rep('''    shm = None
    try:
        stc = SafetensorsCollection(model_dir)
        cpu = torch.device("cpu")
        arena = _HugeArena()
''', '''    shm = None
    res_shm = None
    try:
        stc = SafetensorsCollection(model_dir)
        cpu = torch.device("cpu")
        arena = _HugeArena()
        resident = None
        if resident_shm_name is not None:
            # Bump allocator over the parent's shared region; the parent's per-layer budget
            # rule guarantees it never needs a second chunk
            res_shm = shared_memory.SharedMemory(name = resident_shm_name)
            resident = _HugeArena()
            resident.chunks = [res_shm.buf]
            resident.cur = res_shm.buf
''')
rep('''                g, u, d = rehome_all(g), rehome_all(u), rehome_all(d)
                cext.exl3_moe_cpu_make_layer(
''', '''                if spec.get("resident_base") is not None:
                    # Pack [gate|up|down] per expert contiguously at resident_base, the byte
                    # layout the stager produces, so the parent DMAs an expert as one block
                    assert resident is not None and resident.cur_off == spec["resident_base"], \\
                        "resident region allocation drifted from the parent's plan"
                    def rehome_res(ts):
                        return (resident.rehome(ts[0], band_swizzle = swz and ts[0].shape[2] // 16 != 8),
                                arena.rehome(ts[1]), arena.rehome(ts[2]), arena.rehome(ts[3]))
                    rg, ru, rd = [], [], []
                    for e in range(len(u)):
                        if g:
                            rg.append(rehome_res(g[e]))
                        ru.append(rehome_res(u[e]))
                        rd.append(rehome_res(d[e]))
                    g, u, d = rg, ru, rd
                else:
                    g, u, d = rehome_all(g), rehome_all(u), rehome_all(d)
                cext.exl3_moe_cpu_make_layer(
''')
rep('''    finally:
        if shm is not None:
            shm.close()
''', '''    finally:
        if shm is not None:
            shm.close()
        if res_shm is not None:
            # Tensor views over the region outlive this scope; the process is exiting anyway
            try:
                res_shm.close()
            except BufferError:
                pass
''')

# parent: create the region before spawn, plan per layer, pass the name to the child
rep('''    def _spawn(self):
        if self.proc is not None:
            return
        ctx = multiprocessing.get_context("spawn")
        self.conn, child_conn = ctx.Pipe(duplex = True)
        self.proc = ctx.Process(
            target = _moe_cpu_child_main,
            args = (child_conn, self.model_dir, self.threads, self.stage_threads),
            daemon = True,
        )
''', '''    def _spawn(self):
        if self.proc is not None:
            return
        self.res_shm = None
        self.res_bytes = TUNING.pin_resident_mb << 20
        self.res_used = 0
        if self.res_bytes:
            self.res_shm = shared_memory.SharedMemory(create = True, size = self.res_bytes)
        ctx = multiprocessing.get_context("spawn")
        self.conn, child_conn = ctx.Pipe(duplex = True)
        self.proc = ctx.Process(
            target = _moe_cpu_child_main,
            args = (child_conn, self.model_dir, self.threads, self.stage_threads,
                    self.res_shm.name if self.res_shm is not None else None),
            daemon = True,
        )
''')
rep('''            spec["proj_bytes"] = (gb, ub, db)
            spec["expert_bytes"] = gb + ub + db
        self.specs.append(spec)
''', '''            spec["proj_bytes"] = (gb, ub, db)
            spec["expert_bytes"] = gb + ub + db
        # Resident subset plan: whole layers in registration order while they fit
        spec["resident_base"] = None
        if self.res_bytes and spec.get("expert_bytes"):
            need = spec["num_experts"] * spec["expert_bytes"]
            if self.res_used + need <= self.res_bytes:
                spec["resident_base"] = self.res_used
                self.res_used += need
        self.specs.append(spec)
''')

# ensure_started: register the region and pre-fill the hit map
rep('''        self.cache_view = torch.frombuffer(
            self.shm.buf, dtype = torch.int16, count = self.cache_slots * self.cache_stride // 2,
            offset = self.layout["cache_off"]) if self.cache_slots else None
        self.cache_map = {}          # (layer, local expert) -> slot
        self.cache_next = 0
''', '''        self.cache_view = torch.frombuffer(
            self.shm.buf, dtype = torch.int16, count = self.cache_slots * self.cache_stride // 2,
            offset = self.layout["cache_off"]) if self.cache_slots else None
        self.cache_map = {}          # (layer, local expert) -> slot
        self.cache_next = 0
        if self.res_shm is not None and self.res_used:
            # Resident subset: the region is the "cache", full from the start, slot stride is
            # the (uniform) expert size; every resident layer's experts are permanent hits
            buf = np.frombuffer(self.res_shm.buf, dtype = np.uint8)
            cuda_host_register(buf.ctypes.data, self.res_bytes,
                               flags = CUDA_HOST_REGISTER_PORTABLE | CUDA_HOST_REGISTER_MAPPED)
            self.cache_stride = max(s["expert_bytes"] for s in self.specs if s.get("resident_base") is not None)
            assert all(s["expert_bytes"] == self.cache_stride for s in self.specs if s.get("resident_base") is not None)
            self.cache_slots = self.res_used // self.cache_stride
            self.cache_next = self.cache_slots
            self.cache_view = torch.frombuffer(self.res_shm.buf, dtype = torch.int16,
                                               count = self.res_used // 2)
            for li, sp in enumerate(self.specs):
                if sp.get("resident_base") is not None:
                    base = sp["resident_base"] // self.cache_stride
                    for e in range(sp["num_experts"]):
                        self.cache_map[(li, e)] = base + e
            n_res = sum(1 for sp in self.specs if sp.get("resident_base") is not None)
            print(f" -- resident subset: {n_res}/{len(self.specs)} layers, {self.res_used / 1e9:.1f} GB pinned")
''')
rep('''        # Prototype cache: drop the entry (the slot is not reclaimed)
        self.cache_map.pop((layer_idx, local_idx), None)
''', '''        # Prototype fill cache: drop the entry (the slot is not reclaimed). Resident entries stay:
        # the install rewrites the region in place
        if self.specs[layer_idx].get("resident_base") is None:
            self.cache_map.pop((layer_idx, local_idx), None)
''')
rep('''                self.proc.join(timeout = 5)
''', '''                self.proc.join(timeout = 5)
                res = getattr(self, "res_shm", None)
                if res is not None:
                    # The torch views over the region are still alive; close is best-effort
                    try:
                        res.close()
                    except BufferError:
                        pass
                    res.unlink()
                    self.res_shm = None
''')
open(p, "w", encoding="utf-8", newline="\n").write(s)
print("resident ok")
