#!/bin/bash
# Compute-pool vs stager thread split, all with the stream + stager profilers on.
export PATH="/c/personal/Git/usr/bin:$PATH"
export MSYS_NO_PATHCONV=1 MSYS2_ARG_CONV_EXCL='*'
cd "C:/Users/denys/Documents/GitHub/SiftKit/.scratch-staging"
R="./run_upstream.sh"
P="progress_batchC.txt"
A="-mcs 410 -cs 32768 -chunk_size 4096 -ngr -max_length 32768 -sg"
B="EXL3_MOE_CPU_WSLOT_MB=64 EXL3_MOE_STREAM_BATCH_EXPERTS=24 EXL3_MOE_MEMOPS=1 EXL3_MOE_CPU_PIECE_EXPERTS=5 EXL3_MOE_CPU_PIECES=2 EXL3_MOE_STREAM_T=8 EXL3_MOE_STREAM_PROF=1 EXL3_MOE_STAGE_PROF=1"
echo "start $(date)" >> "$P"
bash "$R" u-C-mct10-t4 "$B EXL3_MOE_CPU_STAGE_THREADS=4" -mct 10 $A >> "$P" 2>&1
bash "$R" u-C-mct8-t4  "$B EXL3_MOE_CPU_STAGE_THREADS=4" -mct 8  $A >> "$P" 2>&1
bash "$R" u-C-mct8-t6  "$B EXL3_MOE_CPU_STAGE_THREADS=6" -mct 8  $A >> "$P" 2>&1
bash "$R" u-C-mct6-t6  "$B EXL3_MOE_CPU_STAGE_THREADS=6" -mct 6  $A >> "$P" 2>&1
echo "SWEEP DONE $(date)" >> "$P"
