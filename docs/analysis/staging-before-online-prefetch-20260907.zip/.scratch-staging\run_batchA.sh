#!/bin/bash
# Correctness pair, then env-only pipeline-depth experiments (stream_t pinned at 8).
export PATH="/c/personal/Git/usr/bin:$PATH"
export MSYS_NO_PATHCONV=1 MSYS2_ARG_CONV_EXCL='*'
cd "C:/Users/denys/Documents/GitHub/SiftKit/.scratch-staging"
R="./run_upstream.sh"
P="progress_batchA.txt"
A="-mcs 410 -mct 12 -cs 32768 -chunk_size 4096 -ngr -max_length 32768 -sg"
B="EXL3_MOE_CPU_WSLOT_MB=64 EXL3_MOE_STREAM_BATCH_EXPERTS=24 EXL3_MOE_MEMOPS=1 EXL3_MOE_STREAM_T=8"
echo "start $(date)" >> "$P"
bash run_logits_cache2.sh
cat progress_logits_cache2.txt >> "$P"
bash "$R" u-A-w3-5x2-t4 "$B EXL3_MOE_CPU_WSLOTS=3 EXL3_MOE_CPU_PIECE_EXPERTS=5 EXL3_MOE_CPU_PIECES=2 EXL3_MOE_CPU_STAGE_THREADS=4" $A >> "$P" 2>&1
bash "$R" u-A-w4-5x2-t4 "$B EXL3_MOE_CPU_WSLOTS=4 EXL3_MOE_CPU_PIECE_EXPERTS=5 EXL3_MOE_CPU_PIECES=2 EXL3_MOE_CPU_STAGE_THREADS=4" $A >> "$P" 2>&1
bash "$R" u-A-w2-2x5-t4 "$B EXL3_MOE_CPU_WSLOTS=2 EXL3_MOE_CPU_PIECE_EXPERTS=2 EXL3_MOE_CPU_PIECES=5 EXL3_MOE_CPU_STAGE_THREADS=4" $A >> "$P" 2>&1
bash "$R" u-A-w2-5x2-t3 "$B EXL3_MOE_CPU_WSLOTS=2 EXL3_MOE_CPU_PIECE_EXPERTS=5 EXL3_MOE_CPU_PIECES=2 EXL3_MOE_CPU_STAGE_THREADS=3" $A >> "$P" 2>&1
echo "SWEEP DONE $(date)" >> "$P"
