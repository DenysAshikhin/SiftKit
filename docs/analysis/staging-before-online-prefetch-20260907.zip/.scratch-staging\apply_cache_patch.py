"""Apply the pinned-expert-cache prototype to moe_cpu_host.py (expects the piece ring + pool
patch already applied). C++ side: moe_handoff.cu/.h (cache_offset/cache_stride worker params,
MOE_DEST_RING destination codes in stage jobs)."""
import os, sys

p = os.path.join(os.path.dirname(__file__), "..", "pristine_exle", "exllamav3-upstream",
                 "exllamav3", "model", "moe_cpu_host.py")
s = open(p, encoding="utf-8").read()


def rep(a, b):
    global s
    assert s.count(a) == 1, a[:70]
    s = s.replace(a, b)


rep('''        self.pieces = int(os.environ.get("EXL3_MOE_CPU_PIECES", 2))
''', '''        self.pieces = int(os.environ.get("EXL3_MOE_CPU_PIECES", 2))
        # Prototype pinned expert cache (piece mode only): fixed-stride slots, filled first-come
        # and never evicted; hits DMA straight from the cache, misses go through the ring
        self.pin_cache_mb = int(os.environ.get("EXL3_MOE_CPU_PIN_CACHE_MB", 0))
        assert not self.pin_cache_mb or self.piece_experts, "EXL3_MOE_CPU_PIN_CACHE_MB needs piece mode"
''')
rep('''            int(os.environ.get("EXL3_MOE_STREAM_BATCH_EXPERTS", 24)), MOE_JOB_MAX_EXPERTS))
''', '''            int(os.environ.get("EXL3_MOE_STREAM_BATCH_EXPERTS", 24)), MOE_JOB_MAX_EXPERTS // 2))
''')
rep('''                layout["wstage_off"], layout["num_wslots"], layout["wslot_size"],
                threads, stage_threads,
            ),''', '''                layout["wstage_off"], layout["num_wslots"], layout["wslot_size"],
                threads, stage_threads, layout["cache_off"], layout["cache_stride"],
            ),''')
rep('''        size = MOE_CTRL_SIZE + self.num_slots * slot_size + self.num_wslots * self.wslot_size
        self.shm = shared_memory.SharedMemory(create = True, size = size)
''', '''        size = MOE_CTRL_SIZE + self.num_slots * slot_size + self.num_wslots * self.wslot_size
        self.cache_stride = _align64(max((s.get("expert_bytes") or 0) for s in self.specs))
        self.cache_slots = ((TUNING.pin_cache_mb << 20) // self.cache_stride
                            if TUNING.pin_cache_mb and self.cache_stride else 0)
        self.layout["cache_off"] = size
        self.layout["cache_stride"] = self.cache_stride
        size += self.cache_slots * self.cache_stride
        self.shm = shared_memory.SharedMemory(create = True, size = size)
''')
rep('''        # Per-device CUDA state for the streamed-prefill path (copy stream, VRAM ring, events)
        self.sstate = {}
''', '''        self.cache_view = torch.frombuffer(
            self.shm.buf, dtype = torch.int16, count = self.cache_slots * self.cache_stride // 2,
            offset = self.layout["cache_off"]) if self.cache_slots else None
        self.cache_map = {}          # (layer, local expert) -> slot
        self.cache_next = 0
        self.cache_hit_b = 0
        self.cache_total_b = 0
        # Per-device CUDA state for the streamed-prefill path (copy stream, VRAM ring, events)
        self.sstate = {}
''')
rep('''        self.conn.send(("install", layer_idx, local_idx, keys))
''', '''        # Prototype cache: drop the entry (the slot is not reclaimed)
        self.cache_map.pop((layer_idx, local_idx), None)
        self.conn.send(("install", layer_idx, local_idx, keys))
''')
rep('''    def shutdown(self):
        if self.proc is not None:
''', '''    def shutdown(self):
        if self.cache_slots and self.cache_total_b:
            print(f" -- pin cache: {self.cache_slots} slots x {self.cache_stride / 2**20:.2f} MB, "
                  f"{self.cache_next} filled, hits {self.cache_hit_b / 1e9:.1f} GB of "
                  f"{self.cache_total_b / 1e9:.1f} GB streamed ({100 * self.cache_hit_b / self.cache_total_b:.1f}%)")
        if self.proc is not None:
''')
rep('''            batch = streamed[i0:i0 + per_slot]
            ws = self.next_wslot
''', '''            batch = streamed[i0:i0 + per_slot]
            hits, fills = [], []
            if self.cache_slots:
                ring = []
                for e in batch:
                    slot = self.cache_map.get((layer_idx, e))
                    if slot is not None:
                        hits.append((e, slot))
                    elif self.cache_next < self.cache_slots:
                        slot = self.cache_next
                        self.cache_next += 1
                        self.cache_map[(layer_idx, e)] = slot
                        fills.append((e, slot))
                    else:
                        ring.append(e)
                hits.sort(key = lambda x: x[1])
                batch = [e for e, _ in hits] + [e for e, _ in fills] + ring
                self.cache_hit_b += len(hits) * exp_b
                self.cache_total_b += len(batch) * exp_b
            staged = batch[len(hits):]
            ws = self.next_wslot
''')
rep('''            stail = int(self.v_stage_tail[0])
            while stail - int(self.v_stage_head[0]) >= MOE_STAGE_RING - 2:
''', '''            stail = int(self.v_stage_tail[0])
            while staged and stail - int(self.v_stage_head[0]) >= MOE_STAGE_RING - 2:
''')
rep('''            job = self.v_stage_jobs[stail % MOE_STAGE_RING]
            job[0] = seq
            job[1] = layer_idx
            job[2] = len(batch)
            pe = self.piece_experts
            job[3] = pe
            job[4] = ws
            job[5] = 1    # MOE_JOB_KIND_STAGE
            job[6] = self.pieces if pe else self.wslot_prev_seq[ws]
            for bi, e in enumerate(batch):
                job[7 + bi] = e
            self.v_stage_tail[0] = stail + 1
            self.wslot_prev_seq[ws] = seq
''', '''            pe = self.piece_experts
            if staged:
                job = self.v_stage_jobs[stail % MOE_STAGE_RING]
                job[0] = seq
                job[1] = layer_idx
                job[2] = len(staged)
                job[3] = pe
                job[4] = ws
                job[5] = 1    # MOE_JOB_KIND_STAGE
                job[6] = self.pieces if pe else self.wslot_prev_seq[ws]
                dest = 7 + MOE_JOB_MAX_EXPERTS // 2
                for bi, e in enumerate(staged):
                    job[7 + bi] = e
                    job[dest + bi] = fills[bi][1] if bi < len(fills) else MOE_DEST_RING
                self.v_stage_tail[0] = stail + 1
            self.wslot_prev_seq[ws] = seq
''')
rep('''                    for k in range(0, len(batch), pe):
                        n = min(pe, len(batch) - k)
''', '''                    # Cache hits: DMA straight from the pinned cache, no stager involvement.
                    # Runs of consecutive slots coalesce into one copy when slot == expert stride
                    cs = self.cache_stride // 2
                    bi = 0
                    while bi < len(hits):
                        j = bi
                        if self.cache_stride == exp_b:
                            while j + 1 < len(hits) and hits[j + 1][1] == hits[j][1] + 1:
                                j += 1
                        s0, n = hits[bi][1], j - bi + 1
                        st["vram_slots"][ws][(bi * exp_b) // 2 : ((bi + n) * exp_b) // 2].copy_(
                            self.cache_view[s0 * cs : s0 * cs + (n * exp_b) // 2], non_blocking = True)
                        bi = j + 1
                    # Cache fills: the stager wrote the slot, one piece each, same counter
                    for fi, (e, slot) in enumerate(fills):
                        g = self.piece_seq
                        self.piece_seq += 1
                        bi = len(hits) + fi
                        ext.exl3_moe_flag_wait(self.stage_done_addr[ws], g + 1, abort)
                        st["vram_slots"][ws][(bi * exp_b) // 2 : ((bi + 1) * exp_b) // 2].copy_(
                            self.cache_view[slot * cs : slot * cs + exp_b // 2], non_blocking = True)
                    for k in range(len(hits) + len(fills), len(batch), pe):
                        n = min(pe, len(batch) - k)
''')
rep('''MOE_JOB_MAX_EXPERTS = 256   # structural capacity of MoeJob.experts[]; see cpu/moe_handoff.h
''', '''MOE_JOB_MAX_EXPERTS = 256   # structural capacity of MoeJob.experts[]; see cpu/moe_handoff.h
MOE_DEST_RING = 0xFFFFFFFF  # stage job destination code: piece ring (else a cache slot index)
''')
open(p, "w", encoding="utf-8", newline="\n").write(s)
print("py ok")
