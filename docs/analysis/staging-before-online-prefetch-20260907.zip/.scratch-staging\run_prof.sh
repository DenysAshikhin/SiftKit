#!/bin/bash
# Correctness check (cache), then stream_t pinned run, then the same with the stream profiler.
export PATH="/c/personal/Git/usr/bin:$PATH"
export MSYS_NO_PATHCONV=1 MSYS2_ARG_CONV_EXCL='*'
cd "C:/Users/denys/Documents/GitHub/SiftKit/.scratch-staging"
R="./run_upstream.sh"
P="progress_prof.txt"
A="-mcs 410 -mct 12 -cs 32768 -chunk_size 4096 -ngr -max_length 32768 -sg"
B="EXL3_MOE_CPU_WSLOT_MB=64 EXL3_MOE_STREAM_BATCH_EXPERTS=24 EXL3_MOE_CPU_STAGE_THREADS=4 EXL3_MOE_MEMOPS=1 EXL3_MOE_CPU_PIECE_EXPERTS=5 EXL3_MOE_CPU_PIECES=2"
echo "start $(date)" >> "$P"
bash run_logits_cache.sh
cat progress_logits_cache.txt >> "$P"
bash "$R" u-st8       "$B EXL3_MOE_STREAM_T=8" $A >> "$P" 2>&1
bash "$R" u-prof-st8  "$B EXL3_MOE_STREAM_T=8 EXL3_MOE_STREAM_PROF=1" $A >> "$P" 2>&1
echo "SWEEP DONE $(date)" >> "$P"
