// Staging pipeline microbenchmark: arena (pageable, 4 GiB) -> pinned ring slot (CPU copy, T threads,
// regular or non-temporal stores) -> GPU (cudaMemcpyAsync), slot reuse gated on the DMA event.
// Reports delivered GB/s to the GPU. Modes: pipe (copy+DMA), copy (CPU copy only), dma (DMA only).
#include <cuda_runtime.h>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cstdint>
#include <atomic>
#include <thread>
#include <vector>
#include <chrono>
#include <immintrin.h>
#define CK(x) do { cudaError_t e = (x); if (e != cudaSuccess) { printf("CUDA %s at %d\n", cudaGetErrorString(e), __LINE__); exit(1); } } while (0)
static const size_t MAT = 819200;
static void nt_copy(uint8_t* d, const uint8_t* s, size_t n) {
    size_t i = 0;
    for (; i + 128 <= n; i += 128) {
        __m256i a = _mm256_loadu_si256((const __m256i*)(s + i)), b = _mm256_loadu_si256((const __m256i*)(s + i + 32));
        __m256i c = _mm256_loadu_si256((const __m256i*)(s + i + 64)), e = _mm256_loadu_si256((const __m256i*)(s + i + 96));
        _mm256_stream_si256((__m256i*)(d + i), a); _mm256_stream_si256((__m256i*)(d + i + 32), b);
        _mm256_stream_si256((__m256i*)(d + i + 64), c); _mm256_stream_si256((__m256i*)(d + i + 96), e);
    }
    _mm_sfence();
    if (i < n) memcpy(d + i, s + i, n - i);
}
struct Pool {
    int T; std::atomic<uint64_t> gen{0}; std::atomic<int> done{0}; std::atomic<bool> quit{false};
    std::vector<std::thread> th;
    uint8_t* dst; const uint8_t* src; const size_t* offs; int units; bool nt;
    Pool(int t) : T(t) { for (int i = 0; i < T; ++i) th.emplace_back([this, i] { run(i); }); }
    void run(int i) {
        uint64_t seen = 0;
        while (!quit.load()) {
            uint64_t g = gen.load(std::memory_order_acquire);
            if (g == seen) { _mm_pause(); continue; }
            seen = g;
            if (quit.load()) return;
            for (int u = i; u < units; u += T) {
                if (nt) nt_copy(dst + size_t(u) * MAT, src + offs[u], MAT);
                else memcpy(dst + size_t(u) * MAT, src + offs[u], MAT);
            }
            done.fetch_add(1, std::memory_order_release);
        }
    }
    void copy(uint8_t* d, const uint8_t* s, const size_t* o, int u, bool n) {
        dst = d; src = s; offs = o; units = u; nt = n; done.store(0);
        gen.fetch_add(1, std::memory_order_release);
        while (done.load(std::memory_order_acquire) < T) _mm_pause();
    }
    ~Pool() { quit = true; gen.fetch_add(1); for (auto& t : th) t.join(); }
};
int main(int argc, char** argv) {
    setvbuf(stdout, nullptr, _IONBF, 0);
    const size_t SRC = size_t(4) << 30, TOTAL = size_t(2) << 30;
    uint8_t* src = (uint8_t*)_aligned_malloc(SRC, 64);
    for (size_t i = 0; i < SRC; i += 4096) src[i] = (uint8_t)i;
    cudaStream_t st; CK(cudaStreamCreate(&st));
    {
        uint8_t* pin; CK(cudaHostAlloc((void**)&pin, size_t(1) << 30, cudaHostAllocDefault)); memset(pin, 1, size_t(1) << 30);
        uint8_t* dev; CK(cudaMalloc((void**)&dev, size_t(1) << 30));
        for (int i = 0; i < 12; ++i) CK(cudaMemcpyAsync(dev, pin, size_t(1) << 30, cudaMemcpyHostToDevice, st));
        CK(cudaStreamSynchronize(st));
        auto t0 = std::chrono::steady_clock::now();
        for (int i = 0; i < 8; ++i) CK(cudaMemcpyAsync(dev, pin, size_t(1) << 30, cudaMemcpyHostToDevice, st));
        CK(cudaStreamSynchronize(st));
        double s = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
        printf("reference DMA pinned 1 GiB x8: %5.1f GB/s\n", 8.0 * (1 << 30) / s / 1e9);
        CK(cudaFree(dev)); CK(cudaFreeHost(pin));
    }
    std::vector<size_t> sizes_mb = {2, 4, 8, 16, 32, 64, 128, 512};
    std::vector<int> threads = {1, 2, 4, 8};
    std::vector<int> depths = {2, 3};
    for (size_t mb : sizes_mb) {
        const size_t S = mb << 20; const int units = int(S / MAT); const size_t SB = size_t(units) * MAT;
        const int jobs = int(TOTAL / SB);
        std::vector<size_t> offs(size_t(units) * jobs);
        uint64_t r = 88172645463325252ull;
        for (auto& o : offs) { r ^= r << 13; r ^= r >> 7; r ^= r << 17; o = (r % (SRC / MAT - 1)) * MAT; }
        for (int depth : depths) {
            std::vector<uint8_t*> slots(depth); std::vector<uint8_t*> dev(depth); std::vector<cudaEvent_t> ev(depth);
            for (int i = 0; i < depth; ++i) { CK(cudaHostAlloc((void**)&slots[i], SB, cudaHostAllocDefault)); memset(slots[i], 1, SB); CK(cudaMalloc((void**)&dev[i], SB)); CK(cudaEventCreateWithFlags(&ev[i], cudaEventDisableTiming)); }
            for (int nt = 0; nt < 2; ++nt) for (int T : threads) {
                if (depth == 3 && T != 4) continue;
                Pool pool(T);
                auto run_mode = [&](int mode) {   // 0 pipe, 1 copy only, 2 dma only
                    for (int j = 0; j < depth; ++j) { int sl = j % depth; pool.copy(slots[sl], src, offs.data() + size_t(j) * units, units, nt); CK(cudaMemcpyAsync(dev[sl], slots[sl], SB, cudaMemcpyHostToDevice, st)); CK(cudaEventRecord(ev[sl], st)); }
                    CK(cudaStreamSynchronize(st));
                    auto t0 = std::chrono::steady_clock::now();
                    for (int j = 0; j < jobs; ++j) {
                        int sl = j % depth;
                        if (mode != 1 && j >= depth) CK(cudaEventSynchronize(ev[sl]));
                        if (mode != 2) pool.copy(slots[sl], src, offs.data() + size_t(j) * units, units, nt);
                        if (mode != 1) { CK(cudaMemcpyAsync(dev[sl], slots[sl], SB, cudaMemcpyHostToDevice, st)); CK(cudaEventRecord(ev[sl], st)); }
                    }
                    if (mode != 1) CK(cudaStreamSynchronize(st));
                    double s = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
                    return double(jobs) * SB / s / 1e9;
                };
                double pipe = run_mode(0), copy = run_mode(1), dma = (T == 4 && nt == 0) ? run_mode(2) : 0.0;
                printf("slot %4zu MB depth %d %-6s T=%d: pipe %5.1f GB/s | copy-only %5.1f", mb, depth, nt ? "NT" : "memcpy", T, pipe, copy);
                if (dma > 0) printf(" | dma-only %5.1f", dma);
                printf("\n");
            }
            for (int i = 0; i < depth; ++i) { CK(cudaFreeHost(slots[i])); CK(cudaFree(dev[i])); CK(cudaEventDestroy(ev[i])); }
        }
    }
    return 0;
}
