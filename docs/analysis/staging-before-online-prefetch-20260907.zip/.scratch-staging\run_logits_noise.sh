#!/bin/bash
# Noise floor: piece mode, cache off, same harness as logits_base (single prefill) -> logits_base2.pt
export PATH="/c/personal/Git/usr/bin:$PATH"
export MSYS_NO_PATHCONV=1 MSYS2_ARG_CONV_EXCL='*'
cd "C:/Users/denys/Documents/GitHub/SiftKit/.scratch-staging"
P="progress_logits_noise.txt"
PY='C:/envs/rl313-turbo/Scripts/python.exe'
M='D:/personal/models/elx3/td_flash-next_4.05bpw_h6_ng6'
export PYTHONPATH='C:/Users/denys/Documents/GitHub/SiftKit/pristine_exle/exllamav3-upstream'
export PYTHONDONTWRITEBYTECODE=1 PYTHONUNBUFFERED=1 PYTORCH_ALLOC_CONF='backend:native' EXL3_LOAD_ARENA=1
B="EXL3_MOE_CPU_WSLOT_MB=64 EXL3_MOE_STREAM_BATCH_EXPERTS=24 EXL3_MOE_CPU_STAGE_THREADS=4 EXL3_MOE_MEMOPS=1 EXL3_MOE_CPU_PIECE_EXPERTS=5 EXL3_MOE_CPU_PIECES=2"
echo "start $(date)" >> "$P"
env $B $PY logits_check_up.py --save logits_base2.pt -m "$M" -mcs 410 -mct 12 -cs 32768 > logits_base2.log 2>&1
echo "logits_base2 exit_code=$?" >> "$P"
$PY compare_pt.py logits_base.pt logits_base2.pt > logits_compare_noise.txt 2>&1
echo "compare base vs base2: $(cat logits_compare_noise.txt)" >> "$P"
$PY compare_pt.py logits_base2.pt logits_cache.pt >> logits_compare_noise.txt 2>&1
echo "compare base2 vs cache: $(tail -1 logits_compare_noise.txt)" >> "$P"
echo "DONE $(date)" >> "$P"
