"""Replay a stream trace and report byte hit rates of a pinned expert cache per prefill length.

Trace line: <t> <layer> <rows> <expert_bytes> <e:count> ...
A prefill = consecutive chunks; a new chunk starts when layer <= previous layer. Prefills are
identified by their row sum matching perf.py's doubling lengths. Policies: LRU, static (fill
once, never evict: best for a cyclic sweep), Belady (optimal, upper bound).
"""
import sys
from collections import OrderedDict

def load(path):
    calls = []
    for ln in open(path):
        f = ln.split()
        if len(f) < 4:
            continue
        ids = [int(x.split(":")[0]) for x in f[4:]]
        calls.append((int(f[1]), int(f[2]), int(f[3]), ids))
    return calls

def split_prefills(calls):
    chunks, cur, prev_layer = [], [], -1
    for c in calls:
        if c[0] <= prev_layer and cur:
            chunks.append(cur); cur = []
        cur.append(c); prev_layer = c[0]
    if cur:
        chunks.append(cur)
    # perf.py extends the cache incrementally: warmup 256..chunk, then 256..max, each length
    # prefilling only its new tokens. Group by the resulting chunk counts.
    per = [1, 1, 1, 1, 1] + [1, 1, 1, 1, 1, 1, 2, 4]
    prefills, i = [], 0
    for n in per:
        if i >= len(chunks):
            break
        grp = chunks[i:i + n]; i += n
        prefills.append((sum(ch[0][1] for ch in grp), grp))
    if i < len(chunks):
        prefills.append((sum(ch[0][1] for ch in chunks[i:]), chunks[i:]))
    return prefills

def accesses(prefill):
    out = []
    for ch in prefill:
        for layer, rows, eb, ids in ch:
            for e in ids:
                out.append(((layer, e), eb))
    return out

def sim_lru(acc, cap):
    c, used, hit = OrderedDict(), 0, 0
    for k, b in acc:
        if k in c:
            c.move_to_end(k); hit += b; continue
        while used + b > cap and c:
            _, ob = c.popitem(last = False); used -= ob
        if b <= cap:
            c[k] = b; used += b
    return hit

def sim_static(acc, cap):
    c, used, hit = set(), 0, 0
    for k, b in acc:
        if k in c:
            hit += b
        elif used + b <= cap:
            c.add(k); used += b
    return hit

def sim_belady(acc, cap):
    nxt = {}
    following = [0] * len(acc)
    for i in range(len(acc) - 1, -1, -1):
        k = acc[i][0]
        following[i] = nxt.get(k, len(acc) + i)
        nxt[k] = i
    c, used, hit = {}, 0, 0
    for i, (k, b) in enumerate(acc):
        if k in c:
            hit += b; c[k] = following[i]; continue
        while used + b > cap and c:
            victim = max(c, key = c.get)
            if c[victim] < following[i]:
                break
            del c[victim]; used -= b
        if used + b <= cap:
            c[k] = following[i]; used += b
    return hit

def main():
    calls = load(sys.argv[1])
    caps = [int(x) for x in sys.argv[2:]] or [256, 512, 1024, 2048, 5120]
    eb = calls[0][2]
    prefills = split_prefills(calls)
    print(f"expert_bytes {eb / 2**20:.2f} MB, calls {len(calls)}, prefills {[p[0] for p in prefills]}")
    print("| prefill | chunks | streamed GB | distinct GB | " + " | ".join(
        f"{c} MB LRU / static / Belady" for c in caps) + " |")
    print("|---:|---:|---:|---:|" + "---:|" * len(caps))
    for rows, pf in prefills:
        acc = accesses(pf)
        total = sum(b for _, b in acc)
        distinct = len({k for k, _ in acc}) * eb
        cells = []
        for c in caps:
            cap = c * 2**20
            cells.append(" / ".join(f"{100 * f(acc, cap) / max(total, 1):.0f}%"
                                    for f in (sim_lru, sim_static, sim_belady)))
        print(f"| {rows} | {len(pf)} | {total / 1e9:.1f} | {distinct / 1e9:.1f} | " + " | ".join(cells) + " |")
    # cross-prefill reuse: whole trace as one stream (a static cache persists across requests)
    acc = accesses([ch for _, pf in prefills for ch in pf])
    total = sum(b for _, b in acc)
    print("whole trace (cache persists across prefills), LRU / static / Belady: " + ", ".join(
        f"{c} MB " + " / ".join(f"{100 * f(acc, c * 2**20) / total:.0f}%" for f in (sim_lru, sim_static, sim_belady))
        for c in caps))
    # popularity: how skewed are streamed bytes across (layer, expert)?
    from collections import Counter
    cnt = Counter(k for k, _ in acc)
    ranked = sorted(cnt.values(), reverse = True)
    tot = sum(ranked)
    for c in caps:
        n = min(len(ranked), int(c * 2**20 // eb))
        print(f"top-{n} experts by frequency ({c} MB) cover {100 * sum(ranked[:n]) / tot:.0f}% of accesses")

if __name__ == "__main__":
    main()
