"""Persistent stager pool: exl3_moe_cpu_stage_experts no longer spawns/joins std::threads per
call. A process-wide pool (sized at first use from `threads`) parks on a generation counter
(spin, then 50 us sleeps when idle); the caller takes worker 0's share and waits for the
helpers' done count. Threads are detached: no join at exit."""
import os
p = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "pristine_exle", "exllamav3-upstream", "exllamav3", "exllamav3_ext", "cpu", "moe_mul1.cpp")
s = open(p, encoding="utf-8").read()
old = """    StageCtx ctx { get_layer(handle), expert_ids, count, dst };
    const bool gated = !ctx.layer->gates.empty();
    int units = count * (gated ? 3 : 2);
    int nt = std::min(threads > 0 ? threads : 1, units);
    if (nt <= 1)
    {
        stage_phase(&ctx, 0, 1);
        return;
    }
    std::vector<std::thread> ts;
    ts.reserve(nt);
    for (int i = 0; i < nt; ++i)
        ts.emplace_back(stage_phase, &ctx, i, nt);
    for (auto& t : ts)
        t.join();
}
"""
new = """    StageCtx ctx { get_layer(handle), expert_ids, count, dst };
    const bool gated = !ctx.layer->gates.empty();
    int units = count * (gated ? 3 : 2);
    int nt = std::min(threads > 0 ? threads : 1, units);
    if (nt <= 1)
    {
        stage_phase(&ctx, 0, 1);
        return;
    }
    StagePool& pool = stage_pool();
    pool.ensure(nt - 1);
    pool.run(&ctx, std::min(nt, pool.helpers + 1));
}
"""
assert s.count(old) == 1
s = s.replace(old, new)
old2 = """void exl3_moe_cpu_stage_experts
(
    int64_t handle,"""
new2 = """namespace {

// Persistent helper threads for stage_experts: created once (sized by the first call's thread
// count), parked on a generation counter between jobs. The caller is worker 0.
struct StagePool
{
    int helpers = 0;
    std::atomic<uint32_t> gen { 0 };
    std::atomic<int> done { 0 };
    StageCtx* ctx = nullptr;
    int num_workers = 1;

    void ensure(int n)
    {
        if (helpers > 0 || n <= 0) return;
        helpers = n;
        for (int i = 0; i < n; ++i)
            std::thread([this, i]() { loop(i + 1); }).detach();
    }

    void loop(int worker)
    {
        uint32_t seen = 0;
        int idle = 0;
        while (true)
        {
            uint32_t g = gen.load(std::memory_order_acquire);
            if (g == seen)
            {
                if (++idle < 65536) { cpu_pause(); continue; }
                std::this_thread::sleep_for(std::chrono::microseconds(50));
                continue;
            }
            idle = 0;
            seen = g;
            if (worker < num_workers) stage_phase(ctx, worker, num_workers);
            done.fetch_add(1, std::memory_order_release);
        }
    }

    void run(StageCtx* c, int workers)
    {
        ctx = c;
        num_workers = workers;
        done.store(0, std::memory_order_relaxed);
        gen.fetch_add(1, std::memory_order_release);
        stage_phase(c, 0, workers);
        while (done.load(std::memory_order_acquire) < helpers) cpu_pause();
    }
};

StagePool& stage_pool() { static StagePool p; return p; }

} // namespace

void exl3_moe_cpu_stage_experts
(
    int64_t handle,"""
assert s.count(old2) == 1
s = s.replace(old2, new2)
open(p, "w", encoding="utf-8", newline="\n").write(s)
print("patched moe_mul1.cpp (stager pool)")
