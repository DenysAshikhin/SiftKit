#!/bin/bash
# Upstream staging-ring sweep, prefill only. Launch detached from PowerShell (see the direction doc).
export PATH="/c/personal/Git/usr/bin:$PATH"
export MSYS_NO_PATHCONV=1 MSYS2_ARG_CONV_EXCL='*'
cd "C:/Users/denys/Documents/GitHub/SiftKit/.scratch-staging"
R="./run_upstream.sh"
A="-mcs 410 -mct 12 -cs 32768 -chunk_size 4096 -ngr -max_length 32768 -sg"
P="progress_sweep.txt"
echo "start $(date)" >> "$P"
bash "$R" u-base  ""                                                   $A >> "$P" 2>&1
bash "$R" u-w8    "EXL3_MOE_CPU_WSLOT_MB=8"                             $A >> "$P" 2>&1
bash "$R" u-w4    "EXL3_MOE_CPU_WSLOT_MB=4"                             $A >> "$P" 2>&1
bash "$R" u-w16   "EXL3_MOE_CPU_WSLOT_MB=16"                            $A >> "$P" 2>&1
bash "$R" u-w8-t2 "EXL3_MOE_CPU_WSLOT_MB=8 EXL3_MOE_CPU_STAGE_THREADS=2" $A >> "$P" 2>&1
echo "SWEEP DONE $(date)" >> "$P"
