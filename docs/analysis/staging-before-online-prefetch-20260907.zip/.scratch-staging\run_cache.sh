#!/bin/bash
# Pinned expert cache prototype: correctness (double prefill vs baseline logits), then the
# cache-size sweep on the 5x2 / 4-thread / memops config, then the large-FIFO sweep.
export PATH="/c/personal/Git/usr/bin:$PATH"
export MSYS_NO_PATHCONV=1 MSYS2_ARG_CONV_EXCL='*'
cd "C:/Users/denys/Documents/GitHub/SiftKit/.scratch-staging"
R="./run_upstream.sh"
P="progress_cache.txt"
PY='C:/envs/rl313-turbo/Scripts/python.exe'
M='D:/personal/models/elx3/td_flash-next_4.05bpw_h6_ng6'
export PYTHONPATH='C:/Users/denys/Documents/GitHub/SiftKit/pristine_exle/exllamav3-upstream'
export PYTHONDONTWRITEBYTECODE=1 PYTHONUNBUFFERED=1 PYTORCH_ALLOC_CONF='backend:native' EXL3_LOAD_ARENA=1
A="-mcs 410 -mct 12 -cs 32768 -chunk_size 4096 -ngr -max_length 32768 -sg"
B="EXL3_MOE_CPU_WSLOT_MB=64 EXL3_MOE_STREAM_BATCH_EXPERTS=24 EXL3_MOE_CPU_STAGE_THREADS=4 EXL3_MOE_MEMOPS=1 EXL3_MOE_CPU_PIECE_EXPERTS=5 EXL3_MOE_CPU_PIECES=2"
echo "start $(date)" >> "$P"
env $B EXL3_MOE_CPU_PIN_CACHE_MB=5120 $PY logits_check_cache.py --save logits_cache.pt -m "$M" -mcs 410 -mct 12 -cs 32768 > logits_cache.log 2>&1
echo "logits_cache exit_code=$?" >> "$P"
$PY compare_pt.py logits_base.pt logits_cache.pt > logits_compare_cache.txt 2>&1
echo "compare: $(cat logits_compare_cache.txt)" >> "$P"
bash "$R" u-cache-0     "$B" $A >> "$P" 2>&1
bash "$R" u-cache-5120  "$B EXL3_MOE_CPU_PIN_CACHE_MB=5120"  $A >> "$P" 2>&1
bash "$R" u-cache-2048  "$B EXL3_MOE_CPU_PIN_CACHE_MB=2048"  $A >> "$P" 2>&1
bash "$R" u-cache-10240 "$B EXL3_MOE_CPU_PIN_CACHE_MB=10240" $A >> "$P" 2>&1
echo "CACHE DONE $(date)" >> "$P"
F="EXL3_MOE_CPU_STAGE_THREADS=4 EXL3_MOE_MEMOPS=1 EXL3_MOE_CPU_PIECES=8"
bash "$R" u-fifo-24x8   "$F EXL3_MOE_CPU_WSLOT_MB=256  EXL3_MOE_STREAM_BATCH_EXPERTS=24  EXL3_MOE_CPU_PIECE_EXPERTS=24"  $A >> "$P" 2>&1
bash "$R" u-fifo-64x8   "$F EXL3_MOE_CPU_WSLOT_MB=640  EXL3_MOE_STREAM_BATCH_EXPERTS=64  EXL3_MOE_CPU_PIECE_EXPERTS=64"  $A >> "$P" 2>&1
bash "$R" u-fifo-128x8  "$F EXL3_MOE_CPU_WSLOT_MB=1280 EXL3_MOE_STREAM_BATCH_EXPERTS=128 EXL3_MOE_CPU_PIECE_EXPERTS=128" $A >> "$P" 2>&1
echo "SWEEP DONE $(date)" >> "$P"
