#!/bin/bash
# Piece-ring follow-up: inline single-thread staging (no per-piece thread spawn) and memops on.
export PATH="/c/personal/Git/usr/bin:$PATH"
export MSYS_NO_PATHCONV=1 MSYS2_ARG_CONV_EXCL='*'
cd "C:/Users/denys/Documents/GitHub/SiftKit/.scratch-staging"
R="./run_upstream.sh"
A="-mcs 410 -mct 12 -cs 32768 -chunk_size 4096 -ngr -max_length 32768 -sg"
P="progress_sweep3.txt"
B="EXL3_MOE_CPU_WSLOT_MB=64 EXL3_MOE_STREAM_BATCH_EXPERTS=24"
echo "start $(date)" >> "$P"
bash "$R" u-p64-3x2-t1     "$B EXL3_MOE_CPU_PIECE_EXPERTS=3 EXL3_MOE_CPU_PIECES=2 EXL3_MOE_CPU_STAGE_THREADS=1" $A >> "$P" 2>&1
bash "$R" u-p64-3x2-t1-mo1 "$B EXL3_MOE_CPU_PIECE_EXPERTS=3 EXL3_MOE_CPU_PIECES=2 EXL3_MOE_CPU_STAGE_THREADS=1 EXL3_MOE_MEMOPS=1" $A >> "$P" 2>&1
bash "$R" u-p64-4x2-t1     "$B EXL3_MOE_CPU_PIECE_EXPERTS=4 EXL3_MOE_CPU_PIECES=2 EXL3_MOE_CPU_STAGE_THREADS=1" $A >> "$P" 2>&1
bash "$R" u-p64-2x3-t1     "$B EXL3_MOE_CPU_PIECE_EXPERTS=2 EXL3_MOE_CPU_PIECES=3 EXL3_MOE_CPU_STAGE_THREADS=1" $A >> "$P" 2>&1
bash "$R" u-p64-6x2-t1     "$B EXL3_MOE_CPU_PIECE_EXPERTS=6 EXL3_MOE_CPU_PIECES=2 EXL3_MOE_CPU_STAGE_THREADS=1" $A >> "$P" 2>&1
bash "$R" u-base64-t1      "$B EXL3_MOE_CPU_STAGE_THREADS=1" $A >> "$P" 2>&1
echo "SWEEP DONE $(date)" >> "$P"
