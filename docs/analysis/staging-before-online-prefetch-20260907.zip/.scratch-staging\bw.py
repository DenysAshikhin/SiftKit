import time, threading, torch
GiB = 1 << 30
def gbs(nbytes, s): return nbytes / s / 1e9
def best(fn, reps=8, warm=3):
    for _ in range(warm): fn()
    ts = []
    for _ in range(reps):
        t0 = time.perf_counter(); fn(); ts.append(time.perf_counter() - t0)
    return min(ts), sorted(ts)[len(ts)//2]

print("torch", torch.__version__, "threads", torch.get_num_threads())
src = torch.empty(GiB, dtype=torch.uint8); src.fill_(1)
dst = torch.empty(GiB, dtype=torch.uint8); dst.fill_(2)
for th in (1, 4, 8, 12):
    torch.set_num_threads(th)
    mn, md = best(lambda: dst.copy_(src))
    print(f"DRAM copy 1 GiB pageable->pageable, {th:2d} threads: best {gbs(GiB, mn):5.1f} GB/s, median {gbs(GiB, md):5.1f}")
pin = torch.empty(GiB, dtype=torch.uint8).pin_memory(); pin.fill_(3)
for th in (1, 8):
    torch.set_num_threads(th)
    mn, md = best(lambda: pin.copy_(src))
    print(f"DRAM copy 1 GiB pageable->pinned,   {th:2d} threads: best {gbs(GiB, mn):5.1f} GB/s, median {gbs(GiB, md):5.1f}")
torch.set_num_threads(12)

# staging pattern: 3 matrices of 819200 B per expert from random offsets of a 4 GiB arena into a contiguous dst
MAT = 819200; EXPERTS = 24; UNITS = EXPERTS * 3
arena = torch.empty(4 * GiB, dtype=torch.uint8); arena[::4096] = 1
g = torch.Generator().manual_seed(1)
offs = (torch.randint(0, 4 * GiB // MAT - 1, (UNITS,), generator=g) * MAT).tolist()
for name, d in (("pageable", torch.zeros(UNITS * MAT, dtype=torch.uint8)), ("pinned", torch.zeros(UNITS * MAT, dtype=torch.uint8).pin_memory())):
    for th in (1, 4, 8):
        def run():
            def work(t):
                for u in range(t, UNITS, th):
                    d[u*MAT:(u+1)*MAT].copy_(arena[offs[u]:offs[u]+MAT])
            ths = [threading.Thread(target=work, args=(t,)) for t in range(th)]
            for x in ths: x.start()
            for x in ths: x.join()
        mn, md = best(run, reps=20)
        print(f"staging gather {EXPERTS} experts x3 x {MAT} B -> {name:8s}, {th} py-threads: best {gbs(UNITS*MAT, mn):5.1f} GB/s, median {gbs(UNITS*MAT, md):5.1f}")

# PCIe
dev = torch.empty(GiB, dtype=torch.uint8, device="cuda")
torch.cuda.synchronize()
def h2d_pin(): dev.copy_(pin); torch.cuda.synchronize()
def h2d_page(): dev.copy_(src); torch.cuda.synchronize()
def d2h_pin(): pin.copy_(dev); torch.cuda.synchronize()
t0 = time.perf_counter()
while time.perf_counter() - t0 < 0.5: h2d_pin()   # warm link out of Gen1
for name, fn in (("H2D pinned", h2d_pin), ("H2D pageable", h2d_page), ("D2H pinned", d2h_pin)):
    mn, md = best(fn)
    print(f"PCIe {name:13s} 1 GiB: best {gbs(GiB, mn):5.1f} GB/s, median {gbs(GiB, md):5.1f}")
# overlapped: two streams, half each
s1, s2 = torch.cuda.Stream(), torch.cuda.Stream()
h = GiB // 2
def h2d_2s():
    with torch.cuda.stream(s1): dev[:h].copy_(pin[:h], non_blocking=True)
    with torch.cuda.stream(s2): dev[h:].copy_(pin[h:], non_blocking=True)
    torch.cuda.synchronize()
mn, md = best(h2d_2s)
print(f"PCIe H2D pinned 2 streams  1 GiB: best {gbs(GiB, mn):5.1f} GB/s, median {gbs(GiB, md):5.1f}")
